package core.utils;
//
import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.bigquery.*;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.UUID;
//
public class BQconnector {
//
    static BigQuery bigquery;
    private Logger log = Logger.getLogger();

    public void connectToBq() throws IOException {
        GoogleCredentials credentials = GoogleCredentials.fromStream(new FileInputStream("src/main/resources/bq.json"));
        bigquery = BigQueryOptions.newBuilder().setCredentials(credentials).build().getService();
        if(bigquery != null){
            log.info("BigQuery Connected");
        }
    }

    public TableResult executeQuery(String query) throws InterruptedException, IOException {

        connectToBq();
        QueryJobConfiguration queryConfig = QueryJobConfiguration.newBuilder(query).setUseLegacySql(false).build();

        JobId jobId = JobId.of(UUID.randomUUID().toString());
        Job queryJob = bigquery.create(JobInfo.newBuilder(queryConfig).setJobId(jobId).build());

        queryJob = queryJob.waitFor();

        if (queryJob == null) {
            throw new RuntimeException("Job no longer exists");
        } else if (queryJob.getStatus().getError() != null) {

            throw new RuntimeException(queryJob.getStatus().getError().toString());
        }
        log.info("Querying from BigQuery...");
        TableResult result = queryJob.getQueryResults();
        return result;

    }

//    public String getEventKeyValue(TableResult event, String key){
//
//        String traceID = null;
//        for(FieldValueList row : event.iterateAll()){
//            traceID = row.get(key).getStringValue();
//        }
//        return traceID;
//    }
//
//
//
}
