package core.driver;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import core.utils.Logger;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.html5.LocalStorage;
import org.openqa.selenium.html5.WebStorage;
import org.openqa.selenium.remote.RemoteWebDriver;

/**
 * Hello world!
 *
 */
public final class BaseDriver
{

    private static Logger log = core.utils.Logger.getLogger();
    static ThreadLocal<WebDriver> driverHolder = new ThreadLocal<WebDriver>();

    private static WebDriver initDriver(){

        System.setProperty("webdriver.chrome.silentOutput", "true");
//        System.setProperty("webdriver.chrome.driver", "src/main/resources/chromedriver.exe");

        ChromeOptions options = new ChromeOptions();
//        options.setBinary("src/main/resources/chrome-win64/chrome.exe");
        options.addArguments("incognito");
        options.addArguments("--remote-allow-origins=*");
        options.addArguments("--window-size=400,800");
        WebDriver driver = new ChromeDriver(options);
//        Capabilities caps = ((ChromeDriver) driver).getCapabilities();
//        String browserName = caps.getBrowserName();
//        String browserVersion = caps.getBrowserVersion();
//        System.out.println(browserName+" "+browserVersion);

        return driver;
    }

    public static WebDriver getDriver() throws Exception {
        try{
            if(driverHolder.get() == null){
                driverHolder.set(BaseDriver.initDriver());
                return driverHolder.get();
            }
        } catch (Exception e){
            log.error("Error in getting chrome driver = "+e.getLocalizedMessage());
            e.printStackTrace();
        }
        return driverHolder.get();
    }

    public static void closeBrowser() throws Exception {
        try {
            getDriver().close();
        } catch (Exception e) {
            log.error("Error in Closing chrome = "+e.getLocalizedMessage());
        } finally {
            driverHolder.remove();
        }
    }

    public static void setLocInfoInBrowserStorage(String div, String store) throws Exception {

        LocalStorage local = ((WebStorage) getDriver()).getLocalStorage();
        JsonObject jsonObject = JsonParser.parseString(local.getItem("simulatorData")).getAsJsonObject();
        JsonObject getLocationInformation = jsonObject.getAsJsonObject("getLocationInformation")
                .getAsJsonObject("response")
                .getAsJsonObject("locationInformation");
        JsonObject divInfo = getLocationInformation.getAsJsonObject("divInfo");
        JsonObject storeInfo = getLocationInformation.getAsJsonObject("storeInfo");
        divInfo.addProperty("num", div);
        storeInfo.addProperty("num", store);
        local.removeItem("simulatorData");
        local.setItem("simulatorData",jsonObject.toString());
    }




}
