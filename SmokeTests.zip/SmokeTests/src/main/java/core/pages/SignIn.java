package core.pages;

import core.driver.BaseDriver;
import core.utils.Logger;
import core.utils.Parser;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.SkipException;

import java.util.Base64;

public class SignIn extends BasePage{

    private Logger log = Logger.getLogger();
    private WebDriver driver = BaseDriver.getDriver();

    @FindBy(xpath = "//input[@id='loginButton_0']")
    WebElement loginButton;

    @FindBy(xpath = "//input[@id='idToken2']")
    WebElement userName;

    @FindBy(xpath = "//input[@id='idToken3']")
    WebElement passWord;
    private String loginButtonXpath = "//input[@id='loginButton_0']";


    private String passwordNotice = "//h4[text()='PASSWORD EXPIRATION NOTICE']";

    @FindBy(xpath = "//input[@id='idToken3_0']")
    WebElement changeLaterBtn;

    public SignIn() throws Exception {
        log.info("User in Sign In Page");
        PageFactory.initElements(driver, this);
    }

    public void login() throws Exception {

        try {
            waitForElement(By.xpath(loginButtonXpath));
            log.info("Entering Username and Password...");
            userName.sendKeys(Parser.getProperties().getProperty("userName"));
            passWord.sendKeys(new String(Base64.getDecoder().decode(Parser.getProperties().getProperty("passWord"))));
            loginButton.click();
            sleep(2);
            if(!isElementNotDisplayed(By.xpath(passwordNotice))){
                changeLaterBtn.click();
            }
        }
        catch (Exception ne){
            log.error(ne.getLocalizedMessage());
            throw new SkipException("Login Page is not loaded");
        }


    }
}
