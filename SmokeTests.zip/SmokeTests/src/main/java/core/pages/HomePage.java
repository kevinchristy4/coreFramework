package core.pages;

import core.driver.BaseDriver;
import core.utils.Logger;
import core.utils.Parser;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class HomePage extends BasePage{

    private Logger log = Logger.getLogger();
    private WebDriver driver = BaseDriver.getDriver();
    private String headerXpath = "//div[@id='greeting-message']";

    @FindBy(xpath = "//div[@id='greeting-message']")
    WebElement pageHeader;

    @FindBy(xpath = "//div[@class='right menu page-header-menu']//i[@title='Search']")
    WebElement searchIcon;

    @FindBy(xpath = "//div[@class='right menu page-header-menu']//div[@class='item']")
    WebElement notificationIcon;

    public HomePage() throws Exception {
        waitForElement(By.xpath(headerXpath));
        log.info("User In HomePage");
        PageFactory.initElements(driver, this);
    }

    public void verifyUserName(){
        pageHeader.getText().contains(Parser.getProperties().getProperty("userActualName"));
    }

    public void verifySearchAndNotificationIconPresent(){

        Assert.assertTrue(searchIcon.isDisplayed(),"Search icon is not displayed");
        Assert.assertTrue(notificationIcon.isDisplayed(),"Notification icon is not displayed");
    }
}
