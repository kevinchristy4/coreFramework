package core.pages;

import core.driver.BaseDriver;
import core.utils.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class Preferences extends BasePage{

    private Logger log = Logger.getLogger();
    private WebDriver driver = BaseDriver.getDriver();
    private String headerXpath = "//div[text()=\"Preferences\"]";

    @FindBy(xpath = "//div[@id=\"pref-list-item-title-Switch Division\"]")
    WebElement switchDivision;

    @FindBy(xpath = "//div[@id=\"pref-list-item-title-Subscribe to Alerts\"]")
    WebElement subscribeAlerts;

    @FindBy(xpath = "//div[@id=\"pref-list-item-title-RFID\"]")
    WebElement rfid;

    @FindBy(xpath = "//div[@id=\"pref-list-item-title-Printer\"]")
    WebElement printer;

    @FindBy(xpath = "//div[@id=\"pref-list-item-title-Application Info\"]")
    WebElement appInfo;

    @FindBy(xpath = "//div[@id=\"pref-list-item-title-Sign Out\"]")
    WebElement signOut;

    private String signOutHeader = "//div[@class=\"header\" and text()='Sign out']";

    @FindBy(xpath = "//div[@class=\"button-content\" and text()='Yes']")
    WebElement signoutConfirmation;

    public Preferences() throws Exception {
        waitForElement(By.xpath(headerXpath));
        log.info("User In Preferences");
        PageFactory.initElements(driver, this);
    }

    public void verifyAllOptionsArePresent() throws Exception {

        Assert.assertTrue(switchDivision.isDisplayed(),"switchDivision option is not displayed");
        Assert.assertTrue(subscribeAlerts.isDisplayed(),"subscribeAlerts option is not displayed");
        Assert.assertTrue(rfid.isDisplayed(),"rfid option is not displayed");
        Assert.assertTrue(printer.isDisplayed(),"printer option is not displayed");
        scrollToBottom();
        Assert.assertTrue(appInfo.isDisplayed(),"appInfo option is not displayed");
        Assert.assertTrue(signOut.isDisplayed(),"signOut option is not displayed");

    }

    public void verifyAllOptionsArePresentBLM() throws Exception {

        Assert.assertTrue(subscribeAlerts.isDisplayed(),"subscribeAlerts option is not displayed");
        Assert.assertTrue(rfid.isDisplayed(),"rfid option is not displayed");
        Assert.assertTrue(printer.isDisplayed(),"printer option is not displayed");
        scrollToBottom();
        Assert.assertTrue(appInfo.isDisplayed(),"appInfo option is not displayed");
        Assert.assertTrue(signOut.isDisplayed(),"signOut option is not displayed");

    }


    public void signOut() throws Exception {

        scrollToBottom();
        signOut.click();
        waitForElement(By.xpath(signOutHeader));
        signoutConfirmation.click();

    }

}
