package core.pages.Prelude;

import core.driver.BaseDriver;
import core.pages.BasePage;
import core.utils.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ConnectDevices extends BasePage {

    private Logger log = Logger.getLogger();
    private WebDriver driver = BaseDriver.getDriver();
    private String popUpHeader = "//div[@class='header' and text()='OS Update Required']";

    @FindBy(xpath = "//div[@class='button-content' and text()='Ok']")
    WebElement popUpButton;

    private String pageHeader = "//div[@class='prelude-header-title' and text()='Connect Devices']";




    public ConnectDevices() throws Exception {
        waitForElement(By.xpath(popUpHeader));
        log.info("User In Prelude");
        PageFactory.initElements(driver, this);
    }

    public void closeOSupdatePopUp() throws Exception {
        popUpButton.click();
        waitForElement(By.xpath(pageHeader));
    }


}
