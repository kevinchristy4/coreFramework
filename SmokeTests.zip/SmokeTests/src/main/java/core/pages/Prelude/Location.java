package core.pages.Prelude;

import core.driver.BaseDriver;
import core.pages.BasePage;
import core.utils.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.SkipException;

public class Location extends BasePage {

    private Logger log = Logger.getLogger();
    private WebDriver driver = BaseDriver.getDriver();
    private String headerXpath = "//div[@class='prelude-header-title' and text()='Location']";

    @FindBy(xpath = "//label[text()=\"Macy's\"]")
    WebElement macysLocation;

    @FindBy(xpath = "//label[text()=\"Macy's Backstage\"]")
    WebElement BackStageLocation;

    @FindBy(xpath = "//div[text()=\"Next\"]")
    WebElement nextButton;

    public Location() throws Exception {

        waitForElement(By.xpath(headerXpath));
        log.info("User In Prelude");
        PageFactory.initElements(driver, this);
    }

    public enum location{
        MACYS,
        BACKSTAGE
    }

    public void locationSelection(location location){


        switch (location){
            case MACYS: macysLocation.click();
            break;
            case BACKSTAGE: BackStageLocation.click();
            break;
            default: throw new SkipException("Invalid location selected");
        }
        log.info("Location selected");
    }



}
