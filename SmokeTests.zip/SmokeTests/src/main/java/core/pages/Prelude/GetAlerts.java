package core.pages.Prelude;

import core.driver.BaseDriver;
import core.pages.BasePage;
import core.utils.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class GetAlerts extends BasePage {

    private Logger log = Logger.getLogger();
    private WebDriver driver = BaseDriver.getDriver();
    private String pageHeader = "//div[@class='prelude-header-title' and text()='Get Alerts']";
    private String alertsChecked = "//div[contains(@class,'checked')]";
    private String alertsCheckbox = "//input/../label";

    @FindBy(xpath = "//input/../label")
    WebElement alertToggle;


    public GetAlerts() throws Exception {
        waitForElement(By.xpath(pageHeader));
        log.info("User in Alerts page");
        PageFactory.initElements(driver, this);
    }

    public void getAlerts(Boolean status) throws Exception {

        Boolean checkStatus = (!isElementNotDisplayed(By.xpath(alertsChecked)));

        if(!(checkStatus && status)){
            alertToggle.click();
            log.info("Alerts are set to "+ status);
        }
        log.info("Alerts are set to "+ status);
    }
}
