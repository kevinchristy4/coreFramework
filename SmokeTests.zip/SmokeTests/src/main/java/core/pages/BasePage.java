package core.pages;

import core.driver.BaseDriver;
import core.functions.BaseFunc;
import core.utils.Logger;
import core.utils.Parser;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;
import java.util.stream.Collectors;

import static core.driver.BaseDriver.closeBrowser;

public class BasePage extends BaseFunc {

    private Logger log = Logger.getLogger();
    private String signInButtonXpath = "//div[text()='Sign In']";

    public BasePage() throws Exception {
    }


    @BeforeSuite
    public void setChromeDriver(){
        String chromeVersion = "";
//        try {
//            Process process = Runtime.getRuntime().exec("$(Get-Package -Name \"Google Chrome\").Version");
//            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
//            String line;
//            while ((line = reader.readLine()) != null) {
//                chromeVersion = line.trim().split(" ")[2]; // Extract the version part
//                System.out.println(chromeVersion);
//                break;
//            }
//        } catch (IOException e) {
//            e.printStackTrace();
//        }

//        try {
//            ProcessBuilder processBuilder = new ProcessBuilder("powershell.exe","$(Get-Package -Name \"Google Chrome\").Version");
//            Process process = processBuilder.start();
//
//            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
//                List<String> lines = reader.lines().collect(Collectors.toList());
//                System.out.println(lines);
//                if (lines.size() > 0) {
//                    chromeVersion = lines.get(0).trim().split(" ")[2]; // Extract the version part
//                }
//            }
//
//            process.waitFor();
//            System.out.println("chromeVersion");
//            System.out.println(chromeVersion);
//
//        } catch (IOException | InterruptedException e) {
//            e.printStackTrace();
//        }
    }

    @BeforeClass
    @Parameters({"isBloomingdales"})
    public void setupApplication(@Optional("false") Boolean isBloomingdales) throws Exception {
        log.info("Launch Application");
        WebDriver driver = BaseDriver.getDriver();
        System.out.println(Parser.getProperties().getProperty("envURL"));
        driver.get(Parser.getProperties().getProperty("envURL"));
        waitForElement(By.xpath(signInButtonXpath));
        if(isBloomingdales){
            BaseDriver.setLocInfoInBrowserStorage("72","1");
        }
        waitForElement(By.xpath(signInButtonXpath)).click();
    }

    @AfterClass
    public void closeChrome() throws Exception {
        closeBrowser();
    }
}
