package core.functions;

import core.driver.BaseDriver;
import core.utils.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class BaseFunc {

    private WebDriver driver;
    public Logger log = Logger.getLogger();

    private String nextButton = "//div[text()=\"Next\"]";
    private String skipConnectionPrelude = "//div[text()='Skip Connection']";
    private String preferencesIcon = "//a[@description='settings']";



    public BaseFunc() throws Exception {
//        driver = BaseDriver.getDriver();
//        this.driver = driver;
//        PageFactory.initElements(driver, this);
    }

    public WebElement waitForElement(By locator) throws Exception {
        driver = BaseDriver.getDriver();
        WebDriverWait wait =  new WebDriverWait(driver, Duration.ofSeconds(30));
        WebElement waitedElement;
        Object ee = wait.until(driver -> {
            WebElement waitedEle =  wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(locator)));
            if(waitedEle != null && driver.findElement(locator).isDisplayed()){
                return waitedEle;
            }
            return null;
        });
        waitedElement = (WebElement) ee;
        return waitedElement;
    }



    public WebDriverWait waitObj(Duration duration) throws Exception {
        WebDriverWait wait = new WebDriverWait(BaseDriver.getDriver(), duration);
        return wait;
    }

    public void sleep(int sec) throws InterruptedException {
        Thread.sleep(sec*1000);
    }

    public void scrollToBottom() throws Exception {
        ((JavascriptExecutor)BaseDriver.getDriver()).executeScript("window.scrollBy(0,document.body.scrollHeight)");
    }

    public int getNoOfElements(By locator) throws Exception {
        return BaseDriver.getDriver().findElements(locator).size();
    }

    public boolean isElementNotDisplayed(By locator) throws Exception {
        if(getNoOfElements(locator) == 0){
            return true;
        }
        else {
            return false;
        }
    }

    public void clickNext() throws Exception {
        BaseDriver.getDriver().findElement(By.xpath(nextButton)).click();
    }

    public void skipConnectionPrelude() throws Exception {
        BaseDriver.getDriver().findElement(By.xpath(skipConnectionPrelude)).click();
    }

    public void goToPreferences() throws Exception {
        BaseDriver.getDriver().findElement(By.xpath(preferencesIcon)).click();
    }

}
