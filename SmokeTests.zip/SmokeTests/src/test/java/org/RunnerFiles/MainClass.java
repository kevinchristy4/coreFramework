package org.RunnerFiles;

import org.testng.TestNG;
import org.testng.xml.XmlSuite;

import java.util.ArrayList;
import java.util.List;

public class MainClass {

    public static void main(String[] args) {
        TestNG testNG = new TestNG();
        List<String> suites = new ArrayList<>();
        suites.add("src/test/java/org/RunnerFiles/MasterSuite.xml");
        suites.add("src/test/java/org/RunnerFiles/MasterSuiteBLM.xml");
        testNG.setTestSuites(suites);
        testNG.setParallel(XmlSuite.ParallelMode.CLASSES);
        testNG.setSuiteThreadPoolSize(10);
        testNG.run();
    }
}
