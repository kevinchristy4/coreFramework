package org.TestCases;

import core.pages.BasePage;
import core.pages.HomePage;
import core.pages.Preferences;
import core.pages.Prelude.ConnectDevices;
import core.pages.Prelude.GetAlerts;
import core.pages.Prelude.Location;
import core.pages.SignIn;
import core.utils.Logger;
import org.testng.annotations.Test;

public class TC_7_BlmLoginWithAlertsDisabled extends BasePage {

    private Logger log = Logger.getLogger();

    public TC_7_BlmLoginWithAlertsDisabled() throws Exception {
        log.startTest("TC_7_Blm Login With Alerts Disabled");
    }

    @Test
    public void test() throws Exception {
        log.step(1,"Login to OneX");
        new SignIn().login();

        log.step(2,"Disable Alerts for notifications");
        GetAlerts alerts = new GetAlerts();
        alerts.getAlerts(false);
        clickNext();

        log.step(3,"Skip Connect devices page");
        new ConnectDevices().closeOSupdatePopUp();
        skipConnectionPrelude();

        log.step(4,"Verify Username and icons in HomePage");
        HomePage homePage = new HomePage();
        homePage.verifyUserName();
        homePage.verifySearchAndNotificationIconPresent();

        log.step(5,"Go To Preferences and Verify all options are present");
        goToPreferences();
        Preferences preferences = new Preferences();
        preferences.verifyAllOptionsArePresentBLM();

        log.step(6,"Logout");
        preferences.signOut();

        log.endTest("TC_7_Blm Login With Alerts Disabled");
    }
}
