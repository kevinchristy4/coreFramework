package org.TestCases;

import com.google.cloud.bigquery.TableResult;
//import core.pages.BasePage;
import core.utils.BQconnector;
import core.utils.Logger;
import core.utils.Parser;
import core.utils.RestApi;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.IOException;

public class TC_5_EventReceiverApiTest {

    private Logger log = Logger.getLogger();
    private String jsonPayload = "{\"appId\":\"oneX\",\"type\":\"event\",\"eventId\":\"login\",\"traceId\":\"9ad5c61d-5e01-4f21-bc87-3118d77fe84c\",\"sessionId\":\"dcf1701a-8275-4c44-8c4a-9451b758b4ca\",\"division\":71,\"store\":3,\"userId\":7520451,\"deviceId\":\"215CA4E0-2D3A-4AEE-89EE-534F49863BB9\",\"deviceType\":\"CT40\",\"localTime\":\"2023-08-22T13:17:37\",\"timeZone\":\"EST\",\"utcOffset\":\"GMT-04:00\",\"fields\":[{\"field\":\"description\",\"type\":\"string\",\"value\":\"colleague logs in onex application\"},{\"field\":\"os_version\",\"type\":\"string\",\"value\":\"9\"},{\"field\":\"hal_version\",\"type\":\"string\",\"value\":\"6.6.6\"},{\"field\":\"stores_ui_version\",\"type\":\"string\",\"value\":\"1.0.2570\"},{\"field\":\"store_middleware_endpoint\",\"type\":\"string\",\"value\":\"https://onexp-stores-middleware-dev.devops.fds.com/graphql\"},{\"field\":\"ui_endpoint\",\"type\":\"string\",\"value\":\"https://onexp-stores-ui-dev.devops.fds.com\"}]}";
    private String uri = "https://onex-events-receiver-dev.devops.fds.com/analytics/v1/event";
    private String query = "SELECT * FROM `mtech-storesys-np.onex_analytics.onex_events_analytics_dev` WHERE trace_id = \"%1$s\"";
    int maxRetries = 1;
    int retryCount = 0;
    long eventPresent = 0;

    public TC_5_EventReceiverApiTest() {
        log.startTest("TC_5_Event Receiver Api Test");
    }

    @Test
    public void test() throws IOException, InterruptedException {

        log.step(1,"Hit the event receiver api");
        Response response = RestApi.post(uri,jsonPayload);

        log.step(2,"Verify if the transaction is success");
        String traceIDFromApi = Parser.getJsonKeyValue(response.print(),"traceId");
        Assert.assertTrue(response.print().contains("Ok"));

        log.step(3,"Verify in BigQuery the event is present for the trace ID");
        //The code will retry once if event not found in BigQuery

        BQconnector bq = new BQconnector();
        while (retryCount <= maxRetries) {
            TableResult result = bq.executeQuery(String.format(query, traceIDFromApi));
            eventPresent = result.getTotalRows();
            if (eventPresent == 0) {
                if (retryCount < maxRetries) {
                    retryCount++;
                } else {
                    break;
                }
            } else {
                log.info("Event present in BQ");
                break;
            }
        }
        if (eventPresent == 0) {
            throw new Error("Event not present in BigQuery for the traceID = "+traceIDFromApi);
        }

    }

}
