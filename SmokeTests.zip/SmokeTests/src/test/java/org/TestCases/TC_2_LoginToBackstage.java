package org.TestCases;

import core.pages.BasePage;
import core.pages.HomePage;
import core.pages.Preferences;
import core.pages.Prelude.ConnectDevices;
import core.pages.Prelude.GetAlerts;
import core.pages.Prelude.Location;
import core.pages.SignIn;
import core.utils.Logger;
import org.testng.annotations.Test;

public class TC_2_LoginToBackstage extends BasePage {

    private Logger log = Logger.getLogger();

    public TC_2_LoginToBackstage() throws Exception {
        log.startTest("TC_2_Login To Backstage");
    }

    @Test
    public void login() throws Exception {

        log.step(1,"Login to OneX");
        new SignIn().login();

        log.step(2,"Select the location to backstage");
        Location location = new Location();
        location.locationSelection(Location.location.BACKSTAGE);
        clickNext();

        log.step(3,"Enable Alerts for notifications");
        GetAlerts alerts = new GetAlerts();
        alerts.getAlerts(true);
        clickNext();

        log.step(4,"Skip Connect devices page");
        new ConnectDevices().closeOSupdatePopUp();
        skipConnectionPrelude();

        log.step(5,"Verify Username and icons in HomePage");
        HomePage homePage = new HomePage();
        homePage.verifyUserName();
        homePage.verifySearchAndNotificationIconPresent();

        log.step(6,"Go To Preferences and Verify all options are present");
        goToPreferences();
        Preferences preferences = new Preferences();
        preferences.verifyAllOptionsArePresent();

        log.step(7,"Logout");
        preferences.signOut();

        log.endTest("TC_2_Login To Backstage");
    }
}
