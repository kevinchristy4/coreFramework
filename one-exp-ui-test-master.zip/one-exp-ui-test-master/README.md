To DO:

~~- Create a flow to capture stale element error and reinitialize the element from baseFunc or element super class~~
- Run all tests to verify migration is sucessfull
~~- Add functionality to skip version update at start~~

~~- Migrate all enum for events data to json - Follow the example for flm events~~

- Try to login from api,
  - hit secure qa with credentials it will return a token with redirect url
  


-   ~~The driver compatability issue occurs in baseFunc at setCurrentContext() method,
    Add a try catch block and see if you can get the current installed chrome version
    once the version is obtained try to download and place it under the driver folder and restart the test~~

~~-   Convert all Enum to json for maintaining event data~~

~~-   Build a logic to verify session id attached to eventID for flm events~~

-   Separate the test case code and framework code - separated framework code is already available in coreFramework branch