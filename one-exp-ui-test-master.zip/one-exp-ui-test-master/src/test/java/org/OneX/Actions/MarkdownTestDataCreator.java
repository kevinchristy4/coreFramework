package org.OneX.Actions;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.Timestamp;
import com.google.cloud.bigquery.*;
import com.google.cloud.spanner.Mutation;
import com.google.cloud.spanner.ResultSet;
import com.google.cloud.spanner.Statement;
import com.google.cloud.spanner.Value;
import org.core.component.pages.Markdown.MarkdownDbClient;
import org.core.util.MarkDown.ImportDTO;
import org.core.component.pages.Markdown.MarkdownCannotReadFileException;
import org.core.util.MarkDown.AppProperties;
import org.core.util.MarkDown.Constants;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.CSVRecord;

import java.io.*;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
public class MarkdownTestDataCreator {

    private AppProperties appProperties;
    private static final String[] HEADERS = {"division", "location", "upc", "effective_date",
            "prc_stat", "onhand_qty", "tckt_qty","mchHierId","pid","color"};

    public static void main(String[] args) throws FileNotFoundException, IOException {
        new MarkdownTestDataCreator().process();
        System.exit(0);
    }

    private void process() throws FileNotFoundException, IOException {
        appProperties = new AppProperties();
        //connect to spanner
        MarkdownDbClient db = new MarkdownDbClient();
        //read list of files
        String file = readInputFiles();

        System.out.println("processing " + file);
        try {
            List<ImportDTO> rows = readCsvFile(file);
            //queryCatalog(db, rows);
           upsertIntoMarkdown(db, rows);
            //checkUPCsInPricingService(rows);
            writeResultsToCsv(rows);
        } catch (MarkdownCannotReadFileException e) {
            throw new RuntimeException(e);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }finally{
            db.closeConnection();
        }
    }

    private void writeResultsToCsv(List<ImportDTO> rows) throws IOException {
        String outputFile = appProperties.readProperty(AppProperties.OUTPUT_PATH) + File.separator + "MarkDownData/output.csv";
        System.out.println("writing csv to: "+outputFile);
        BufferedWriter writer = Files.newBufferedWriter(Paths.get(outputFile));
        String[] headers = {
                "division", "location", "upc", "isInPricing"
        };

        CSVFormat csvFormat = CSVFormat.DEFAULT.builder()
                .setHeader(headers)
                .build();

        try (final CSVPrinter printer = new CSVPrinter(writer, csvFormat)) {
            rows.forEach(r -> {
                String[] csvRow = {
                        r.getDivision().toString(),
                        r.getLocation().toString(),
                        r.getUpc().toString(),
                        //r.getPresentInPricingService().toString()
                };
                try {
                    printer.printRecord(csvRow);
                    System.out.println("Completed the record insertion in DB and ipdated the output file");
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            });
        }

    }

    private void checkUPCsInPricingService(List<ImportDTO> rows) throws FileNotFoundException {
        BufferedReader reader = new BufferedReader(new FileReader("src/main/resources/query-pag-template.graphql"));
        String queryPAG = String.join(" ", reader.lines().collect(Collectors.toList()));
        String tsQuery = new SimpleDateFormat("yyyy-MM-dd'T'00:00:00").format(Timestamp.now().toDate());
        rows.forEach(r -> {
            String query = queryPAG
                    .replaceAll("@divNbr", r.getDivision().toString())
                    .replaceAll("@locNbr", r.getLocation().toString())
                    .replaceAll("@tsQuery", tsQuery)
                    .replaceAll("@upc", r.getUpc().toString());

            System.out.println(query);

            HttpClient httpClient = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest.newBuilder(
//                        URI.create("https://product-service.cloudrts.net/graphql"))
                            URI.create("https://product-service-qa.devops.fds.com/graphql"))
                    .header("content-type", "application/json")
                    .header("X-Cloud-Trace-Context", "undefined/undefined;o=1")
                    .header("x-client-id", "MCOM")
                    .header("x-selling-client", "Macys")
                    .header("x-sub-client-id", "OneEx")
                    .header("x-trace-id", "956b655b4696486db0d4d7fa860d1755")
                    .POST(HttpRequest.BodyPublishers.ofString(query))
                    .build();
            HttpResponse<String> response = null;
            try {
                response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            } catch (Exception e) {
                throw new RuntimeException(e);
            }

            System.out.println(response.body());

            r.setPresentInPricingService(response.body().contains("\"originalPrice\":"));
        });
    }

    private void queryCatalog(MarkdownDbClient db, List<ImportDTO> rows) throws IOException, InterruptedException {
        System.out.println("Querying Catalog BigQuery to get product information");
        List<String> upcs = rows.stream().map(r -> r.getUpc().toString()).collect(Collectors.toList());
        String upcIn = String.join(",", upcs);
        BufferedReader reader = new BufferedReader(new FileReader("src/main/resources/query-catalog-template.sql"));
        String sql = String.join(" ", reader.lines().collect(Collectors.toList()));
        sql = sql.replace("${UPC_LIST}", upcIn);

        GoogleCredentials credentials = GoogleCredentials.fromStream(new FileInputStream(
                appProperties.readProperty(AppProperties.GCP_APP_USER_CREDENTIALS)
        ));
        BigQuery bigquery = BigQueryOptions.newBuilder()
                .setCredentials(credentials)
                .setProjectId(appProperties.readProperty(AppProperties.PROJECT_NAME)) //<--try setting it here
                .build()
                .getService();
        QueryJobConfiguration queryConfig =
                QueryJobConfiguration.newBuilder(sql)
                        // Use standard SQL syntax for queries.
                        // See: https://cloud.google.com/bigquery/sql-reference/
                        .setUseLegacySql(false)
                        .build();
        JobId jobId = JobId.of(UUID.randomUUID().toString());
        System.out.println("Executing catalog query "+sql);
        Job queryJob = bigquery.create(JobInfo.newBuilder(queryConfig).setJobId(jobId).build());
        while (true) {
            Thread.sleep(5000);
            if (queryJob.isDone()) {
                System.out.println("Query Completed");
                break;
            } else {
                System.out.println("Waiting for the catalog query to be completed");
            }
        }
        // Check for errors
        if (queryJob == null) {
            throw new RuntimeException("Job no longer exists");
        } else if (queryJob.getStatus().getError() != null) {
            // You can also look at queryJob.getStatus().getExecutionErrors() for all
            // errors, not just the latest one.
            throw new RuntimeException(queryJob.getStatus().getError().toString());
        }
        TableResult result = queryJob.getQueryResults();
        FieldList fields = result.getSchema().getFields();
        String[] headers = fields.stream().map(field -> field.getName()).collect(Collectors.toList()).toArray(String[]::new);
        System.out.println(Arrays.toString(headers));
        result.iterateAll().forEach(row -> {
            String[] queryRow = fields.stream().map(f -> row.get(f.getName()).isNull() ? "" : row.get(f.getName()).getStringValue())
                    .collect(Collectors.toList()).toArray(String[]::new);
            System.out.println(Arrays.toString(queryRow));
            /*
            This is the header and a record examoke
            *   [upcnumber, upcmodelnumber, divisionid, gmmId, productdivisionid, departmentid, vendorid, gmmName, productdivisionname, deptname, vendorname, nrfcolordescription, loadedTime, insertid, rownum]
                [196745106562, S38TY02A, 12, 2, 17, 123, 2, READY TO WEAR, CAREER SPORTSWEAR, CK MS SUITSEP, G-Iii Apparel Grp/Calvin Klein, TERRA, 1702871889.02, 196745106562_12_123_2_3804_16723649, 1]
            */
            //MchHierId = divisionNumber + departmentId + vendorId
            String mchHierId = queryRow[2] + "" + queryRow[5] + "" + queryRow[6];
//            String mchHierId = "123";
            rows.forEach(r -> {
                if (r.getUpc().equals(Long.valueOf(queryRow[0]))) {
                    r.setColor(queryRow[11]);
                    r.setMchHierId(mchHierId);
                    r.setPid(queryRow[1]);
                }
            });

            //query a la bd a ver si ese mchhiderid existe
            Statement statement =
                    Statement.newBuilder(
                                    "SELECT MCH_HIER_ID "
                                            + "FROM MKDN_MCH_HIER "
                                            + "WHERE MCH_HIER_ID = @id")
                            .bind("id")
                            .to(Integer.valueOf(mchHierId))
                            .build();
            try (ResultSet resultSet = db.getDbClient().singleUse().executeQuery(statement)) {
                if (!resultSet.next()) {
                    //Doesn't exist. insert mchhier
                    System.out.println("MchHierId: " + mchHierId + " doesn't exists. inserting");
                    insertIntoMchHier(db, Long.valueOf(mchHierId), Long.valueOf(queryRow[2]),
                            Long.valueOf(queryRow[3]), queryRow[7],
                            Long.valueOf(queryRow[4]), queryRow[8],
                            Long.valueOf(queryRow[5]), queryRow[9],
                            Long.valueOf(queryRow[6]), queryRow[10]
                    );
                }
            }

        });
    }

    private void insertIntoMchHier(MarkdownDbClient db, Long mchHierId, Long division, Long gmmId, String gmmDesc,
                                   Long divManId, String divManDesc, Long deptId, String deptDesc,
                                   Long vendorNbr, String vendorDesc) {
        Mutation mutation = Mutation.newInsertBuilder(Constants.MKDN_MCH_HIER_TABLE_NAME)
                .set(Constants.MCH_HIER_ID).to(mchHierId)
                .set(Constants.DIVN_NBR).to(division)
                .set(Constants.GMM_ID).to(gmmId)
                .set(Constants.GMM_DESC).to(gmmDesc)
                .set(Constants.DIV_MAN_ID).to(divManId)
                .set(Constants.DIV_MAN_DESC).to(divManDesc)
                .set(Constants.DEPT_NBR).to(deptId)
                .set(Constants.DEPT_DESC).to(deptDesc)
                .set(Constants.VENDOR_NBR).to(vendorNbr)
                .set(Constants.VENDOR_DESC).to(vendorDesc)
                .set(Constants.RFID_IND).to(Boolean.TRUE)
                .set(Constants.CREATED_BY).to("Markdown Script")
                .set(Constants.CREATED_TS).to(Timestamp.now())
                .set(Constants.UPDATED_BY).to("Markdown Script")
                .set(Constants.UPDATED_TS).to(Value.COMMIT_TIMESTAMP)
                .build();
        db.getDbClient().write(List.of(mutation));
    }

    private void upsertIntoMarkdown(MarkdownDbClient db, List<ImportDTO> rows) {
        System.out.println("Upsert records into " + Constants.MKDN_MARKDOWN_TABLE_NAME);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        List<Mutation> mutations = new ArrayList<>();
        rows.forEach(r -> {
            try {
                Date effectiveDate = sdf.parse(r.getEffectiveDate());
                String markdownId = r.getLocation() + "" + r.getDivision() + "" + r.getUpc();
                mutations.add(
                        Mutation.newInsertOrUpdateBuilder(Constants.MKDN_MARKDOWN_TABLE_NAME)
                                .set(Constants.MCH_HIER_ID).to(r.getMchHierId())
                                .set(Constants.MARKDOWN_ID).to(markdownId)
                                .set(Constants.DIVN_NBR).to(r.getDivision())
                                .set(Constants.LOC_NBR).to(r.getLocation())
                                .set(Constants.UPC).to(r.getUpc())
                                .set(Constants.EFF_DATE).to(r.getEffectiveDate())
                                .set(Constants.PID).to(r.getPid())
                                .set(Constants.COLOR_DESC).to(r.getColor())
                                .set(Constants.NCT_IND).to(Boolean.FALSE)
                                .set(Constants.PRC_STAT).to(r.getPrcStat())
                                .set(Constants.ONHAND_QTY).to(r.getOnHandQty())
                                .set(Constants.TCKT_QTY).to(r.getTcktQty())
                                .set(Constants.IS_CANCEL).to(Boolean.FALSE)
                                .set(Constants.CREATED_BY).to("Markdown Script")
                                .set(Constants.CREATED_TS).to(Timestamp.now())
                                .set(Constants.UPDATED_BY).to("Markdown Script")
                                .set(Constants.UPDATED_TS).to(Value.COMMIT_TIMESTAMP)
                                .set(Constants.DF_UPDATED_TS).to(Timestamp.now())
                                .build());
            } catch (ParseException e) {
                throw new RuntimeException(e);
            }
        });
        log.info("Mutations to write: {}", mutations.size());
        Timestamp ts = db.getDbClient().write(mutations);
        log.info(ts.toString());
    }

    private String readInputFiles() {
        String base = appProperties.readProperty(AppProperties.INPUT_PATH);
        String files = appProperties.readProperty(AppProperties.INPUT_FILE);
        return base + File.separator + files;
    }

    private List<ImportDTO> readCsvFile(String path) throws MarkdownCannotReadFileException {
        List<ImportDTO> rows = new ArrayList<>();
        try {
            Reader in = new FileReader(path);
            CSVFormat csvFormat = CSVFormat.DEFAULT.builder()
                    .setHeader(HEADERS)
                    .setSkipHeaderRecord(true)
                    .build();

            Iterable<CSVRecord> records = csvFormat.parse(in);
            for (CSVRecord record : records) {
                rows.add(new ImportDTO(
                        Integer.valueOf(record.get("division")),
                        Integer.valueOf(record.get("location")),
                        Long.valueOf(record.get("upc")),
                        record.get("effective_date"),
                        Integer.valueOf(record.get("prc_stat")),
                        Integer.valueOf(record.get("onhand_qty")),
                        Integer.valueOf(record.get("tckt_qty")),
                        record.get("mchHierId"),
                        record.get("pid"),
                        record.get("color")
                ));
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            throw new MarkdownCannotReadFileException(e.getMessage());
        } catch (IOException e) {
            e.printStackTrace();
            throw new MarkdownCannotReadFileException(e.getMessage());
        }
        System.out.println("found " + rows.size() + " rows in csv file");
        System.out.println(rows.stream().toString());
        return rows;
    }
}
