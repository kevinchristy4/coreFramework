package org.OneX.Actions;

import com.google.cloud.spanner.ResultSet;
import org.core.util.PropertiesHandler;
import org.core.util.SpannerDB;
import org.core.util.TriggerNotification;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class TriggerNofications {


    @Parameters({"customerName","vehicleType","color","location","DoorPickup"})
    @Test
    public void test(@Optional("VIRATAPU")String customerName,@Optional("SUV") String vehicleType, @Optional("White") String color, @Optional("test") String location, @Optional("true") Boolean DoorPickup) throws Exception{

            SpannerDB db = new SpannerDB();
            db.connectDB(PropertiesHandler.getProperties().getProperty("testEnv"));
            db.updateQuery(new TriggerNotification().getUpdateTokenQuery(customerName));
            ResultSet result = db.selectQuery(new TriggerNotification().getSelectTokenQuery(customerName));
            String customerToken = db.getToken(result, customerName);
            System.out.println(customerToken);
            if (DoorPickup) {
                new TriggerNotification().triggerOnTheWayAndArrivedAtDoor(customerToken);
            } else {
                new TriggerNotification().triggerOnTheWayAndArrivedInCar(customerToken, vehicleType, color, location);
            }
    }

}
