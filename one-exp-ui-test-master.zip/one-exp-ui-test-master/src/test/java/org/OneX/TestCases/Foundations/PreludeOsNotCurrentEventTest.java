package org.OneX.TestCases.Foundations;

import com.google.cloud.bigquery.TableResult;
import org.core.component.BQanalytics;
import org.core.driver.Browserfactory;
import org.core.util.*;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

public class PreludeOsNotCurrentEventTest {

    private Logger log = Logger.getLogger();
    private String eventDataLoc = "src/main/resources/EventsData/FoundationsEvent.json";

    @Test
    public void test() throws Exception {

        new BQanalytics().getLastEntry(PropertiesHandler.getProperties().getProperty("bqUserID"));

        // This test will be executed from browser as it will automatically trigger the popup and event in Prelude
        // TO test from CT40 we need a device with os 9

        log.startTest("Os not current PopUp and Event");

        BrowserController browser = new BrowserController();
        log.info("Login from Browser");
        browser.login();
        browser.completePrelude("MACYS",true);

        log.info("Waiting for events to reach BQ...");
        browser.sleep(15);
        BQanalytics bq = new BQanalytics();
        TableResult results = bq.getCurrentSessionEntries();
        Assert.assertTrue(new BQdataValidator().verifyBrowserEvents(results, EventDataParser.getEventDatafor(eventDataLoc,"OSnotCurrent"),1));
        log.endTest("Os not current PopUp and Event");
    }

    @AfterTest
    public void closeBrowser() throws Exception {
        Browserfactory.closeBrowser();
    }
}
