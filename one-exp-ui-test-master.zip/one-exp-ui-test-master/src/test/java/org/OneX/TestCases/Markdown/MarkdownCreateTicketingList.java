package org.OneX.TestCases.Markdown;

import com.google.cloud.bigquery.TableResult;
import org.core.component.BQanalytics;
import org.core.component.pages.BasePage;
import org.core.component.pages.HomePage;
import org.core.component.pages.Markdown.Ticketing;
import org.core.util.*;
import org.testng.Assert;
import org.testng.annotations.Test;

public class MarkdownCreateTicketingList extends BasePage {

    private Logger log = Logger.getLogger();
    private String eventDataLoc = "src/main/resources/EventsData/MarkdownEvents.json";

    public MarkdownCreateTicketingList() throws Exception {
    }

    @Test
    public void test() throws Exception{
        log.startTest("Markdown Create picklist event test");

        new BQanalytics().getLastEntry(PropertiesHandler.getProperties().getProperty("bqUserID"));

        log.info("User in HomePage");
        HomePage homePage = new HomePage();

        log.info("Go to Merchandising and click Ticketing");
        homePage.selectService(HomePage.serviceOptions.MERCHANDISING);
        homePage.selectServiceSection("Ticketing");

        log.info("Click Create List Button and Navigate back to HomePage");
        skipConnection();
        Ticketing ticketing = new Ticketing();
        ticketing.clickCreateListButton();
        ticketing.verifyTicketingListPage();
        ticketing.clickBackArrow();
        skipConnection();
        ticketing.clickBackArrow();
        new HomePage();

        BQanalytics bq = new BQanalytics();
        TableResult results = bq.getCurrentSessionEntries();
        Assert.assertTrue(new BQdataValidator().verifyEventIsPresentInResults(results, EventDataParser.getEventDatafor(eventDataLoc,"MarkdownTicketingLogin"),1));
        Assert.assertTrue(new BQdataValidator().verifyEventIsPresentInResults(results, EventDataParser.getEventDatafor(eventDataLoc,"MarkdownCreateTicketingList"),1));
        Assert.assertTrue(new BQdataValidator().verifyEventIsPresentInResults(results, EventDataParser.getEventDatafor(eventDataLoc,"MarkdownTicketingLogout"),1));
        log.endTest("Markdown Create picklist event test");


    }

}
