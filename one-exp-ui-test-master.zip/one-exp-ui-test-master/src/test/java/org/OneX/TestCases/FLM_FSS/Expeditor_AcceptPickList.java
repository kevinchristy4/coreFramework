package org.OneX.TestCases.FLM_FSS;

import com.arakelian.faker.model.Person;
import com.arakelian.faker.service.RandomPerson;
import com.google.cloud.bigquery.TableResult;
import org.core.component.BQanalytics;
import org.core.component.pages.BasePage;
import org.core.component.pages.FSS.Expeditor;
import org.core.component.pages.FSS.FSSMain;
import org.core.component.pages.HomePage;
import org.core.util.BQdataValidator;
import org.core.util.EventDataParser;
import org.core.util.Logger;
import org.core.util.PropertiesHandler;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.Test;

public class Expeditor_AcceptPickList extends BasePage {

    HomePage homePage;
    FSSMain fss;
    Expeditor expeditor;

    private Logger log = Logger.getLogger();
    private String[] stockRoomName = {"D6 2200-2899","F2 4500-4999"};
    private String upc = "44209485121";
    private String customerName;
    private String dataFilePath = "src/main/resources/FlmEventsData/fss.json";
    private String startEvent = "fssExpeditorAcceptPickListStart";
    private String endEvent = "fssExpeditorAcceptPickListEnd";


    public Expeditor_AcceptPickList() throws Exception {
    }

    @Test
    public void testAcceptPickList(ITestContext context) throws Exception{

        if(context.getAttribute("customerName")== null){
            Person person = RandomPerson.get().next();
            customerName = person.getFirstName();
        }
        else
            customerName = (String) context.getAttribute("customerName");

        System.out.println("customerName: " + customerName);

        new BQanalytics().getLastEntry(PropertiesHandler.getProperties().getProperty("bqUserID"));

        log.startTest("FSS-FLM Integration: Feature AcceptPickList in Expeditor");

        homePage= new HomePage();

        log.step(1,"Login To FSS");
        homePage.selectService(HomePage.serviceOptions.SHOES_SALES);
        homePage.selectServiceSection(HomePage.serviceOptions.FSS.getString());

        log.step(2,"Select Active Zone");
        fss = new FSSMain();
        fss.selectZone("Active", "FULL");

        log.step(3,"Navigate to Search By upc");
        fss.enterUpc(upc);

        log.step(4,"Add to Customer Bag");
        upc = fss.clickAddToBag();

        if(context.getAttribute("customerName")== null)
            fss.addToCustomerBag(customerName);

        log.step(5,"Send Bag to expeditor");
        fss.sendBag(customerName);

        log.step(6,"Navigate To Expeditor");
        homePage.goToHomePage();
        homePage.selectServiceSection(HomePage.serviceOptions.EXPEDITOR.getString());

        log.step(7,"Select StockRoom");
        expeditor= new Expeditor();
        expeditor.selectStockRoom(stockRoomName);

        log.step(8,"Accept PickList");
        expeditor.acceptAllPicklist();
        expeditor.selectHeaderPill(Expeditor.actionTabs.PICKLIST);

        log.step(9, "Verify events in BQ");
        String[] excludeEvent = {"page tracking","picklist"};
        TableResult result = new BQanalytics().getCurrentSessionEntries(excludeEvent);

        Assert.assertTrue(new BQdataValidator().verifyFLMEvents(result,
                    EventDataParser.getEventDatafor(dataFilePath,startEvent),
                EventDataParser.getEventDatafor(dataFilePath,endEvent),2));

        expeditor.goToHomePage();

        log.endTest("FSS-FLM integration: Feature AcceptPickList in Expeditor");

    }

}
