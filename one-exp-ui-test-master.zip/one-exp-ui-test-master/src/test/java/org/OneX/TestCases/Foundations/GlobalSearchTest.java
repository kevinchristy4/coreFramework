package org.OneX.TestCases.Foundations;

import com.google.cloud.bigquery.TableResult;
import org.core.component.BQanalytics;
import org.core.component.pages.BasePage;
import org.core.component.pages.HomePage;
import org.core.util.*;
import org.testng.Assert;
import org.testng.annotations.Test;


public class GlobalSearchTest extends BasePage
{
    private Logger log = Logger.getLogger();
    private String eventDataLoc = "src/main/resources/EventsData/FoundationsEvent.json";


    public GlobalSearchTest() throws Exception {
    }

    @Test
    public void test() throws Exception {

        log.startTest("Global Search");

        new BQanalytics().getLastEntry(PropertiesHandler.getProperties().getProperty("bqUserID"));

        HomePage homePage = new HomePage();
        homePage.searchWithoutClear("Picking","Fulfillment");
        goToHomePage();
        HomePage homePage1 = new HomePage();
        log.info("Navigating to Search Page");
        homePage1.goToSearch();
        log.info("Exit out of search");
        homePage1.cancelSearch();
        new HomePage();

        sleep(3);

        log.info("Verifying access and exit events for search");
        BQanalytics bq = new BQanalytics();
        TableResult results = bq.getCurrentSessionEntries();

        Assert.assertTrue(new BQdataValidator().verifyEventIsPresentInResults(results, EventDataParser.getEventDatafor(eventDataLoc,"GlobalSearchAccess"),2));
        log.info("Access event is present in BigQuery");
        Assert.assertTrue(new BQdataValidator().verifyEventIsPresentInResults(results, EventDataParser.getEventDatafor(eventDataLoc,"GlobalSearchRedirectPickingMerch"),1));
        Assert.assertTrue(new BQdataValidator().verifyEventIsPresentInResults(results, EventDataParser.getEventDatafor(eventDataLoc,"GlobalSearchExit"),2));

        log.info("Exit event is present in BigQuery");

        log.endTest("Global Search");

    }
}
