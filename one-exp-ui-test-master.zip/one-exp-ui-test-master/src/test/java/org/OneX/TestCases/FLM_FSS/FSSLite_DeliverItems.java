package org.OneX.TestCases.FLM_FSS;

import com.arakelian.faker.model.Person;
import com.arakelian.faker.service.RandomPerson;
import com.google.cloud.bigquery.TableResult;
import org.core.component.BQanalytics;
import org.core.component.pages.BasePage;
import org.core.component.pages.FSS.FSSMain;
import org.core.component.pages.HomePage;
import org.core.component.wait;
import org.core.util.BQdataValidator;
import org.core.util.EventDataParser;
import org.core.util.Logger;
import org.core.util.PropertiesHandler;
import org.testng.Assert;
import org.testng.annotations.Test;

public class FSSLite_DeliverItems extends BasePage {

    private String zoneName = "Tribeca";
    private String zoneType = "LITE";
    private String searchType = "Search By";
    private String gender = "WOMENS";
    private String width = "M";
    private String size = "5";
    private String order = "1";
    private String quantity = "1";
    private String upc;
    private String eventDataLoc = "src/main/resources/FlmEventsData/fss.json";
    private String startEvent = "fssPickListDeliveredStart";
    private String endEvent = "fssPickListDeliveredEnd";

    private Logger log = Logger.getLogger();
    public FSSLite_DeliverItems() throws Exception {
    }

    @Test
    public void FSSLite_DeliverItemsTest() throws Exception{

        Person person = RandomPerson.get().next();
        String customerName = person.getFirstName();
        System.out.println(customerName);
        log.startTest("FSS Lite PickList Delivered");
        log.step(1,"Navigate to Shoe Sales -> FSS");
        HomePage homePage = new HomePage();
        sleep(3);
        homePage.selectService(HomePage.serviceOptions.SHOES_SALES);
        homePage.selectServiceSection(HomePage.serviceOptions.FSS.getString());

        log.step(2,"Select Zone");
        FSSMain fss = new FSSMain();
        fss.selectZone(zoneName,zoneType);

        log.step(3,"Search By Size");
        fss.searchType(searchType);
        fss.searchBySize(gender,width,size);

        log.step(4,"Select first product in the list");
        fss.selectProductByOrder(order);

        log.step(5,"Select shoe quantity");
        fss.selectProductQuantity(quantity);

        log.step(6,"Add to customer bag");
        upc = fss.clickAddToBag();
        fss.addToCustomerBag(customerName);
//        wait.waitForToast();
        log.step(7,"Send bag");
        fss.sendBag(customerName);

        new BQanalytics().getLastEntry(PropertiesHandler.getProperties().getProperty("bqUserID"));

        log.step(8,"Pull item to deliver");
        fss.fssLitePullItem(upc);

        fss.goToHomePage();

        log.step(11,"BQ verifications");
        BQanalytics bq = new BQanalytics();
        String[] excludeEventId = {"page tracking","picklist"};
        TableResult result = bq.getCurrentSessionEntries(excludeEventId);

        Assert.assertTrue(
                new BQdataValidator().verifyFLMEvents(result, EventDataParser.getEventDatafor(eventDataLoc, startEvent),
                        EventDataParser.getEventDatafor(eventDataLoc, endEvent), 2));

        log.endTest("FSS Lite PickList Delivered");


    }
}
