package org.OneX.TestCases.Foundations;

import com.google.cloud.bigquery.TableResult;
import org.core.component.BQanalytics;
import org.core.component.pages.BasePage;
import org.core.component.pages.HomePage;
import org.core.component.pages.Preferences;
import org.core.util.*;
import org.testng.Assert;
import org.testng.annotations.Test;

public class switchDivisionFromPreferences extends BasePage {

    private Logger log = Logger.getLogger();
    private String eventDataLoc = "src/main/resources/EventsData/FoundationsEvent.json";


    public switchDivisionFromPreferences() throws Exception {
    }

    @Test
    public void test() throws Exception {

        log.startTest("Switch division from Preferences page event test");

        new BQanalytics().getLastEntry(PropertiesHandler.getProperties().getProperty("bqUserID"));

        log.step(1,"Navigate to Preferences page");
        HomePage homePage = new HomePage();
        homePage.goToPreferences();
        Preferences preferences = new Preferences();
        log.step(2,"Go to switch division page and switch to Backstage and again from backstage to Macys");
        preferences.switchDivision(Preferences.Division.MACYS_BACKSTAGE);
        preferences.switchDivision(Preferences.Division.MACYS);
        goToHomePage();

//        sleep(7);

        log.step(3,"Verify 2 switch division events are present");
        BQanalytics bq = new BQanalytics();
        TableResult results = bq.getCurrentSessionEntries();
        log.info("Events are present in BigQuery");
        Assert.assertTrue(new BQdataValidator().verifyEventIsPresentInResults(results, EventDataParser.getEventDatafor(eventDataLoc,"SwitchDivisionPref"),1));

        log.endTest("Switch division from Preferences page event test");


    }
}
