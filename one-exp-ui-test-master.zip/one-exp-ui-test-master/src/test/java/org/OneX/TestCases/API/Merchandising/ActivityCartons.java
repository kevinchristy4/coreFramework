package org.OneX.TestCases.API.Merchandising;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import io.restassured.response.Response;
import org.core.util.JsonParserFromFile;
import org.core.util.Logger;
import org.core.util.RestApi;
import org.testng.annotations.AfterClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;
public class ActivityCartons {
    private Logger log = Logger.getLogger();
    private String variableTemplate = "{\"cartonDetailsInput\": { \"locn\": \"%1$s\", \"deliveryTypes\": \"%2$s\", \"resNbrs\": \"%3$s\", \"shpToLocNbrs\": \"%4$s\"}}";
    private String query = "query getActivityCartons($cartonDetailsInput:CartonDetailsInput){\n" +
            "    getActivityCartons(cartonDetailsInput:$cartonDetailsInput){\n" +
            "         cartonNbr\n" +
            "         cartonQty\n" +
            "         deliveryTypeDesc\n" +
            "         resNbr\n" +
            "         deliveryTypeDescResNbr\n" +
            "         shpToLocNbr\n" +
            "         locName\n" +
            "         sendingLocName\n" +
            "         zlStoreNbr\n" +
            "         zlStoreNbrLocation\n" +
            "         activities{\n" +
            "             activityId\n" +
            "             resNbr\n" +
            "             skuUpcNbr\n" +
            "             displayResNbr\n" +
            "             deliveryType\n" +
            "             deliveryTypeDesc\n" +
            "             requestQty\n" +
            "             pickQty\n" +
            "             packQty\n" +
            "             activityStatus\n" +
            "             activityStatusId\n" +
            "             isRfidEnabled\n" +
            "             shpNbr\n" +
            "             locName\n" +
            "             zlStoreNbr\n" +
            "             divNbr\n" +
            "             shpToLocNbr\n" +
            "             displayResNbr\n" +
            "             zlStoreNbrLocation\n" +
            "               product {\n" +
            "               pid\n" +
            "               webId\n" +
            "               productDesc\n" +
            "               brand\n" +
            "               color\n" +
            "               size\n" +
            "               primaryImage {\n" +
            "                 imageUrl\n" +
            "                }\n" +
            "               images {\n" +
            "                 imageUrl\n" +
            "                }\n" +
            "               swatchImage {\n" +
            "                 imageUrl\n" +
            "                }\n" +
            "                upcs\n" +
            "               }\n" +
            "            }\n" +
            "        }\n" +
            "}";
    private String uri = "https://pick-pack-api-qa.devops.fds.com/graphql";
    @DataProvider(name = "myDataProvider")
    public static Object[][] dataProviderMethod() {
        List<JsonObject> datObject = JsonParserFromFile.getDataAsList(JsonParserFromFile.readJsonFromFile("src/test/java/org/OneX/TestData/Actvcartons.json"));
        List<Object[]> testData = new ArrayList<>();
        for (JsonObject key : datObject) {
            String locn = key.get("locationNbr").getAsString();
            String deliveryTypes = key.get("deliveryTypes").getAsString();
            String resNbrs = key.get("resNbrs").getAsString();
            String shpToLocNbrs = key.get("shpToLocNbrs").getAsString();
            testData.add(new Object[]{locn, deliveryTypes, resNbrs, shpToLocNbrs});
        }
        return testData.toArray(new Object[testData.size()][]);
    }
    public ActivityCartons() {
        log.startTest("Start the validate ActivityCartons ");
    }
    @Test(dataProvider = "myDataProvider")
    public void GraphicalVariables(String locn, String deliveryTypes, String resNbrs, String shpToLocNbrs) throws Exception {
        String variable = String.format(variableTemplate, locn, deliveryTypes, resNbrs, shpToLocNbrs);
        Response response = RestApi.postGrapgQlcall(uri,null, variable, query);
        log.info("---------- Scenario: Validate response --------------");
        System.out.println();
        log.info("Hitting the API with the following test data:");
        log.info("location: " + locn);
        log.info("resNbr: " + deliveryTypes);
        log.info("shpToLocNbr: " + resNbrs);
        log.info("shpToLocNbrs: " + shpToLocNbrs);
        System.out.println(response.body().prettyPrint());

    }
    @AfterClass
    private void endTest() {
        log.endTest("ActivityCartons testScenarios");
    }
}