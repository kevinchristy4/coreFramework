package org.OneX.TestCases.FLM_FSS;

import com.arakelian.faker.model.Person;
import com.arakelian.faker.service.RandomPerson;
import com.google.cloud.bigquery.TableResult;
import org.core.component.BQanalytics;
import org.core.component.pages.BasePage;
import org.core.component.pages.FSS.Expeditor;
import org.core.component.pages.FSS.FSSMain;
import org.core.component.pages.HomePage;
import org.core.util.BQdataValidator;
import org.core.util.EventDataParser;
import org.core.util.Logger;
import org.core.util.PropertiesHandler;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.Test;

public class FSS_DeliverItems extends BasePage {

    private Logger log = Logger.getLogger();
    private String zoneName = "Active";
    private String zoneType = "FULL";
    private String searchType = "Search By";
    private String gender = "WOMENS";
    private String width = "M";
    private String size = "5";
    private String order = "1";
    private String quantity = "1";
    private String[] stockRoomName = {"D6 2200-2899","F2 4500-4999"};
    private String upc;
    private String eventDataLoc = "src/main/resources/FlmEventsData/fss.json";
    private String startEvent = "fssExpeditorPickListDeliveredStart";
    private String endEvent = "fssExpeditorPickListDeliveredEnd";
    public FSS_DeliverItems() throws Exception {
    }

    @Test
    public void FLMDeliverItemsTest(ITestContext context) throws Exception {

        Person person = RandomPerson.get().next();
        String customerName = person.getFirstName();

        context.setAttribute("customerName", customerName);
        System.out.println("customerName: " +customerName);

        log.startTest("FLM FSS test - Picklist Delivered event");
        log.step(1,"Navigate to Shoe Sales -> FSS");
        HomePage homePage = new HomePage();
//        sleep(3);
        homePage.selectService(HomePage.serviceOptions.SHOES_SALES);
        homePage.selectServiceSection(HomePage.serviceOptions.FSS.getString());

        log.step(2,"Select Zone");
        FSSMain fss = new FSSMain();
        fss.selectZone(zoneName,zoneType);

        log.step(3,"Search By Size");
        fss.searchType(searchType);
        fss.searchBySize(gender,width,size);

        log.step(4,"Select first product in the list");
        fss.selectProductByOrder(order);

        log.step(5,"Select shoe quantity");
        fss.selectProductQuantity(quantity);

        log.step(6,"Add to customer bag");
        upc = fss.clickAddToBag();
        fss.addToCustomerBag(customerName);

        log.step(7,"Send bag to Expeditor ");
        fss.sendBag(customerName);

        log.step(8,"Navigate to Expeditor");
        fss.goToHomePage();
        HomePage homePage1 = new HomePage();
        homePage1.selectService(HomePage.serviceOptions.SHOES_SALES);
        homePage1.selectServiceSection(HomePage.serviceOptions.EXPEDITOR.getString());
        Expeditor expeditor = new Expeditor();

        log.step(9,"Select stock room");
        expeditor.selectStockRoom(stockRoomName);


        log.step(10,"Accept pick list");
        expeditor.acceptAllPicklist();

        new BQanalytics().getLastEntry(PropertiesHandler.getProperties().getProperty("bqUserID"));
        expeditor.selectHeaderPill(Expeditor.actionTabs.PICKLIST);

        sleep(3);
        log.step(10,"Enter the upc to pull the item");
        upc = expeditor.enterUpcForItems(customerName,quantity);

        log.step(10,"Deliver the item");
        expeditor.clickDeliverItems();
        expeditor.verifyItemInDeliveredSection(customerName,quantity);
        expeditor.goToHomePage();


        log.step(11,"BQ verifications");
        BQanalytics bq = new BQanalytics();
        String[] excludeEventId = {"page tracking","picklist"};
        TableResult result = bq.getCurrentSessionEntries(excludeEventId);

        Assert.assertTrue(
                new BQdataValidator().verifyFLMEvents(result, EventDataParser.getEventDatafor(eventDataLoc, startEvent),
                        EventDataParser.getEventDatafor(eventDataLoc, endEvent), 2));

        log.endTest("FSS-FLM integration: Feature Put Away in Expeditor");

    }
}
