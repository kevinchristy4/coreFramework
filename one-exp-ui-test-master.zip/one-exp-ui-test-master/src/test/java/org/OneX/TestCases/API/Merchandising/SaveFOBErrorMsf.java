package org.OneX.TestCases.API.Merchandising;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import io.restassured.response.Response;
import org.core.util.JsonParserFromFile;
import org.core.util.Logger;
import org.core.util.RestApi;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import java.util.ArrayList;
import java.util.List;
public class SaveFOBErrorMsf  {

    private Logger log = Logger.getLogger();
    private String variable = "{ \"locationNbr\": \"%1$s\", \"workTypeCode\": \"%2$s\", \"deliveryTypes\": %3$s }";
    private String query = "query gmmDetailsForUnassignedAndNotFound($locationNbr:String!,$workTypeCode:String!, $deliveryTypes: [String]!) {\r\n" +
            "  getGMMDetails(gmmDetailsInput:{locationNbr: $locationNbr, workTypeCodes: $workTypeCode, deliveryTypes: $deliveryTypes}) {\r\n" +
            "    gmmName\r\n" +
            "    gmmId\r\n" +
            "    totalQty\r\n" +
            "    resNbrMetaDetails {\r\n" +
            "        resNbr\r\n" +
            "        totalPickQty\r\n" +
            "        totalPackQty\r\n" +
            "        totalRequestQty\r\n" +
            "        deliveryTypeDesc\r\n" +
            "        deliveryTypeDescResNbr\r\n" +
            "    }\r\n" +
            "  }\r\n" +
            "}";
    private String uri = "https://pick-pack-api-qa.devops.fds.com/graphql";


    @DataProvider(name = "myDataProvider")
    public static Object[][] dataProviderMethod() {
        List<JsonObject> datObject = JsonParserFromFile.getDataAsList(JsonParserFromFile.readJsonFromFile("src/test/java/org/OneX/TestData/SaveFOBData.json"));
        List<Object[]> testData = new ArrayList<>();
        for (JsonObject key : datObject) {
            String locationNbr = key.get("locationNbr").getAsString();
            String workTypeCode = key.get("workTypeCode").getAsString();
            JsonArray deliveryTypesArray = key.getAsJsonArray("deliveryTypes");
            List<String> deliveryTypes = new ArrayList<>();
            deliveryTypesArray.forEach(item -> deliveryTypes.add(item.getAsString()));
            testData.add(new Object[]{locationNbr, workTypeCode, deliveryTypes});
        }
        return testData.toArray(new Object[testData.size()][]);
    }

    @Test(dataProvider = "myDataProvider")
    public void JsonResponseDetails(String locationNbr, String workTypeCode, List<String> deliveryTypes) throws Exception {
        System.out.println("\n\nLocation Number: " + locationNbr);
        System.out.println("Work Type Code: " + workTypeCode);
        System.out.println("Department Numbers: " + deliveryTypes);
        String deliveryTypesString = deliveryTypes.toString();
        Response response = RestApi.postGrapgQlcall(uri, null, String.format(variable, locationNbr, workTypeCode, deliveryTypesString), query);
        System.out.println(response.body().prettyPrint());
        JsonObject object = new JsonObject();
        System.out.println("*************************************************\n");
        // Access response data here as needed
        // For example:
        // JsonObject gmmDetails = object.getAsJsonObject("data").getAsJsonObject("getGMMDetails");
        // JsonArray resNbrMetaDetails = gmmDetails.getAsJsonArray("resNbrMetaDetails");
        // Perform validations or further processing as needed
    }
}