package org.OneX.TestCases.API.Merchandising;


import io.restassured.response.Response;
import org.core.util.Logger;
import org.core.util.RestApi;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

public class MerchandiseApiTest {

    private Logger log = Logger.getLogger();
    private String variable = "{ \"locationNbr\": \"10\", \"workTypeCode\": \"101\", \"activityStatusCodes\": \"10,70\" }";
    private String query = "query merchandiseHierarchy($locationNbr:String!,$workTypeCode:String!, $activityStatusCodes: String) {\r\n"
            + "  merchandiseHierarchy(locationNbr:$locationNbr,wrkTypeCd:$workTypeCode, actvtyStatCodes:$activityStatusCodes) {\r\n"
            + "    delvTypCd\r\n" + "    delvTypDesc\r\n" + "    gmmNbr\r\n" + "    gmmName\r\n" + "    deptNbr\r\n"
            + "    deptName\r\n" + "    activeInd\r\n" + "    divManDesc\r\n" + "    divManId\r\n"
            + "    zlDivnNbr\r\n" + "    locName\r\n" + "    \r\n" + "  }\r\n" + "}";
    private String uri = "https://pick-pack-api-qa.devops.fds.com/graphql";


    public MerchandiseApiTest() throws Exception {
    }

    @Test
    public void test() throws Exception{

        Response response = RestApi.postGrapgQlcall(uri,null,variable,query);
       System.out.println(response.body().prettyPrint());
        JSONObject object = new JSONObject(response.getBody().asString());
        System.out.println(object.getJSONObject("data").getJSONArray("merchandiseHierarchy").getJSONObject(0).get("deptNbr"));
//        Assert.assertTrue(object.getJSONObject("data").getJSONArray("merchandiseHierarchy").getJSONObject(0).get("deptNbr").equals(158),"Values did not match");

    }
}
