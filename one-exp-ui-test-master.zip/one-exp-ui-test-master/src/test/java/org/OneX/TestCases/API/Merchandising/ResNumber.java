package org.OneX.TestCases.API.Merchandising;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import org.core.util.JsonParserFromFile;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import org.core.util.Logger;
import org.core.util.RestApi;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import io.restassured.response.Response;


public class ResNumber {


    private Logger log = Logger.getLogger();

    private String locationNbrKey = "locationNbr";
    private String associateIdKey = "associateId";
    private String assignedByAssociateIdKey = "assignedByAssociateId";
    private String resNbrskey="resNbrs";

    private String variable ="{ \"locationNbr\": \"%1$s\", \"associateId\": \"%2$s\", \"assignedByAssociateId\": \"%3$s\", \"resNbrskey\": \"%4$s\"}";

    private String query = "mutation assignResNbr($assignResNbrInput:AssignResNbrInput) {\n" +
            "  assignResNbr(\n" +
            "    assignResNbrInput: $assignResNbrInput\n" +
            "  ) {\n" +
            "    returnCode\n" +
            "    returnMessage\n" +
            "  }\n" +
            "}";
    private String uri = "https://pick-pack-api-qa.devops.fds.com/graphql";
    private String testDataLocation = "src/test/java/org/OneX/TestData/Resnum.json";


    public ResNumber(){
        log.startTest("Vendors Negative Scenarios ");
    }

    @DataProvider(name = "locationData")
    private Object[][] dataProviderMethod() {
        List<JsonObject> datObject = JsonParserFromFile.getDataAsList(JsonParserFromFile.readJsonFromFile(testDataLocation));
        List<Object[]> testData = new ArrayList<>();
        for (JsonObject key : datObject) {

            String locationNbr = key.get(locationNbrKey).getAsString();
            String associateId = key.get(associateIdKey).getAsString();
            String assignedByAssociateId = key.get(assignedByAssociateIdKey).getAsString();
            String resNbrs=key.get(resNbrskey).getAsString();
            testData.add(new Object[]{locationNbr, associateId, assignedByAssociateId,resNbrs});
        }
        return testData.toArray(new Object[testData.size()][]);
    }

    @Test(dataProvider = "locationData")
    public void VendorsNegativeApiTests(String locationNbr, String associateId, String assignedByAssociateId,String resNbrs) throws Exception {
        System.out.println("Location Number: " + locationNbr);
        System.out.println("Work Type Code: " + associateId);
        System.out.println("Department Number: " + assignedByAssociateId);
        System.out.println("resNbrs: "+ resNbrs);
        Response response = RestApi.postGrapgQlcall(uri,null,String.format(variable,locationNbr,associateId,assignedByAssociateId,resNbrs),query);
        System.out.println(response.body().prettyPrint());
    }
    @AfterClass
    private void endTest(){
        log.endTest("Vendors Negative Scenarios");
    }
}

