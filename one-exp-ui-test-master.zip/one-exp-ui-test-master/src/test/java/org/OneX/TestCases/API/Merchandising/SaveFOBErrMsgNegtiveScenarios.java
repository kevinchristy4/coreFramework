package org.OneX.TestCases.API.Merchandising;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import io.restassured.response.Response;
import org.core.util.JsonParserFromFile;
import org.core.util.Logger;
import org.core.util.RestApi;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import java.util.ArrayList;
import java.util.List;

public class SaveFOBErrMsgNegtiveScenarios {
    private Logger log = Logger.getLogger();
    private String variable = "{ \"locationNbr\": \"%1$s\", \"workTypeCodes\": \"%2$s\", \"deliveryTypes\": %3$s }";
    private String query = "query gmmDetailsForUnassignedAndNotFound($locationNbr:String!,$workTypeCodes:String!, $deliveryTypes: [String]!) {\r\n" +
            "  getGMMDetails(gmmDetailsInput:{locationNbr: $locationNbr, workTypeCodes: $workTypeCodes, deliveryTypes: $deliveryTypes}) {\r\n" +
            "    gmmName\r\n" +
            "    gmmId\r\n" +
            "    totalQty\r\n" +
            "    resNbrMetaDetails {\r\n" +
            "        resNbr\r\n" +
            "        totalPickQty\r\n" +
            "        totalPackQty\r\n" +
            "        totalRequestQty\r\n" +
            "        deliveryTypeDesc\r\n" +
            "        deliveryTypeDescResNbr\r\n" +
            "    }\r\n" +
            "  }\r\n" +
            "}";
    private String uri = "https://pick-pack-api-qa.devops.fds.com/graphql";

    @DataProvider(name = "myDataProvider")
    public static Object[][] dataProviderMethod() {
        List<JsonObject> datObject = JsonParserFromFile.getDataAsList(JsonParserFromFile.readJsonFromFile("src/test/java/org/OneX/TestData/SaveFOBData.json"));
        List<Object[]> testData = new ArrayList<>();
        List<String> deliveryTypes = new ArrayList<>();
        for (JsonObject key : datObject) {
            String locationNbr = key.get("locationNbr").getAsString();
            String workTypeCodes = key.get("workTypeCodes").getAsString();
            JsonArray deliveryTypesArray = key.getAsJsonArray("deliveryTypes");
            deliveryTypesArray.forEach(item -> deliveryTypes.add(item.getAsString()));
            testData.add(new Object[]{locationNbr, workTypeCodes, deliveryTypes});
        }
        return testData.toArray(new Object[testData.size()][]);
    }




    public SaveFOBErrMsgNegtiveScenarios(){
        log.startTest("SaveFOB Error Msg Negative Scenarios ");
    }


    @Test(dataProvider = "myDataProvider")
    public void MisssingGraphicalVaribles(String locationNbr, String workTypeCodes, List<String> deliveryTypes) throws Exception {

        Response response = RestApi.postGrapgQlcall(uri, null, String.format(variable, locationNbr, workTypeCodes, deliveryTypes), query);

            String locationNbrerr = "Exception while fetching data (/getGMMDetails) : null";
            String deliveryTypeserr = "Exception while fetching data (/getGMMDetails) : element cannot be mapped to a null key";

            if (locationNbr.isEmpty()) {

                log.info("---------- Scenario: Validate response When location number is missing --------------");
                log.info("Hitting the api with the following test data");
                log.info("Location Number: " + locationNbr);
                log.info("Work Type Code: " + workTypeCodes);
                log.info("deliveryTypes Number: " + deliveryTypes);

                Gson gson = new Gson();
                JsonObject jsonObject = gson.fromJson(response.getBody().asString(), JsonObject.class);

                String message = jsonObject.getAsJsonArray("errors").get(0).getAsJsonObject().get("message").getAsString();
                log.info("Response message: " + message);
                try {
                    Assert.assertTrue(message.contains(locationNbrerr));
                } catch (AssertionError e) {
                    log.error("Expected response: " + locationNbrerr + " || " + "Actual Response: " + message);
                    throw new Exception("Response message does not match ");
                }

            } else if (workTypeCodes.isEmpty()) {

                log.info("---------- Scenario: Validate response When location number is missing --------------");
                log.info("Hitting the api with the following test data");
                log.info("Location Number: " + locationNbr);
                log.info("Work Type Code: " + workTypeCodes);
                log.info("deliveryTypes Number: " + deliveryTypes);

            } else if (deliveryTypes.isEmpty()) {

                log.info("---------- Scenario: Validate response When location number is missing --------------");
                log.info("Hitting the api with the following test data");
                log.info("Location Number: " + locationNbr);
                log.info("Work Type Code: " + workTypeCodes);
                log.info("deliveryTypes Number: " + deliveryTypes);

            Gson gson = new Gson();
            JsonObject jsonObject = gson.fromJson(response.getBody().asString(), JsonObject.class);
            String message = jsonObject.getAsJsonArray("errors").get(0).getAsJsonObject().get("message").getAsString();
            log.info("Response message: " + message);

                try {
                    Assert.assertTrue(message.contains(deliveryTypeserr));
                } catch (AssertionError e) {
                    log.error("Expected response: " + deliveryTypeserr + " || " + "Actual Response: " + message);
                    throw new Exception("Response message does not match ");
                }
            }
    }
}