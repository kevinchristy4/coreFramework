package org.OneX.TestCases.API.Merchandising;

import org.OneX.TestCases.API.Merchandising.MyConnections;
import org.testng.annotations.Test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DataSourceUtil {

    private static MyConnections alcon[]=new MyConnections[30];
    private static int count;
    private static boolean removed;
    private static int conavailable=0;
    //  private static final ThreadLocal<MyConnections> tlocal = new ThreadLocal<MyConnections>();
//
//  static {
//      try {
//          Class.forName("oracle.jdbc.driver.OracleDriver");
//          readCredentialsFromFile("C:\\Users\\ashish.bisht03\\Downloads\\pick-pack-api\\pick-pack-api\\src\\test\\java\\com\\macys\\pickpack");
//      } catch (Exception e) {
//          e.printStackTrace();
//      }
//  }
//  private static void readCredentialsFromFile(String filePath) {
//      try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
//          String line;
//          while ((line = br.readLine()) != null) {
//              String[] parts = line.split(",");
//              String jdbcUrl = parts[0].trim();
//              String username = parts[1].trim();
//              String password = parts[2].trim();
//              for (int i = 0; i < 10; i++) {
//                  Connection con = DriverManager.getConnection(jdbcUrl, username, password);
//                  alcon[i] = new MyConnections(con, i);
//              }
//          }
//      }
//      catch (Exception e) {
//          e.printStackTrace();
//      }
//  }
//

    static {
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            for (int i = 0; i < 10; i++) {
                Connection con1 = DriverManager.getConnection("jdbc:oracle:thin:@WMSSBX01.federated.fds:1521/WMSSBX1F", "FFWSMQA", "ffwsmqa#1");
                alcon[i] = new MyConnections(con1, i);
            }

            for (int i = 10; i < 20; i++) {
                Connection con2 = DriverManager.getConnection("jdbc:oracle:thin:@WMSSBX01.federated.fds:1521/WMSSBX1F", "FFWSMDEV", "ffwsmdev#1");
                alcon[i] = new MyConnections(con2, i);
            }

            for (int i = 20; i < 30; i++) {
                Connection con3 = DriverManager.getConnection("jdbc:oracle:thin:@WMSSBX01.federated.fds:1521/WMSSBX1F", "IWMDSGWSM", "welcome1");
                alcon[i] = new MyConnections(con3, i);
            }
        } catch (Exception e) {
            e.printStackTrace();
            //System.out.println("HELLO DATABASE");
        }
    }

    private static final ThreadLocal<MyConnections> tlocal=new ThreadLocal<MyConnections>();

    public static Connection getCon() {
        if (count < 10) {
            MyConnections con = tlocal.get();
            System.out.println("connection start");
            if (con == null) {
                if (removed) {
                    removed = false;
                    con = alcon[conavailable];
                    tlocal.set(con);
                    count++;
                    return con.getCon();
                } else {
                    con = alcon[count];
                    tlocal.set(con);
                    count++;
                    return con.getCon();
                }
            } else {
                return con.getCon();
            }
        } else {
            System.out.println("No more connections available....");
        }
        return null;
    }



    public static void main(String args[]) {
        DataSourceUtil db = new DataSourceUtil();
        Connection con1 = db.getCon();
        Connection con2 = db.getCon();
        Connection con3 = db.getCon();

        try {
            PreparedStatement stmt1 = con1.prepareStatement("SELECT ACTVTY_ID, sku_upc_nbr, PCK_QTY, ACTVTY_STAT_ID, PACK_QTY, RQST_QTY, loc_nbr FROM ACTVTY WHERE ACTVTY_ID = ?");
            stmt1.setInt(1, 702565982);
            ResultSet rs1 = stmt1.executeQuery();
            while (rs1.next()) {
                System.out.println("ACTVTY_ID: " + rs1.getInt("ACTVTY_ID"));
                System.out.println("sku_upc_nbr: " + rs1.getString("sku_upc_nbr"));
                System.out.println("PCK_QTY: " + rs1.getInt("PCK_QTY"));
                System.out.println("ACTVTY_STAT_ID: " + rs1.getInt("ACTVTY_STAT_ID"));
                System.out.println("PACK_QTY: " + rs1.getInt("PACK_QTY"));
                System.out.println("RQST_QTY: " + rs1.getInt("RQST_QTY"));
                System.out.println("loc_nbr: " + rs1.getString("loc_nbr"));
                System.out.println("*************************************");
            }
            rs1.close();
            stmt1.close();
            PreparedStatement stmt2 = con2.prepareStatement("SELECT ACTVTY_ID, sku_upc_nbr, PCK_QTY, ACTVTY_STAT_ID, PACK_QTY, RQST_QTY, loc_nbr FROM ACTVTY WHERE ACTVTY_ID = ? ");
            stmt2.setInt(1, 607875876);
            ResultSet rs2 = stmt2.executeQuery();
            while (rs2.next()) {
                System.out.println("ACTVTY_ID: " + rs2.getInt("ACTVTY_ID"));
                System.out.println("sku_upc_nbr: " + rs2.getString("sku_upc_nbr"));
                System.out.println("PCK_QTY: " + rs2.getInt("PCK_QTY"));
                System.out.println("ACTVTY_STAT_ID: " + rs2.getInt("ACTVTY_STAT_ID"));
                System.out.println("PACK_QTY: " + rs2.getInt("PACK_QTY"));
                System.out.println("RQST_QTY: " + rs2.getInt("RQST_QTY"));
                System.out.println("loc_nbr: " + rs2.getString("loc_nbr"));
                System.out.println("*************************************");
            }
            rs2.close();
            stmt2.close();


            PreparedStatement stmt3 = con3.prepareStatement("SELECT ACTVTY_ID, sku_upc_nbr, PCK_QTY, ACTVTY_STAT_ID, PACK_QTY, RQST_QTY, loc_nbr FROM ACTVTY WHERE ACTVTY_ID = ?");
            stmt3.setInt(1, 702565988);
            ResultSet rs3 = stmt3.executeQuery();
            while (rs3.next()) {
                System.out.println("*************************************");
                System.out.println("ACTVTY_ID: " + rs3.getInt("ACTVTY_ID"));
                System.out.println("sku_upc_nbr: " + rs3.getString("sku_upc_nbr"));
                System.out.println("PCK_QTY: " + rs3.getInt("PCK_QTY"));
                System.out.println("ACTVTY_STAT_ID: " + rs3.getInt("ACTVTY_STAT_ID"));
                System.out.println("PACK_QTY: " + rs3.getInt("PACK_QTY"));
                System.out.println("RQST_QTY: " + rs3.getInt("RQST_QTY"));
                System.out.println("loc_nbr: " + rs3.getString("loc_nbr"));
                System.out.println("*************************************");
            }
            rs3.close();
            stmt3.close();

        } catch (Exception e) {
            e.printStackTrace();
        }


        db.closeConnection();
        db.closeConnection();
        db.closeConnection();

    }
    private void closeConnection() {


    }
}