package org.OneX.TestCases.FSS;

import com.google.cloud.bigquery.TableResult;
import org.core.component.BQanalytics;
import org.core.component.pages.BasePage;
import org.core.component.pages.HomePage;
import org.core.util.BQdataValidator;
import org.core.util.EventDataParser;
import org.core.util.PropertiesHandler;
import org.testng.Assert;
import org.testng.annotations.Test;

public class FSSLoginLogout extends BasePage {

    private String eventDataLoc = "src/main/resources/EventsData/FssEvents.json";

    public FSSLoginLogout() throws Exception {
    }

    @Test
    public void test() throws Exception {
        new BQanalytics().getLastEntry(PropertiesHandler.getProperties().getProperty("bqUserID"));

        HomePage homePage = new HomePage();
        homePage.selectService(HomePage.serviceOptions.SHOES_SALES);
        homePage.selectServiceSection("Full Service Selling (FSS)");
        homePage.clickBackArrow();


        BQanalytics bq = new BQanalytics();
        TableResult results = bq.getCurrentSessionEntries();

        Assert.assertTrue(new BQdataValidator().verifyEventIsPresentInResults(results, EventDataParser.getEventDatafor(eventDataLoc,"FSSLogin"),1));
        Assert.assertTrue(new BQdataValidator().verifyEventIsPresentInResults(results, EventDataParser.getEventDatafor(eventDataLoc,"FSSLogout"),1));


    }

}
