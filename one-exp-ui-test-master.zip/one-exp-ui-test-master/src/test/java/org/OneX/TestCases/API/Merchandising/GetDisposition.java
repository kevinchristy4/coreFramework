package org.OneX.TestCases.API.Merchandising;
import com.google.gson.JsonObject;
import io.restassured.response.Response;
import org.core.util.JsonParserFromFile;
import org.core.util.Logger;
import org.core.util.RestApi;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import java.util.ArrayList;
import java.util.List;
public class GetDisposition {
    private  Logger log = Logger.getLogger();
    private  String variable="{\"getDispositionRequest\":{\"upc\":\"%1$s\",\"transferType\":\"%2$s\",\"store\":\"%3$s\",\"division\":\"%4$s\"}}";
    private String query ="query getDisposition($getDispositionRequest: GetDispositionRequest!) {\n" +
            "  getDisposition(getDispositionRequest: $getDispositionRequest) {\n" +
            "    getDispositionResult{\n" +
            "    statusInfo {\n" +
            "    code\n" +
            "    source\n" +
            "    sourceDetail\n" +
            "    businessDescription\n" +
            "    technicalDescription\n" +
            "    isError\n" +
            "    serverName\n" +
            "    serviceVersion\n" +
            "    },\n" +
            "    transferLocation,\n" +
            "    businessPayload {\n" +
            "        upc\n" +
            "        itemType\n" +
            "        transactionId\n" +
            "        dispositionMessage\n" +
            "        productDescription{\n" +
            "            fob\n" +
            "            description\n" +
            "            department\n" +
            "            productClass\n" +
            "        }\n" +
            "        priceInfo{\n" +
            "            priceStatus\n" +
            "            ticketedPrice\n" +
            "            priceStatusGroupTypeDesc\n" +
            "        }\n" +
            "        transferDetail{\n" +
            "            documentNumber\n" +
            "            requiredDate\n" +
            "            transferType\n" +
            "        }\n" +
            "    }\n" +
            "  }\n" +
            "  upcDispositionInfo{\n" +
            "      classification{\n" +
            "          brand{\n" +
            "              brandId\n" +
            "              brandName\n" +
            "          }\n" +
            "          vendor{\n" +
            "              vendorId\n" +
            "              vendorName\n" +
            "          }\n" +
            "      }\n" +
            "      inventory{\n" +
            "          availableQuantity\n" +
            "          locationNumber\n" +
            "      }\n" +
            "      productId\n" +
            "      upcName\n" +
            "      upcNumber\n" +
            "      variation{\n" +
            "          sizes{\n" +
            "                 value\n" +
            "                 sizeId\n" +
            "                 seqNum\n" +
            "             }\n" +
            "          colorway{\n" +
            "              additionalImages{\n" +
            "                  imageName\n" +
            "                  seqNumber\n" +
            "              }\n" +
            "              colorName\n" +
            "              primaryImage{\n" +
            "                  imageName\n" +
            "                  seqNumber\n" +
            "              }\n" +
            "              swatchImage{\n" +
            "                  imageName\n" +
            "                  seqNumber\n" +
            "              }\n" +
            "          }\n" +
            "      }\n" +
            "  }\n" +
            "}}";
    private String uri ="https://pick-pack-api-qa.devops.fds.com/graphql";

    @DataProvider(name = "disposition")
    public static  Object[][] dataprovidermethod(){
        List<JsonObject> datObject = JsonParserFromFile.getDataAsList(JsonParserFromFile.readJsonFromFile("src/test/java/org/OneX/TestData/getdisposition.json"));
        List<Object[]> testData = new ArrayList<>();
        for(JsonObject key : datObject){
            String upc = key.get("upc").getAsString();
            String transferType = key.get("transferType").getAsString();
            String store = key.get("store").getAsString();
            String division = key.get("division").getAsString();
            testData.add(new Object[]{upc, transferType, store,division});
        }
        return testData.toArray(new Object[testData.size()][]);
    }
    public GetDisposition() {
        log.startTest("Start the validate CartonNumber ");
    }
    @Test(dataProvider = "disposition")
    public void Getdispstion(String upc,String transferType,String store, String division){
        Response response = RestApi.postGrapgQlcall(uri, null, String.format(variable, upc, transferType, store,division), query);
//        System.out.println(response.body().prettyPrint());
        log.info("---------- Scenario: Validate response --------------");
        log.info("upc:" + upc);
        log.info("transferType:"+ transferType);
        log.info("store: "+ store);
        log.info("division: "+division);
        System.out.println(response.body().prettyPrint());
    }

}
