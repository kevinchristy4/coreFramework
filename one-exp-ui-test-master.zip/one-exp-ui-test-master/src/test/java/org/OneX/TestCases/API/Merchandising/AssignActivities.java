package org.OneX.TestCases.API.Merchandising;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import io.restassured.response.Response;
import org.core.util.JsonParserFromFile;
import org.core.util.Logger;
import org.core.util.RestApi;
import org.testng.annotations.AfterClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

public class AssignActivities {
    private Logger log = Logger.getLogger();
    private String variableTemplate = "{\"assignActivityInput\": { \"locationNbr\": \"%1$s\", \"associateId\": \"%2$s\", \"assignedByAssociateId\": \"%3$s\", \"activityIds\": \"%4$s\"}}";
    private String query = "mutation assignActivity($assignActivityInput:AssignActivityInput) {\n" +
            "  assignActivity(\n" +
            "    assignActivityInput: $assignActivityInput\n" +
            "  ) {\n" +
            "    returnCode\n" +
            "    returnMessage\n" +
            "  }\n" +
            "}\n";
    private String uri = "https://pick-pack-api-qa.devops.fds.com/graphql";
    @DataProvider(name = "myDataProvider")
    public static Object[][] dataProviderMethod() {
        List<JsonObject> datObject = JsonParserFromFile.getDataAsList(JsonParserFromFile.readJsonFromFile("src/test/java/org/OneX/TestData/Actvcartons.json"));
        List<Object[]> testData = new ArrayList<>();
        for (JsonObject key : datObject) {
            String locationNbr = key.get("locationNbr").getAsString();
            String associateId = key.get("associateId").getAsString();
            String assignedByAssociateId = key.get("assignedByAssociateId").getAsString();
            String activityIds = key.get("activityIds").getAsString();


            testData.add(new Object[]{locationNbr, associateId, assignedByAssociateId, activityIds});
        }
        return testData.toArray(new Object[testData.size()][]);
    }
    public AssignActivities() {
        log.startTest("Start the validate PackActivitySkuNbrs ");
    }
    @Test(dataProvider = "myDataProvider")
    public void GraphicalVariables(String locationNbr, String associateId, String assignedByAssociateId, String activityIds) throws Exception {
        String variable = String.format(variableTemplate, locationNbr, associateId, assignedByAssociateId, activityIds);
        Response response = RestApi.postGrapgQlcall(uri,null, variable, query);
        log.info("---------- Scenario: Validate response --------------");
        System.out.println();
        log.info("Hitting the API with the following test data:");
        log.info("locationnbr: " + locationNbr);
        log.info("associateId: " + associateId);
        log.info("assignedByAssociateId: " + assignedByAssociateId);
        log.info("activityIds: " + activityIds);

        System.out.println(response.body().prettyPrint());
    }
    @AfterClass
    private void endTest() {
        log.endTest("PackActivitySkuNbrs testScenarios");
    }
}