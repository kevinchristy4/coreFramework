package org.OneX.TestCases.FLM_FSS;

import com.arakelian.faker.model.Person;
import com.arakelian.faker.service.RandomPerson;
import org.core.component.BQanalytics;
import org.core.component.pages.BasePage;
import org.core.component.pages.HomePage;
import org.core.component.pages.FSS.Expeditor;
import org.core.component.pages.FSS.FSSMain;
import org.core.util.BQdataValidator;
import org.core.util.EventDataParser;
import org.core.util.Logger;
import org.core.util.PropertiesHandler;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.Test;
import com.google.cloud.bigquery.TableResult;

public class Expeditor_NotFound extends BasePage {

    private Logger log = Logger.getLogger();
    private String zoneName = "Active";
    private String zoneType = "FULL";
    private String quantity = "1";
    private String customerName;
    private String[] stockRoomName = {"F2 4500-4999", "D6 2200-2899"};
    private String upc = "44208122683";
    private String dataFilePath = "src/main/resources/FlmEventsData/fss.json";
    private String startEvent = "fssExpeditorNotFoundStart";
    private String endEvent = "fssExpeditorNotFoundEnd";

    public Expeditor_NotFound() throws Exception {
        super();
    }

    @Test
    public void expeditorNotFound(ITestContext context) throws Exception {

        if(context.getAttribute("customerName")== null){
            Person person = RandomPerson.get().next();
            customerName = person.getFirstName();
        }
        else
            customerName = (String) context.getAttribute("customerName");

        System.out.println("customerName: " + customerName);

        log.startTest("FSS-FLM integration: Feature Item Not Found in Expeditor");

        log.step(1, "Navigate to Shoe Sales -> FSS");
        HomePage homePage = new HomePage();
        homePage.selectService(HomePage.serviceOptions.SHOES_SALES);
        homePage.selectServiceSection(HomePage.serviceOptions.FSS.getString());

        log.step(2, "Select Zone");
        FSSMain fss = new FSSMain();
        fss.selectZone(zoneName, zoneType);

        log.step(3, "Search By UPC");
        fss.searchByUPC(upc);

        log.step(5, "Select shoe quantity");
        fss.selectProductQuantity(quantity);

        log.step(6, "Add to customer bag");
        upc = fss.clickAddToBag();

        if(context.getAttribute("customerName")== null)
            fss.addToCustomerBag(customerName);

        log.step(7, "Send bag to Expeditor ");
        fss.sendBag(customerName);

        log.step(8, "Navigate to Expeditor");
        fss.goToHomePage();
        HomePage homePage1 = new HomePage();
        homePage1.selectService(HomePage.serviceOptions.SHOES_SALES);
        homePage1.selectServiceSection(HomePage.serviceOptions.EXPEDITOR.getString());
        Expeditor expeditor = new Expeditor();

        log.step(9, "Select stock room");
        expeditor.selectStockRoom(stockRoomName);

        log.step(10, "Accept pick list");
        expeditor.acceptAllPicklist();
        expeditor.selectHeaderPill(Expeditor.actionTabs.PICKLIST);

        log.step(11, "Mark item as Not Found");
        expeditor.expeditorMarkItemAsNotFound(customerName);

        log.step(12, "Verify events in BQ");
        String[] excludeEvent = {"page tracking", "picklist"};
        TableResult result = new BQanalytics().getCurrentSessionEntries(excludeEvent);

        Assert.assertTrue(
            new BQdataValidator().verifyFLMEvents(result, EventDataParser.getEventDatafor(dataFilePath, startEvent),
                EventDataParser.getEventDatafor(dataFilePath, endEvent), 2));

        expeditor.goToHomePage();

        log.endTest("FSS-FLM integration: Feature Put Away in Expeditor");

    }


}
