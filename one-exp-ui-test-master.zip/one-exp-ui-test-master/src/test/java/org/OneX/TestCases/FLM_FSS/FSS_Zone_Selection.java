package org.OneX.TestCases.FLM_FSS;

import com.google.cloud.bigquery.TableResult;
import org.core.component.BQanalytics;
import org.core.component.pages.BasePage;
import org.core.component.pages.FSS.FSSMain;
import org.core.component.pages.HomePage;
import org.core.util.*;
import org.testng.Assert;
import org.testng.annotations.Test;

public class FSS_Zone_Selection extends BasePage {

    private Logger log = Logger.getLogger();
    private String dataFilePath = "src/main/resources/FlmEventsData/fss.json";
    private String startEvent = "flmFssZoneSelectionStart";
    private String endEvent = "flmFssZoneSelectionEnd";

    public FSS_Zone_Selection() throws Exception {
    }

    @Test
    public void testZoneSelection() throws Exception {

        new BQanalytics().getLastEntry(PropertiesHandler.getProperties().getProperty("bqUserID"));

        log.startTest("FSS Zone Selection test");

        log.info("Navigating to Zone Selection- FULL");

        HomePage homePage = new HomePage();

        log.info("Select Shoe sales in landing page");
        homePage.selectService(HomePage.serviceOptions.SHOES_SALES);

        log.info("Select FSS");
        homePage.selectServiceSection(HomePage.serviceOptions.FSS.getString());

        FSSMain fssMain = new FSSMain();

        log.info("wait for other events to reach BQ");
        sleep(5);
        new BQanalytics().getLastEntry(PropertiesHandler.getProperties().getProperty("bqUserID"));

        log.info("Select Active Zone");
        fssMain.selectZone("Active", "FULL");

        log.info("Verify events in BQ");
        String[] excludeEvent = {"page tracking"};
        TableResult result = new BQanalytics().getCurrentSessionEntries(excludeEvent);

        Assert.assertTrue(new BQdataValidator().verifyFLMEvents(result, EventDataParser.getEventDatafor(dataFilePath, startEvent), EventDataParser.getEventDatafor(dataFilePath, endEvent), 2));

        log.info("Navigating to Zone Selection - LITE");

        homePage.goToHomePage();
        homePage.selectServiceSection(HomePage.serviceOptions.FSS.getString());

        log.info("wait for other events to reach BQ");
        sleep(5);
        new BQanalytics().getLastEntry(PropertiesHandler.getProperties().getProperty("bqUserID"));

        log.info("Select Tribeca Zone");
        fssMain.selectZone("Tribeca", "LITE");

        log.info("Verify events in BQ");
        String[] excludeEventLite = {"page tracking"};
        TableResult resultLite = new BQanalytics().getCurrentSessionEntries(excludeEventLite);

        Assert.assertTrue(new BQdataValidator().verifyFLMEvents(resultLite, EventDataParser.getEventDatafor(dataFilePath, startEvent), EventDataParser.getEventDatafor(dataFilePath, endEvent), 2));

        fssMain.goToHomePage();
        log.endTest("FSS Zone Selection test");

    }

}
