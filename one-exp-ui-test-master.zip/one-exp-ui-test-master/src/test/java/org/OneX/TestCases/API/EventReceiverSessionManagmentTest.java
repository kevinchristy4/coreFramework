package org.OneX.TestCases.API;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import org.core.driver.Browserfactory;
import org.core.util.BrowserController;
import org.core.util.Logger;
import org.core.util.PropertiesHandler;
import org.core.util.RestApi;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class EventReceiverSessionManagmentTest {

    int initialSessions = 0;
    int sessionsAfterLogin = 0;
    int sessionsAfterLogout = 0;
    private Logger log = Logger.getLogger();


    // In the future if any other test case requires this method - Create a separate class for Event receiver under util folder and move the method
    private int getActiveSession(String eventReceicerInfoEndPoint){
        Response Innitialresponse = RestApi.get(eventReceicerInfoEndPoint);
        JsonPath jsonPath = Innitialresponse.jsonPath();
        return Integer.parseInt(jsonPath.get("activeRedisSession").toString());
    }

    @Parameters("EventReceiverApi")
    @Test
    public void test(String eventReceicerEnv) throws Exception {

        log.startTest("Session Management Test");

        initialSessions = getActiveSession(eventReceicerEnv);
        log.info("Active sessions before login = "+initialSessions);

        BrowserController browser = new BrowserController();
        log.info("Login from Browser");
        browser.login();
        browser.completePrelude("MACYS",true);

        log.info("Waiting for Redis to update...");

        for(int i=0;i<3;i++){
            browser.sleep(20);
            sessionsAfterLogin = getActiveSession(eventReceicerEnv);
            if(sessionsAfterLogin > initialSessions){
                log.info("Active sessions After login = "+sessionsAfterLogin);
                log.info("Session counts increased after login");
                break;
            }
            log.info("Session counts not updated...retrying for 60 seconds");
        }

        log.info("Logout from Browser");
        browser.logout();

        log.info("Waiting for Redis to update...");
        for(int i=0;i<3;i++){
            browser.sleep(20);
            sessionsAfterLogout = getActiveSession(eventReceicerEnv);
            if(sessionsAfterLogin > sessionsAfterLogout){
                log.info("Active sessions After logout = "+sessionsAfterLogout);
                log.info("Session counts decreased after login");
                break;
            }
            log.info("Session counts not updated...retrying for 60 seconds");
        }

        log.endTest("Session Management Test");

    }

    @AfterTest
    public void closeBrowser() throws Exception {
        Browserfactory.closeBrowser();
    }
}
