package org.OneX.TestCases.API.Merchandising;


import java.sql.Connection;

public class MyConnections {

    private Connection con;

    private int count;
    public MyConnections(Connection con,int count) {
        this.con=con;
        this.count=count;
    }
    public final Connection getCon() {
        return con;
    }
    public final void setCon(Connection con) {
        this.con = con;
    }
    public final int getCount() {
        return count;
    }
    public final void setCount(int count) {
        this.count = count;
    }
    public int getDbNumber() {
        // TODO Auto-generated method stub
        return 0;
    }
}
