package org.OneX.TestCases.Fulfillment;

import com.google.cloud.bigquery.TableResult;
import org.core.component.BQanalytics;
import org.core.component.pages.BasePage;
import org.core.component.pages.Fulfillment.Picking;
import org.core.component.pages.HomePage;
import org.core.util.*;
import org.testng.Assert;
import org.testng.annotations.Test;

public class FulfillmentLoginAndLogout extends BasePage {

    private Logger log = Logger.getLogger();
    private String section = "Picking";
    private String eventDataLoc = "src/main/resources/EventsData/FulfillmentEvent.json";


    public FulfillmentLoginAndLogout() throws Exception {
    }

    @Test
    public void test() throws Exception{
        log.startTest("Fulfillment entry/exit event test");

        new BQanalytics().getLastEntry(PropertiesHandler.getProperties().getProperty("bqUserID"));

        HomePage homePage = new HomePage();
        homePage.selectService(HomePage.serviceOptions.FULFILLMENT);
        homePage.selectServiceSection(section);
        Picking picking = new Picking();
        picking.skipConnection();
        picking.clickBackArrow();

        new HomePage();

//        HomePage homePage1 = new HomePage();
//        homePage1.selectService(HomePage.serviceOptions.FULFILLMENT);
//        homePage1.selectServiceSection(section);
//        Picking picking1 = new Picking();
//        picking1.saveAllZones();
//        picking1.goToHomePage();


//        HomePage homePage2 = new HomePage();
//        homePage2.selectService(HomePage.serviceOptions.FULFILLMENT);
//        homePage2.selectServiceSection(section);
//        Picking picking2 = new Picking();
//        picking2.saveAllZones();
//        picking2.goToPreferences();

//        Preferences preferences = new Preferences();
//        preferences.goToHomePage();

        BQanalytics bq = new BQanalytics();
        TableResult results = bq.getCurrentSessionEntries();
        Assert.assertTrue(new BQdataValidator().verifyEventIsPresentInResults(results, EventDataParser.getEventDatafor(eventDataLoc,"FulfillmentPickingLogin"),1));
        Assert.assertTrue(new BQdataValidator().verifyEventIsPresentInResults(results, EventDataParser.getEventDatafor(eventDataLoc,"FulfillmentPickingLogout"),1));

        log.endTest("Fulfillment entry/exit event test");
    }

}
