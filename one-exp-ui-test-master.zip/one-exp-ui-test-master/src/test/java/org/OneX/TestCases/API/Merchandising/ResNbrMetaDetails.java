package org.OneX.TestCases.API.Merchandising;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import io.restassured.response.Response;
import org.core.util.JsonParserFromFile;
import org.core.util.Logger;
import org.core.util.RestApi;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

public class ResNbrMetaDetails {

    private Logger log = Logger.getLogger();
    private String query = "query resNbrMetaDetails($resNbrMetaDetails:ResNbrDetailsInput!) {\n" +
            "  getResNbrMetaDetails(resNbrDetailsInput:$resNbrMetaDetails) {\n" +
            "    resNbr\n" +
            "    totalPickQty\n" +
            "    totalPackQty\n" +
            "    totalRequestQty\n" +
            "    deliveryTypeDesc\n" +
            "    deliveryTypeDescResNbr\n" +
            "    locName\n" +
            "    zlStoreNbr\n" +
            "    shpToLocNbr\n" +
            "    zlStoreNbrLocation \n" +
            "  }\n" +
            "}";
    private String uri = "https://pick-pack-api-qa.devops.fds.com/graphql";

    @DataProvider(name = "myDataProvider")
    public static Object[][] dataProviderMethod() {
        List<JsonObject> dataObject = JsonParserFromFile.getDataAsList(JsonParserFromFile.readJsonFromFile("src/test/java/org/OneX/TestData/Resnum.json"));
        List<Object[]> testData = new ArrayList<>();
        for (JsonObject key : dataObject) {
            String locationNbr = key.get("locationNbr").getAsString();
            String workTypeCodes = key.get("workTypeCodes").getAsString();
            List<String> deliveryTypes = new ArrayList<>();
            JsonArray deliveryTypeArray = key.getAsJsonArray("deliveryTypes");
            deliveryTypeArray.forEach(item -> deliveryTypes.add(item.getAsString()));
            List<String> activityStatCodes = new ArrayList<>();
            JsonArray activityStatCodesArray = key.getAsJsonArray("activityStatCodes");
            activityStatCodesArray.forEach(item -> activityStatCodes.add(item.getAsString()));
            String groupBy = key.get("groupBy").getAsString();
            String filter = key.get("filter").getAsString();
            testData.add(new Object[]{locationNbr, workTypeCodes, deliveryTypes, activityStatCodes, groupBy, filter});
        }
        return testData.toArray(new Object[testData.size()][]);
    }

//    public ResNbrMetaDetails() {
//        log.startTest("Start the validate ResNbrMetaDetails");
//    }

    private void logAndValidateResponse(Response response) {
    }

    @Test(dataProvider = "myDataProvider")
    public void validateNCT(String locationNbr, String workTypeCodes, List<String> deliveryTypes, List<String> activityStatCodes, String groupBy, String filter) throws Exception {
        JsonObject variables = prepareVariables(locationNbr, workTypeCodes, deliveryTypes, activityStatCodes, groupBy, filter);
        String requestBody = new Gson().toJson(variables);
        Response response = RestApi.postGrapgQlcall(uri, null, requestBody, query);
        // logAndValidateResponse(response, locationNbr, workTypeCodes, deliveryTypes.toString(), activityStatCodes.toString(), groupBy, filter);
        logAndValidateResponse(response);
        JsonObject responseData = new Gson().fromJson(response.body().asString(), JsonObject.class);
        JsonArray resNbrMetaDetailsArray = responseData.getAsJsonObject("data").getAsJsonArray("getResNbrMetaDetails");
        validateNCTDeliveryType(resNbrMetaDetailsArray);
    }

    @Test(dataProvider = "myDataProvider")
    public void validateCDP(String locationNbr, String workTypeCodes, List<String> deliveryTypes, List<String> activityStatCodes, String groupBy, String filter) throws Exception {
        JsonObject variables = prepareVariables(locationNbr, workTypeCodes, deliveryTypes, activityStatCodes, groupBy, filter);
        String requestBody = new Gson().toJson(variables);
        Response response = RestApi.postGrapgQlcall(uri, null, requestBody, query);
        logAndValidateResponse(response, locationNbr, workTypeCodes, deliveryTypes.toString(), activityStatCodes.toString(), groupBy, filter);
        logAndValidateResponse(response);
        JsonObject responseData = new Gson().fromJson(response.body().asString(), JsonObject.class);
        JsonArray resNbrMetaDetailsArray = responseData.getAsJsonObject("data").getAsJsonArray("getResNbrMetaDetails");
        validateCDPDeliveryType(resNbrMetaDetailsArray);
    }


    @Test(dataProvider = "myDataProvider")
    public void validateRTV(String locationNbr, String workTypeCodes, List<String> deliveryTypes, List<String> activityStatCodes, String groupBy, String filter) throws Exception {
        JsonObject variables = prepareVariables(locationNbr, workTypeCodes, deliveryTypes, activityStatCodes, groupBy, filter);
        String requestBody = new Gson().toJson(variables);
        Response response = RestApi.postGrapgQlcall(uri, null, requestBody, query);
        logAndValidateResponse(response);
        JsonObject responseData = new Gson().fromJson(response.body().asString(), JsonObject.class);
        JsonArray resNbrMetaDetailsArray = responseData.getAsJsonObject("data").getAsJsonArray("getResNbrMetaDetails");
        validateRTVDeliveryType(resNbrMetaDetailsArray);
    }

    private JsonObject prepareVariables(String locationNbr, String workTypeCodes, List<String> deliveryTypes, List<String> activityStatCodes, String groupBy, String filter) {
        JsonObject variables = new JsonObject();
        JsonObject resNbrMetaDetails = new JsonObject();
        resNbrMetaDetails.addProperty("locationNbr", locationNbr);
        resNbrMetaDetails.addProperty("workTypeCodes", workTypeCodes);
        JsonArray deliveryTypesArray = new JsonArray();
        deliveryTypes.forEach(deliveryTypesArray::add);
        resNbrMetaDetails.add("deliveryTypes", deliveryTypesArray);
        JsonArray activityStatCodesArray = new JsonArray();
        activityStatCodes.forEach(activityStatCodesArray::add);
        resNbrMetaDetails.add("activityStatCodes", activityStatCodesArray);
        resNbrMetaDetails.addProperty("groupBy", groupBy);
        resNbrMetaDetails.addProperty("filter", filter);
        variables.add("resNbrMetaDetails", resNbrMetaDetails);
        return variables;
    }

    private void logAndValidateResponse(Response response, String locationNbr, String workTypeCodes, String deliveryTypes, String activityStatCodes, String groupBy, String filter) {
        log.info("---------- Scenario: Validate response --------------");
        System.out.println();
        log.info("Hitting the api with the following test data");
        log.info("LocationNbr: " + locationNbr);
        log.info("workTypeCodes: " + workTypeCodes);
        log.info("deliveryTypes: " + deliveryTypes);
        log.info("activityStatCodes: " + activityStatCodes);
        log.info("groupBy: " + groupBy);
        log.info("filter: " + filter);

        System.out.println(response.prettyPrint());
        //log.info("Response data is printed" + response.body().asString());
    }
@Test
    private void validateNCTDeliveryType(JsonArray resNbrMetaDetailsArray) {
        for (JsonElement element : resNbrMetaDetailsArray) {
            JsonObject detail = element.getAsJsonObject();
            String deliveryTypeDesc = detail.get("deliveryTypeDesc").getAsString();
            if ("NCT".equals(deliveryTypeDesc)) {
                String resNbr = detail.has("resNbr") && !detail.get("resNbr").isJsonNull() ? detail.get("resNbr").getAsString() : null;
                String shpToLocNbr = detail.has("shpToLocNbr") && !detail.get("shpToLocNbr").isJsonNull() ? detail.get("shpToLocNbr").getAsString() : null;
                Assert.assertNull(resNbr, "When deliveryTypeDesc is NCT, resNbr should be null");
                Assert.assertTrue(shpToLocNbr != null && shpToLocNbr.matches("\\d+"), "When deliveryTypeDesc is NCT, shpToLocNbr should have numeric value");
                log.info("NCT validation passed: resNbr is null and shpToLocNbr is numeric.");
            }
        }
    }
    @Test
    private void validateCDPDeliveryType(JsonArray resNbrMetaDetailsArray) {
        for (JsonElement element : resNbrMetaDetailsArray) {
            JsonObject detail = element.getAsJsonObject();
            String deliveryTypeDesc = detail.get("deliveryTypeDesc").getAsString();
            if ("CDP".equals(deliveryTypeDesc)) {
                String resNbr = detail.has("resNbr") && !detail.get("resNbr").isJsonNull() ? detail.get("resNbr").getAsString() : null;
                String shpToLocNbr = detail.has("shpToLocNbr") && !detail.get("shpToLocNbr").isJsonNull() ? detail.get("shpToLocNbr").getAsString() : null;
                Assert.assertNull(shpToLocNbr, "When deliveryTypeDesc is CDP, shpToLocNbr should be null");
                Assert.assertTrue(resNbr != null && resNbr.matches("\\d+"), "When deliveryTypeDesc is CDP, resNbr should have numeric value");
                log.info("CDP validation passed: shpToLocNbr is null and resNbr is numeric.");
            }
        }
    }
@Test
    private void validateRTVDeliveryType(JsonArray resNbrMetaDetailsArray) {
        for (JsonElement element : resNbrMetaDetailsArray) {
            JsonObject detail = element.getAsJsonObject();
            String deliveryTypeDesc = detail.get("deliveryTypeDesc").getAsString();
            if ("RTV".equals(deliveryTypeDesc)) {
                String resNbr = detail.has("resNbr") && !detail.get("resNbr").isJsonNull() ? detail.get("resNbr").getAsString() : null;
                String shpToLocNbr = detail.has("shpToLocNbr") && !detail.get("shpToLocNbr").isJsonNull() ? detail.get("shpToLocNbr").getAsString() : null;
                Assert.assertNull(shpToLocNbr, "When deliveryTypeDesc is RTV, shpToLocNbr should be null");
                Assert.assertTrue(resNbr != null && resNbr.matches("\\d+"), "When deliveryTypeDesc is RTV, resNbr should have numeric value");
                log.info("RTV validation passed: shpToLocNbr is null and resNbr is numeric.");
            }
        }
    }

    @AfterClass
    private void endTest() {
        log.endTest("ResNbrMetaDetails testScenarios");
    }
}






//package org.OneX.TestCases;
//
//import com.google.gson.Gson;
//import com.google.gson.JsonArray;
//import com.google.gson.JsonObject;
//import io.restassured.response.Response;
//import org.core.util.JsonParserFromFile;
//import org.core.util.Logger;
//import org.core.util.RestApi;
//import org.json.JSONArray;
//import org.json.JSONObject;
//import org.testng.Assert;
//import org.testng.annotations.AfterClass;
//import org.testng.annotations.DataProvider;
//import org.testng.annotations.Test;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import static org.junit.Assert.assertNotNull;
//import static org.testng.Assert.assertNull;
//
//public class ResNbrMetaDetails {
//    private Logger log = Logger.getLogger();
//    private String query = "query resNbrMetaDetails($resNbrMetaDetails:ResNbrDetailsInput!) {\n" +
//            "  getResNbrMetaDetails(resNbrDetailsInput:$resNbrMetaDetails) {\n" +
//            "    resNbr\n" +
//            "    totalPickQty\n" +
//            "    totalPackQty\n" +
//            "    totalRequestQty\n" +
//            "    deliveryTypeDesc\n" +
//            "    deliveryTypeDescResNbr\n" +
//            "    locName\n" +
//            "    zlStoreNbr\n" +
//            "    shpToLocNbr\n" +
//            "    zlStoreNbrLocation \n" +
//            "  }\n" +
//            "}";
//    private String uri = "https://pick-pack-api-qa.devops.fds.com/graphql";
//
//    @DataProvider(name = "myDataProvider")
//    public static Object[][] dataProviderMethod() {
//        List<JsonObject> dataObject = JsonParserFromFile.getDataAsList(JsonParserFromFile.readJsonFromFile("src/test/java/org/OneX/TestData/ResNum.json"));
//        List<Object[]> testData = new ArrayList<>();
//
//        for (JsonObject key : dataObject) {
//            String locationNbr = key.get("locationNbr").getAsString();
//            String workTypeCodes = key.get("workTypeCodes").getAsString();
//
//            List<String> deliveryTypes = new ArrayList<>();
//            JsonArray deliveryTypeArray = key.getAsJsonArray("deliveryTypes");
//            deliveryTypeArray.forEach(item -> deliveryTypes.add(item.getAsString()));
//
//            List<String> activityStatCodes = new ArrayList<>();
//            JsonArray activityStatCodesArray = key.getAsJsonArray("activityStatCodes");
//            activityStatCodesArray.forEach(item -> activityStatCodes.add(item.getAsString()));
//
//            String groupBy = key.get("groupBy").getAsString();
//            String filter = key.get("filter").getAsString();
//
//            testData.add(new Object[]{locationNbr, workTypeCodes, deliveryTypes, activityStatCodes, groupBy, filter});
//        }
//        return testData.toArray(new Object[testData.size()][]);
//    }
//
//    public ResNbrMetaDetails() {
//        log.startTest("Start the validate ResNbrMetaDetails");
//    }
//
//    @Test(dataProvider = "myDataProvider")
//    public void ResNbr(String locationNbr, String workTypeCodes, List<String> deliveryTypes, List<String> activityStatCodes, String groupBy, String filter) throws Exception {
//        JsonObject variables = new JsonObject();
//        JsonObject resNbrMetaDetails = new JsonObject();
//        resNbrMetaDetails.addProperty("locationNbr", locationNbr);
//        resNbrMetaDetails.addProperty("workTypeCodes", workTypeCodes);
//
//        JsonArray deliveryTypesArray = new JsonArray();
//        deliveryTypes.forEach(deliveryTypesArray::add);
//        resNbrMetaDetails.add("deliveryTypes", deliveryTypesArray);
//
//        JsonArray activityStatCodesArray = new JsonArray();
//        activityStatCodes.forEach(activityStatCodesArray::add);
//        resNbrMetaDetails.add("activityStatCodes", activityStatCodesArray);
//
//        resNbrMetaDetails.addProperty("groupBy", groupBy);
//        resNbrMetaDetails.addProperty("filter", filter);
//        variables.add("resNbrMetaDetails", resNbrMetaDetails);
//
//        String requestBody = new Gson().toJson(variables);
//
//        Response response = RestApi.postGrapgQlcall(uri, null, requestBody, query);
//        log.info("---------- Scenario: Validate response --------------");
//        System.out.println();
//        log.info("Hitting the api with the following test data");
//        log.info("LocationNbr: " + locationNbr);
//        log.info("workTypeCodes: " + workTypeCodes);
//        log.info("deliveryTypes: " + deliveryTypes);
//        log.info("activityStatCodes: " + activityStatCodes);
//        log.info("groupBy: " + groupBy);
//        log.info("filter: " + filter);
//        System.out.println(response.prettyPrint());
//        log.info("Response data is printed" + response.body().asString());
//    }
//
//    @Test(dataProvider = "myDataProvider")
//    public void validation(String locationNbr, String workTypeCodes, List<String> deliveryTypes, List<String> activityStatCodes, String groupBy, String filter){
//        JsonObject variables = new JsonObject();
//        JsonObject resNbrMetaDetails = new JsonObject();
//        resNbrMetaDetails.addProperty("locationNbr", locationNbr);
//        resNbrMetaDetails.addProperty("workTypeCodes", workTypeCodes);
//
//        JsonArray deliveryTypesArray = new JsonArray();
//        deliveryTypes.forEach(deliveryTypesArray::add);
//        resNbrMetaDetails.add("deliveryTypes", deliveryTypesArray);
//
//        JsonArray activityStatCodesArray = new JsonArray();
//        activityStatCodes.forEach(activityStatCodesArray::add);
//        resNbrMetaDetails.add("activityStatCodes", activityStatCodesArray);
//
//        resNbrMetaDetails.addProperty("groupBy", groupBy);
//        resNbrMetaDetails.addProperty("filter", filter);
//        variables.add("resNbrMetaDetails", resNbrMetaDetails);
//
//        String requestBody = new Gson().toJson(variables);
//        Response response = RestApi.postGrapgQlcall(uri, null, requestBody, query);
//
//        JSONObject responseObject = new JSONObject(response.getBody().asString());
//        JSONArray dataArray = responseObject.getJSONObject("data").getJSONArray("getResNbrMetaDetails");
//
//        for (int i = 0; i < dataArray.length(); i++) {
//            JSONObject item = dataArray.getJSONObject(i);
//            if (item.isNull("resNbr")) {
//                System.out.println("deliveryTypeDesc :"+ item.get("deliveryTypeDesc"));
//            } else if (item.getString("resNbr").startsWith("521202")) {
//                System.out.println("deliveryTypeDesc :"+ item.get("deliveryTypeDesc"));
//            }
//        }
//    }
//    @AfterClass
//    private void endTest() {
//        log.endTest("ResNbrMetaDetails testScenarios");
//    }
//}
