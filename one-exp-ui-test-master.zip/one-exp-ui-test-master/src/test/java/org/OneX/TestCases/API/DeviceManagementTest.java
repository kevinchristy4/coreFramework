package org.OneX.TestCases.API;

import com.google.gson.JsonObject;
import io.restassured.response.Response;
import lombok.Data;
import org.core.component.pages.BasePage;
import org.core.driver.onexApp;
import org.core.util.JsonParserFromFile;
import org.core.util.Logger;
import org.core.util.PropertiesHandler;
import org.core.util.RestApi;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static io.restassured.RestAssured.requestSpecification;

public class DeviceManagementTest {

    public DeviceManagementTest() throws Exception {
    }

    private Logger log = Logger.getLogger();
    private String testDataLocation = "src/main/resources/DMA_endpoints/env_endpoints.json";

    @DataProvider(name = "endpoints")
    private Object[][] getUri(){
        List<JsonObject> datObject = JsonParserFromFile.getDataAsList(JsonParserFromFile.readJsonFromFile(testDataLocation));
        List<Object[]> testData = new ArrayList<>();
        for (JsonObject key : datObject) {
            String env = key.keySet().iterator().next();
            String health = key.getAsJsonObject(env).get("health").getAsString();
            String getVersion = key.getAsJsonObject(env).get("getVersion").getAsString();
            String getVersionInvalidApi = key.getAsJsonObject(env).get("getVersionInvalidApi").getAsString();
            testData.add(new Object[]{env, health, getVersion,getVersionInvalidApi});
        }
        System.out.println(testData);
        return testData.toArray(new Object[testData.size()][]);
    }



    @Test(dataProvider = "endpoints")
    public void HealthAndVersionCheck(String env, String health, String versionUri, String versionInvalidUri) {

        if(!env.equals("prod") && !env.equals("perf")){
            versionUri = String.format(versionUri,PropertiesHandler.getProperties().getProperty("deviceID"));
            versionInvalidUri = String.format(versionInvalidUri,PropertiesHandler.getProperties().getProperty("deviceID"));
        }

        log.startTest("Device Management API Tests, Env - "+env);


        log.step(1,"Health Info Test");
        Response response= RestApi.get(health);

        log.step(2,"Verify response status code is 200");
        int statusCode= response.getStatusCode();
        Assert.assertEquals(statusCode, 200 , "Status code is not as expected");
        log.info("Api response is valid");

        log.step(3,"Verify apk version api");
        response= RestApi.get(versionUri);

        log.step(4,"Verify response status code is 200");
        statusCode= response.getStatusCode();
        Assert.assertEquals(statusCode, 200 , "Status code is not as expected - Actual code:"+statusCode);
        log.info("Api response is valid");

        log.step(5,"Verify invalid apk version api");
        response= RestApi.get(versionInvalidUri);

        log.step(6,"Verify response status code is 404");
        statusCode= response.getStatusCode();
        Assert.assertEquals(statusCode, 404 , "Status code is not as expected - Actual code:"+statusCode);
        log.info("Api response is valid");


        log.endTest("Device Management API");

    }

}
