package org.OneX.TestCases.PickPack;

import com.google.cloud.bigquery.TableResult;
import org.core.component.BQanalytics;
import org.core.component.pages.BasePage;
import org.core.component.pages.HomePage;
import org.core.util.*;
import org.testng.Assert;
import org.testng.annotations.Test;

public class PickPack_LoginLogout extends BasePage {

    private Logger log = Logger.getLogger();
    private String picking = "Picking";
    private String packing = "Packing";
    private String eventDataLoc = "src/main/resources/EventsData/PickPackEvent.json";


    public PickPack_LoginLogout() throws Exception {
    }

    @Test
    public void test() throws Exception {

        log.startTest("Picking and Packing - Login and Logout event test");

        new BQanalytics().getLastEntry(PropertiesHandler.getProperties().getProperty("bqUserID"));

        HomePage homePage = new HomePage();
        homePage.selectService(HomePage.serviceOptions.MERCHANDISING);
        homePage.selectServiceSection(picking);
        skipConnection();
        clickBackArrow();
        new HomePage();
        homePage.selectService(HomePage.serviceOptions.MERCHANDISING);
        homePage.selectServiceSection(picking);
        skipConnection();
        goToHomePage();
        new HomePage();
        homePage.selectService(HomePage.serviceOptions.MERCHANDISING);
        homePage.selectServiceSection(picking);
        skipConnection();
        goToPreferences();
        goToHomePage();

        new HomePage();
        homePage.selectService(HomePage.serviceOptions.MERCHANDISING);
        homePage.selectServiceSection(packing);
        skipConnection();
        clickBackArrow();
        new HomePage();
        homePage.selectService(HomePage.serviceOptions.MERCHANDISING);
        homePage.selectServiceSection(packing);
        skipConnection();
        goToHomePage();
        new HomePage();
        homePage.selectService(HomePage.serviceOptions.MERCHANDISING);
        homePage.selectServiceSection(packing);
        skipConnection();
        goToPreferences();
        goToHomePage();

        BQanalytics bq = new BQanalytics();
        TableResult results = bq.getCurrentSessionEntries();
        Assert.assertTrue(new BQdataValidator().verifyEventIsPresentInResults(results, EventDataParser.getEventDatafor(eventDataLoc,"PickingLogin"),3));
        Assert.assertTrue(new BQdataValidator().verifyEventIsPresentInResults(results, EventDataParser.getEventDatafor(eventDataLoc,"PickingLogout"),3));
        Assert.assertTrue(new BQdataValidator().verifyEventIsPresentInResults(results, EventDataParser.getEventDatafor(eventDataLoc,"PackingLogin"),3));
        Assert.assertTrue(new BQdataValidator().verifyEventIsPresentInResults(results, EventDataParser.getEventDatafor(eventDataLoc,"PackingLogout"),3));

        log.endTest("Picking and Packing - Login and Logout event test");


    }
}
