package org.OneX.TestCases.FLM_FSS;

import com.google.cloud.bigquery.TableResult;
import org.core.component.BQanalytics;
import org.core.component.pages.BasePage;
import org.core.component.pages.FSS.Expeditor;
import org.core.component.pages.HomePage;
import org.core.util.BQdataValidator;
import org.core.util.EventDataParser;
import org.core.util.Logger;
import org.core.util.PropertiesHandler;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Expeditor_Login extends BasePage {

    private Logger log = Logger.getLogger();
    private String dataFilePath = "src/main/resources/FlmEventsData/fss.json";
    private String startEvent = "fssExpeditorLoginStart";
    private String endEvent = "fssExpeditorLoginEnd";

    public Expeditor_Login() throws Exception {
    }

    @Test
    public void expeditorLogin() throws Exception {

        log.startTest("Expeditor Login test");

        log.info("Navigate to homepage");
        HomePage homePage = new HomePage();

        log.info("Select shoe sales");
        homePage.selectService(HomePage.serviceOptions.SHOES_SALES);

        log.info("Select Expeditor");
        new BQanalytics().getLastEntry(PropertiesHandler.getProperties().getProperty("bqUserID"));
        homePage.selectServiceSection(HomePage.serviceOptions.EXPEDITOR.getString());

        log.info("Verify if events are presents in BQ");
        Expeditor expeditor = new Expeditor();

        String[] excludeEvent = {"page tracking","picklist"};
        TableResult result = new BQanalytics().getCurrentSessionEntries(excludeEvent);

        Assert.assertTrue(new BQdataValidator().verifyFLMEvents(result, EventDataParser.getEventDatafor(dataFilePath, startEvent), EventDataParser.getEventDatafor(dataFilePath, endEvent), 2));
        expeditor.goToHomePage();
        log.endTest("Expeditor Login test");


    }
}
