package org.OneX.TestCases.Foundations;

import com.google.cloud.bigquery.TableResult;
import org.core.component.BQanalytics;
import org.core.component.pages.BasePage;
import org.core.component.pages.HomePage;
import org.core.component.pages.Preferences;
import org.core.util.*;
import org.testng.Assert;
import org.testng.annotations.Test;

public class AppInfoAndReleaseNotesTest extends BasePage {

    private Logger log = Logger.getLogger();
    private String division = String.format("Macy's (%1$s)",PropertiesHandler.getProperties().getProperty("division"));
    private String storeNum = PropertiesHandler.getProperties().getProperty("store");
    private String userID = PropertiesHandler.getProperties().getProperty("bqUserID");
    private String userName = "Performance";
    private String url = PropertiesHandler.getProperties().getProperty("envURL");
    private String location = PropertiesHandler.getProperties().getProperty("location");
    private String eventDataLoc = "src/main/resources/EventsData/FoundationsEvent.json";


    public AppInfoAndReleaseNotesTest() throws Exception {
    }

    @Test
    public void test() throws Exception{

        log.startTest("Application Info and Release Notes - UI and entry/exit event test");

        new BQanalytics().getLastEntry(PropertiesHandler.getProperties().getProperty("bqUserID"));

        log.step(1,"Navigate to Preferences page");
        HomePage homePage = new HomePage();
        homePage.goToPreferences();
        Preferences preferences = new Preferences();

        log.step(2,"Go to Application Info page");
        preferences.clickOnOption(Preferences.options.applicationinfo);
        log.step(3,"Verify app info page against the config set at start up");
        preferences.verifyAppInfo(division,storeNum,location,userID,userName,null,null,url,null);
        clickBackArrow();
        new Preferences().goToHomePage();


        log.step(6,"Verify entry/exit for both App info and release notes are present in BigQuery");
        BQanalytics bq = new BQanalytics();
        TableResult results = bq.getCurrentSessionEntries();
        Assert.assertTrue(new BQdataValidator().verifyEventIsPresentInResults(results, EventDataParser.getEventDatafor(eventDataLoc,"AppInfoEntry"),1));
        Assert.assertTrue(new BQdataValidator().verifyEventIsPresentInResults(results, EventDataParser.getEventDatafor(eventDataLoc,"AppInfoExit"),1));
        log.info("All expected events are present");

        log.endTest("Application Info and Release Notes - UI and entry/exit event test");

    }
}
