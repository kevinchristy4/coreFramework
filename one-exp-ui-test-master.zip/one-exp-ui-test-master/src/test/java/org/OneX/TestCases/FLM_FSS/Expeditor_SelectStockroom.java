package org.OneX.TestCases.FLM_FSS;

import com.google.cloud.bigquery.TableResult;
import org.core.component.BQanalytics;
import org.core.component.pages.BasePage;
import org.core.component.pages.FSS.Expeditor;
import org.core.component.pages.HomePage;
import org.core.util.BQdataValidator;
import org.core.util.EventDataParser;
import org.core.util.Logger;
import org.core.util.PropertiesHandler;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Expeditor_SelectStockroom extends BasePage {

    HomePage homePage;
    Expeditor expeditor;

    private Logger log = Logger.getLogger();
    private String[] stockRoomName = {"D6 2200-2899","F2 4500-4999"};
    private String startEvent = "fssExpeditorStockroomSelectStart";
    private String endEvent = "fssExpeditorStockroomSelectEnd";
    private String dataFilePath = "src/main/resources/FlmEventsData/fss.json";


    public  Expeditor_SelectStockroom() throws Exception{
     }

     @Test
     public void testSelectStockRoom() throws Exception {

         new BQanalytics().getLastEntry(PropertiesHandler.getProperties().getProperty("bqUserID"));

         log.startTest("FSS-FLM integration: Feature SelectStockRoom in Expeditor");

        homePage= new HomePage();

        log.step(1, "Navigate to ShoeSales");
        homePage.selectService(HomePage.serviceOptions.SHOES_SALES);

        log.step(2, "Click on Expeditor");
        homePage.selectServiceSection(HomePage.serviceOptions.EXPEDITOR.getString());

        log.step(3,"Select StockRoom");
        expeditor= new Expeditor();
        expeditor.selectStockRoom(stockRoomName);

        log.step(4, "Verify events in BQ");
        String[] excludeEvent = {"page tracking","picklist"};
        TableResult result = new BQanalytics().getCurrentSessionEntries(excludeEvent);

         Assert.assertTrue(new BQdataValidator().verifyFLMEvents(result,
                         EventDataParser.getEventDatafor(dataFilePath,startEvent),
                         EventDataParser.getEventDatafor(dataFilePath,endEvent),2));

         expeditor.goToHomePage();

         log.endTest("FSS-FLM integration: Feature SelectStockRoom in Expeditor");
     }
}
