package org.OneX.TestCases.FLM_FSS;

import com.arakelian.faker.model.Person;
import com.arakelian.faker.service.RandomPerson;
import org.core.component.BQanalytics;
import org.core.component.pages.BasePage;
import org.core.component.pages.HomePage;
import org.core.component.pages.FSS.FSSMain;
import org.core.util.BQdataValidator;
import org.core.util.EventDataParser;
import org.core.util.Logger;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.Test;
import com.google.cloud.bigquery.TableResult;

public class FSS_NotFound extends BasePage {
    
    HomePage homePage;
    FSSMain fss;
    
    private Logger log = Logger.getLogger();
    private String zoneName = "Tribeca";
    private String zoneType = "LITE";
    private String upc = "19841273436";
    private String quantity = "1";
    private String customerName;
    private String startEvent = "fssNotFoundStart";
    private String endEvent = "fssNotFoundEnd";
    private String dataFilePath = "src/main/resources/FlmEventsData/fss.json";

    public FSS_NotFound() throws Exception {
        super();
    }
    
    @Test
    public void fssLiteNotFound(ITestContext context) throws Exception {

        if(context.getAttribute("customerName")== null){
            Person person = RandomPerson.get().next();
            customerName = person.getFirstName();
        }
        else
            customerName = (String) context.getAttribute("customerName");

        System.out.println("customerName: " + customerName);
    
        log.startTest("FSS-FLM integration: Feature Item Not Found in FSS Lite Store");

        log.step(1, "Navigate to Shoe Sales -> FSS");
        HomePage homePage = new HomePage();
        homePage.selectService(HomePage.serviceOptions.SHOES_SALES);
        homePage.selectServiceSection(HomePage.serviceOptions.FSS.getString());

        log.step(2, "Select Zone");
        FSSMain fss = new FSSMain();
        fss.selectZone(zoneName, zoneType);

        log.step(3, "Search By Upc");
        fss.searchByUPC(upc);

        log.step(5, "Select shoe quantity");
        fss.selectProductQuantity(quantity);

        log.step(6, "Add to customer bag");
        upc = fss.clickAddToBag();

        if(context.getAttribute("customerName")== null)
            fss.addToCustomerBag(customerName);

        log.step(7, "Send bag");
        fss.sendBag(customerName);
        
        log.step(8, "Mark item as Not Found");
        fss.fssNotFound();
        
        log.step(9, "Verify events in BQ");
        String[] excludeEvent = {"page tracking", "picklist"};
        TableResult result = new BQanalytics().getCurrentSessionEntries(excludeEvent);

        Assert.assertTrue(
            new BQdataValidator().verifyFLMEvents(result, EventDataParser.getEventDatafor(dataFilePath, startEvent),
                EventDataParser.getEventDatafor(dataFilePath, endEvent), 2));

        fss.goToHomePage();

        log.endTest("FSS-FLM integration: Feature Item Not Found in FSS Lite Store");
        
    }

}
