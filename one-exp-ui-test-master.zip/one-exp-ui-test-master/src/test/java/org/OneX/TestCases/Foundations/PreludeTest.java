package org.OneX.TestCases.Foundations;

import org.core.component.BQanalytics;
import org.core.component.pages.BasePage;
import org.core.component.pages.Prelude;
import org.core.driver.onexApp;
import org.core.util.Logger;
import org.core.util.PropertiesHandler;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class PreludeTest extends BasePage {

    private Logger log = Logger.getLogger();
    private String eventDataLoc = "src/main/resources/EventsData/FoundationsEvent.json";


    public PreludeTest() throws Exception {
    }

    @Parameters({"location","alerts"})
    @Test
    public void test(Prelude.location location,Boolean alerts) throws Exception {

        new Prelude().verifyPreludeEvents(true);

//        new onexApp().getEventsCount();

    }
}
