package org.OneX.TestCases.Foundations;

import com.google.cloud.bigquery.TableResult;
import org.core.component.BQanalytics;
import org.core.component.pages.BasePage;
import org.core.component.pages.HomePage;
import org.core.component.pages.Preferences;
import org.core.util.*;
import org.testng.Assert;
import org.testng.annotations.Test;

public class OrderPickAlertsTest extends BasePage {

    private Logger log = Logger.getLogger();
    private String eventDataLoc = "src/main/resources/EventsData/FoundationsEvent.json";


    public OrderPickAlertsTest() throws Exception {
    }

    @Test
    public void test() throws Exception{

        //Run this in a separate test method in xml to make the alerts disabled at prelude
        log.startTest("Order Pickup enable and disable test");

        BQanalytics bqPrelude = new BQanalytics();
        TableResult resultsPrelude = bqPrelude.getCurrentSessionEntries();
        Assert.assertTrue(new BQdataValidator().verifyEventIsPresentInResults(resultsPrelude, EventDataParser.getEventDatafor(eventDataLoc,"UnsubscribeToNotificationPrelude"),1));
        new BQanalytics().getLastEntry(PropertiesHandler.getProperties().getProperty("bqUserID"));

        HomePage homePage = new HomePage();
        String alertStatus = homePage.checkStatusOrDisableAlerts_HP(false);
        Assert.assertTrue(alertStatus.equals("false"));

        goToPreferences();
        Preferences preferences = new Preferences();
        preferences.clickOnOption(Preferences.options.alerts);
        preferences.toggleAlerts(true);
        preferences.clickBackPref();
        preferences.goToHomePage();

        new HomePage();
        homePage.checkStatusOrDisableAlerts_HP(true);
        goToPreferences();

        new Preferences();
        preferences.clickOnOption(Preferences.options.alerts);
        preferences.toggleAlerts(true);
        preferences.clickBackPref();
        preferences.goToHomePage();

        BQanalytics bq = new BQanalytics();
        TableResult results = bq.getCurrentSessionEntries();
        Assert.assertTrue(new BQdataValidator().verifyEventIsPresentInResults(results, EventDataParser.getEventDatafor(eventDataLoc,"UnsubscribeToNotificationPrelude"),1));
        Assert.assertTrue(new BQdataValidator().verifyEventIsPresentInResults(results, EventDataParser.getEventDatafor(eventDataLoc,"SubscribeToNotificationPreference"),2));
        log.endTest("Order Pickup enable and disable test");

    }
}
