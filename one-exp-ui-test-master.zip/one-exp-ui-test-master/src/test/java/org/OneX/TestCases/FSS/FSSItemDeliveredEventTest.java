package org.OneX.TestCases.FSS;

import com.google.cloud.bigquery.TableResult;
import org.core.component.BQanalytics;
import org.core.component.pages.BasePage;
import org.core.component.pages.FSS.Expeditor;
import org.core.component.pages.FSS.FSSMain;
import org.core.component.pages.HomePage;
import org.core.util.*;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.Map;

public class FSSItemDeliveredEventTest extends BasePage {

    private Logger log = Logger.getLogger();
    private String zoneName = "Active";
    private String zoneType = "FULL";
    private String searchType = "Search By";
    private String gender = "WOMENS";
    private String width = "M";
    private String size = "5";
    private String order = "1";
    private String quantity = "1";
    private String customerName = "Maximus";
    private String[] stockRoomName = {"D6 2200-2899"};
    private String upc;
    private String eventDataLoc = "src/main/resources/EventsData/FssEvents.json";



    public FSSItemDeliveredEventTest() throws Exception {
    }

    @Test
    public void test() throws Exception{

        new BQanalytics().getLastEntry(PropertiesHandler.getProperties().getProperty("bqUserID"));

        log.startTest("FSS test - Picklist Delivered full flow from FSS to Expeditor");
        log.step(1,"Navigate to Shoe Sales -> FSS");
        HomePage homePage = new HomePage();
        homePage.selectService(HomePage.serviceOptions.SHOES_SALES);
        homePage.selectServiceSection(HomePage.serviceOptions.FSS.getString());

        log.step(2,"Select Zone");
        FSSMain fss = new FSSMain();
        fss.selectZone(zoneName,zoneType);

        log.step(3,"Search By Size");
        fss.searchType(searchType);
        fss.searchBySize(gender,width,size);

        log.step(4,"Select first product in the list");
        fss.selectProductByOrder(order);

        log.step(5,"Select shoe quantity");
        fss.selectProductQuantity(quantity);

        log.step(6,"Add to customer bag");
        upc = fss.clickAddToBag();
        fss.addToCustomerBag(customerName);

        log.step(7,"Send bag to Expeditor ");
        fss.sendBag(customerName);

        log.step(8,"Navigate to Expeditor");
        fss.goToHomePage();
        HomePage homePage1 = new HomePage();
        homePage1.selectService(HomePage.serviceOptions.SHOES_SALES);
        homePage1.selectServiceSection(HomePage.serviceOptions.EXPEDITOR.getString());
        Expeditor expeditor = new Expeditor();

        log.step(9,"Select stock room");
        expeditor.selectStockRoom(stockRoomName);

        log.step(10,"Accept pick list");
        expeditor.acceptAllPicklist();
        expeditor.selectHeaderPill(Expeditor.actionTabs.PICKLIST);

        log.step(10,"Enter the upc to pull the item");
        upc = expeditor.enterUpcForItems(customerName,quantity);

        log.step(10,"Deliver the item");
        expeditor.clickDeliverItems();
        expeditor.verifyItemInDeliveredSection(customerName,quantity);
        expeditor.goToHomePage();


        log.step(11,"BQ verifications");
        BQanalytics bq = new BQanalytics();
        String[] excludeEventId = {"page tracking","picklist"};
        TableResult results = bq.getCurrentSessionEntries(excludeEventId);

        upc = upc.replaceAll("\\s","");

        log.info("Verify Picklist sent event is present from fss");
        Map<String,String> updatedPickListSent = EventDataParser.getEventDatafor(eventDataLoc,"FSSPickListSent");
        updatedPickListSent.put("field_customer_name",customerName);
        updatedPickListSent.put("field_shoe_count",quantity);
        updatedPickListSent.put("field_type_of_store",zoneType.toLowerCase());
        updatedPickListSent.put("field_upcs",upc);
        updatedPickListSent.put("field_zone_name",zoneName);

        Assert.assertTrue(new BQdataValidator().verifyEventIsPresentInResults(results, updatedPickListSent,1));

        log.info("Verify pick list accepted event is present from expeditor");
        Map<String,String> updatedPickListAccepted = EventDataParser.getEventDatafor(eventDataLoc,"FSSEXPPickListAccepted");
        updatedPickListAccepted.put("field_type_of_store",zoneType.toLowerCase());
        updatedPickListAccepted.put("field_list_of_zones",zoneName);

        Assert.assertTrue(new BQdataValidator().verifyEventIsPresentInResults(results, updatedPickListAccepted,1));

        log.info("Verify item pulled event is present from expeditor");
        Map<String,String> updatedItemPulled = EventDataParser.getEventDatafor(eventDataLoc,"FSSEXPItemPulled");
        updatedItemPulled.put("field_upc",upc);
        updatedItemPulled.put("field_zone_name",zoneName);
        updatedItemPulled.put("field_type_of_store",zoneType.toLowerCase());

        Assert.assertTrue(new BQdataValidator().verifyEventIsPresentInResults(results, updatedItemPulled,1));

        log.info("Verify pick list delivered event is present from expeditor");
        Map<String,String> updatedPickListDelivered = EventDataParser.getEventDatafor(eventDataLoc,"FSSEXPPickListDelivered");
        updatedPickListDelivered.put("field_upcs",upc);
        updatedPickListDelivered.put("field_zone_name",zoneName);
        updatedPickListDelivered.put("field_type_of_store",zoneType.toLowerCase());
        updatedPickListDelivered.put("field_shoe_delivered",quantity);

        Assert.assertTrue(new BQdataValidator().verifyEventIsPresentInResults(results, updatedPickListDelivered,1));

        log.endTest("FSS test - Picklist Delivered full flow from FSS to Expeditor");

    }
}
