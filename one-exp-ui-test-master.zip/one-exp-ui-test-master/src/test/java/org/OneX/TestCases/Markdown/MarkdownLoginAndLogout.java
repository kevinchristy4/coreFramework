package org.OneX.TestCases.Markdown;

import com.google.cloud.bigquery.TableResult;
import org.core.component.BQanalytics;
import org.core.component.pages.BasePage;
import org.core.component.pages.HomePage;
import org.core.component.pages.Markdown.Ticketing;
import org.core.component.pages.Preferences;
import org.core.util.*;
import org.testng.Assert;
import org.testng.annotations.Test;

public class MarkdownLoginAndLogout extends BasePage {

    private Logger log = Logger.getLogger();
    private String eventDataLoc = "src/main/resources/EventsData/MarkdownEvents.json";


    public MarkdownLoginAndLogout() throws Exception {
    }

    @Test
    public void test() throws Exception{
        log.startTest("Markdown entry/exit event test");

        new BQanalytics().getLastEntry(PropertiesHandler.getProperties().getProperty("bqUserID"));

        HomePage homePage = new HomePage();
        homePage.selectService(HomePage.serviceOptions.MERCHANDISING);
        homePage.selectServiceSection("Ticketing");

        skipConnection();
        Ticketing ticketing = new Ticketing();
        ticketing.clickBackArrow();

        HomePage homePage1 = new HomePage();
        homePage1.selectService(HomePage.serviceOptions.MERCHANDISING);
        homePage1.selectServiceSection("Ticketing");

        skipConnection();
        Ticketing ticketing1 = new Ticketing();
        ticketing1.selectToggleMenuOption("Preferences");
        Preferences preferences = new Preferences();
        preferences.clickBackMarkDownPref();
        ticketing1.clickBackArrow();

        BQanalytics bq = new BQanalytics();
        TableResult results = bq.getCurrentSessionEntries();
        Assert.assertTrue(new BQdataValidator().verifyEventIsPresentInResults(results, EventDataParser.getEventDatafor(eventDataLoc,"MarkdownTicketingLogin"),3));
        Assert.assertTrue(new BQdataValidator().verifyEventIsPresentInResults(results, EventDataParser.getEventDatafor(eventDataLoc,"MarkdownTicketingLogout"),1));

        log.endTest("Markdown entry/exit event test");

    }
}
