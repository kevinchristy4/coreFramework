package org.OneX.TestCases.API.Merchandising;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import org.core.util.JsonParserFromFile;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import org.core.util.Logger;
import org.core.util.RestApi;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import io.restassured.response.Response;

public class NewVendorsNegtiveScenarios  {

     private Logger log = Logger.getLogger();

    private String locationKey = "locationNbr";
    private String workTypeKey = "workTypeCode";
    private String departmentKey = "departmentNbr";

    private String variable ="{ \"locationNbr\": \"%1$s\", \"workTypeCode\": \"%2$s\", \"departmentNbr\": \"%3$s\" }";

    private String query = "query vendors($locationNbr:String!,$workTypeCode:String!, $departmentNbr: String!) {\r\n"
            + "  vendors(locNbr:$locationNbr,  deptNbr:$departmentNbr,workTypeCode:$workTypeCode){\r\n"
            + "    vendorId\r\n"
            + "    vendorName\r\n"
            + "    nbrItems\r\n"
            + "  }\r\n"
            + "}";
    private String uri = "https://pick-pack-api-qa.devops.fds.com/graphql";
    private String testDataLocation = "src/test/java/org/OneX/TestData/newData.json";

    private String locationNbrerr = "Exception while fetching data (/vendors) : locNbr cannot be null or empty";
    private String workTypeCodeerr= "Exception while fetching data (/vendors) : For input string:";
    private String departmentNbrerr= "Exception while fetching data (/vendors) : deptNbrs cannot be null or empty";


    public NewVendorsNegtiveScenarios(){
        log.startTest("Vendors Negative Scenarios ");
    }

    @DataProvider(name = "locationData")
    private Object[][] dataProviderMethod() {
        List<JsonObject> datObject = JsonParserFromFile.getDataAsList(JsonParserFromFile.readJsonFromFile(testDataLocation));
        List<Object[]> testData = new ArrayList<>();
        for (JsonObject key : datObject) {
            String locationNbr = key.get(locationKey).getAsString();
            String workTypeCode = key.get(workTypeKey).getAsString();
            String activityStatusCodes = key.get(departmentKey).getAsString();
            testData.add(new Object[]{locationNbr, workTypeCode, activityStatusCodes});
        }
        return testData.toArray(new Object[testData.size()][]);
    }

    @Test(dataProvider = "locationData")
    public void VendorsNegativeApiTests(String locationNbr, String workTypeCode, String departmentNbr) throws Exception {


        if(locationNbr.isEmpty()){
            log.info("---------- Scenario: Validate response When location number is missing --------------");
            log.info("Hitting the api with the following test data");
            log.info("Location Number: " + locationNbr);
            log.info("Work Type Code: " + workTypeCode);
            log.info("Department Number: " + departmentNbr);

            Response response = RestApi.postGrapgQlcall(uri,null,String.format(variable,locationNbr,workTypeCode,departmentNbr),query);
            Gson gson = new Gson();
            JsonObject jsonObject = gson.fromJson(response.getBody().asString(),JsonObject.class);

            String message = jsonObject.getAsJsonArray("errors").get(0).getAsJsonObject().get("message").getAsString();
            log.info("Response message: "+message);
            try {
                Assert.assertTrue(message.contains(locationNbrerr));
            }catch (AssertionError e){
                log.error("Expected response: "+locationNbrerr+" || "+"Actual Response: "+message);
                throw new Exception("Response message does not match ");
            }

        }
        else if (workTypeCode.isEmpty()) {
            log.info("----------- Scenario: Validate response When Work Type Code is missing --------------------");

            log.info("Hitting the api with the following test data");
            log.info("Location Number: " + locationNbr);
            log.info("Work Type Code: " + workTypeCode);
            log.info("Department Number: " + departmentNbr);

            Response response = RestApi.postGrapgQlcall(uri,null,String.format(variable,locationNbr,workTypeCode,departmentNbr),query);
            Gson gson = new Gson();
            JsonObject jsonObject = gson.fromJson(response.getBody().asString(),JsonObject.class);

            String message = jsonObject.getAsJsonArray("errors").get(0).getAsJsonObject().get("message").getAsString();
            log.info("Response message: "+message);
            try {
                Assert.assertTrue(message.contains(workTypeCodeerr));
            }catch (AssertionError e){
                log.error("Expected response: "+workTypeCodeerr+" || "+"Actual Response: "+message);
                throw new Exception("Response message does not match ");            }

        } else if (departmentNbr.isEmpty()) {
            log.info(" ------------- Scenario: Validate response When Department Number is missing ----------------");

            log.info("Hitting the api with the following test data");
            log.info("Location Number: " + locationNbr);
            log.info("Work Type Code: " + workTypeCode);
            log.info("Department Number: " + departmentNbr);

            Response response = RestApi.postGrapgQlcall(uri,null,String.format(variable,locationNbr,workTypeCode,departmentNbr),query);
            Gson gson = new Gson();
            JsonObject jsonObject = gson.fromJson(response.getBody().asString(),JsonObject.class);

            String message = jsonObject.getAsJsonArray("errors").get(0).getAsJsonObject().get("message").getAsString();
            log.info("Response message: "+message);
            try {
                Assert.assertTrue(message.contains(departmentNbrerr));
            }catch (AssertionError e){
                log.error("Expected response: "+departmentNbrerr+" || "+"Actual Response: "+message);
                throw new Exception("Response message does not match ");            }
        }
    }

    @AfterClass
    private void endTest(){
        log.endTest("Vendors Negative Scenarios");
    }
}

