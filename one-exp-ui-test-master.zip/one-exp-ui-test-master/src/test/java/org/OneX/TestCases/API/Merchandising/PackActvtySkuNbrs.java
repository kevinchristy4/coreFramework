package org.OneX.TestCases.API.Merchandising;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.stream.JsonReader;
import io.restassured.response.Response;
import org.core.util.JsonParserFromFile;
import org.core.util.Logger;
import org.core.util.RestApi;
import org.testng.annotations.AfterClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import java.io.FileReader;
import java.io.IOException;
import java.sql.*;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;
public class PackActvtySkuNbrs {
        private Logger log = Logger.getLogger();
        private String variable = "{\"cartonRequestInput\":{\"deliveryTypeDesc\": \"%1$s\", \"divNbr\": \"%2$s\", \"zlStoreNbr\": \"%3$s\"}}";
        private String variable1 = "{\"movementInput\":{\"location\":\"%1$s\" ,\"eventTypeCode\":\"%2$s\" , \"associateId\":\"%3$s\",\"packgNbr\":\"%4$s\",\"activities\":%5$s}}";
        private String variable2 = "{\"activityUpdateInput\": { \"location\": \"%1$s\", \"resNbr\": \"%2$s\", \"shpToLocNbr\": \"%3$s\", \"shpNbr\": \"%4$s\", \"packgNbr\": \"%5$s\", \"skuUpcWithQtyList\": %6$s, \"activities\":\"%7$s\",\"eventTypeCode\": \"%8$s\", \"associateId\": \"%9$s\",\"deviceType\" :\"%10$s\",\"deviceName\" :\"%11$s\"}}";
        private String query = "query getCartonNumber($cartonRequestInput:CartonRequestInput){\n" +
                " getCartonNumber(cartonRequestInput:$cartonRequestInput){\n" +
                " returnCode\n" +
                " returnMessage\n" +
                " cartonNbr\n" +
                " }\n" +
                "}";
        private String query1 = "mutation updateMovementActivity($movementInput: MovementInput!) {\n" +
                " updateMovementActivity(\n" +
                " movementInput: $movementInput\n" +
                " ) {\n" +
                " returnCode\n" +
                " returnMessage\n" +
                " }\n" +
                "}";
        private String query2 = "mutation updatePackActivites($activityUpdateInput: ActivityUpdateInput!) {\n" +
                " updateActivity(activityUpdateInput:$activityUpdateInput) {\n" +
                " cartonNbr\n" +
                " zlDivNbr\n" +
                " zlStoreNbr\n" +
                " locNbr\n" +
                " totalUnitsPacked\n" +
                " }\n" +
                "}";
        private String uri = "https://pick-pack-api-qa.devops.fds.com/graphql";
        private List<String> cartonNbr = new ArrayList<String>();
        private Connection connection;
        @DataProvider(name = "CartonNumber")
        public static Object[][] dataProviderMethod() {
            List<JsonObject> datObject = JsonParserFromFile.getDataAsList(JsonParserFromFile.readJsonFromFile("src/test/java/org/OneX/TestData/cartonNubers.json"));
            List<Object[]> testData = new ArrayList<>();
            for (JsonObject key : datObject) {
                String deliveryTypeDesc = key.get("deliveryTypeDesc").getAsString();
                String divNbr = key.get("divNbr").getAsString();
                String zlStoreNbr = key.get("zlStoreNbr").getAsString();
                testData.add(new Object[]{deliveryTypeDesc, divNbr, zlStoreNbr});
            }
            return testData.toArray(new Object[testData.size()][]);
        }

        @DataProvider(name = "UpdateMovement")
        public static Object[][] dataProviderMethod1() {
            List<Object[]> testData = new ArrayList<>();
            try {
                JsonReader reader = new JsonReader(new FileReader("src/test/java/org/OneX/TestData/UpdateMovement.json"));
                JsonParser parser = new JsonParser();
                JsonArray dataArray = parser.parse(reader).getAsJsonArray();
                for (int i = 0; i < dataArray.size(); i++) {
                    JsonObject entry = dataArray.get(i).getAsJsonObject();
                    String location = entry.get("location").getAsString();
                    String eventTypeCode = entry.get("eventTypeCode").getAsString();
                    String associateId = entry.get("associateId").getAsString();
                    String packgNbr = entry.get("packgNbr").getAsString();
                    JsonArray activitiesArray = entry.getAsJsonArray("activities");
                    testData.add(new Object[]{location, eventTypeCode, associateId, packgNbr, activitiesArray});

                }
            }

            catch (Exception e) {
                System.out.println("nullpoinr"+ e);
            }
            return testData.toArray(new Object[testData.size()][]);
        }

        @DataProvider(name = "PackActivitiesSkuN")
        public static Object[][] dataProviderMethod2() {
            List<JsonObject> datObject = JsonParserFromFile.getDataAsList(JsonParserFromFile.readJsonFromFile("src/test/java/org/OneX/TestData/SkuNbrs.json"));
            List<Object[]> testData = new ArrayList<>();
            for (JsonObject key : datObject) {
                String location = key.get("location").getAsString();
                String resNbr = key.get("resNbr").getAsString();
                String shpToLocNbr = key.get("shpToLocNbr").getAsString();
                String shpNbr = key.get("shpNbr").getAsString();
                String packgNbr = key.get("packgNbr").getAsString();
//            JsonArray skuUpcWithQtyList = new JsonArray();
                JsonArray  skuUpcWithQtyList = key.getAsJsonArray("skuUpcWithQtyList");
                String activities = key.get("activities").getAsString();
                String eventTypeCode = key.get("eventTypeCode").getAsString();
                String associateId = key.get("associateId").getAsString();
                String deviceType = key.get("deviceType").getAsString();
                String deviceName =key.get("deviceName").getAsString();
                testData.add(new Object[]{location, resNbr, shpToLocNbr, shpNbr, packgNbr, skuUpcWithQtyList.toString(),activities, eventTypeCode, associateId,deviceType,deviceName});
            }
            return testData.toArray(new Object[testData.size()][]);
        }


        public PackActvtySkuNbrs() {
            log.startTest("Start the validate PackActivitySkuNbrs ");
        }
        @Test(dataProvider = "CartonNumber",priority=0)
        public void GraphicalVariables(String deliveryTypeDesc, String divNbr, String zlStoreNbr) throws Exception {
            Response response = RestApi.postGrapgQlcall(uri, null, String.format(variable, deliveryTypeDesc, divNbr, zlStoreNbr), query);
            log.info("---------- Scenario: Validate response --------------");
            System.out.println();
            log.info("Hitting the API with the following test data:");
            log.info("locationNbr: " + deliveryTypeDesc);
            log.info("associateId: " + divNbr);
            log.info("zlStoreNbr: " + zlStoreNbr);
            System.out.println(response.body().prettyPrint());

            String responseBody = response.body().asString();
//            JsonParser parser = new JsonParser();
//            JsonObject responseData = parser.parse(new StringReader(responseBody)).getAsJsonObject();
            Gson gson = new Gson();
            JsonObject jsonObject = gson.fromJson(response.getBody().asString(), JsonObject.class);
//            JsonObject responseData = JsonParser.parseReader(response.body().asString()).getAsJsonObject();
            String CartonNumber= jsonObject.getAsJsonObject("data").getAsJsonObject("getCartonNumber").get("cartonNbr").getAsString();
            cartonNbr.add(CartonNumber);
            System.out.println(cartonNbr);
        }

        @Test(dataProvider = "UpdateMovement",priority=1)
        public void Update(String location, String eventTypeCode, String associateId, String packgNbr, JsonArray activities) throws Exception {
            for(int i=0;i<cartonNbr.size();i++) {
                packgNbr = cartonNbr.get(i);
                String variable = String.format(variable1, location, eventTypeCode, associateId, packgNbr, activities);
                String activitiesJson = activities.toString(); // Convert activities JsonArray to String
                String datavalue = String.format(variable1, location, eventTypeCode, associateId, packgNbr, activitiesJson);
                System.out.println(datavalue);
                Response response = RestApi.postGrapgQlcall(uri, null, variable, query1);
                log.info("---------- Scenario: Validate response --------------");
                System.out.println();
                log.info("Hitting the API with the following test data:");
                log.info("location: " + location);
                log.info("resNbr: " + eventTypeCode);
                log.info("associateId: " + associateId);
//            log.info("associateId: " + this.packgNbr);
                log.info("packgNbr: " + packgNbr);
                log.info("activities:" + activities);
                System.out.println(response.body().prettyPrint());
                Thread.sleep(2000);
                System.out.println("**********************************************************************************");
            }
        }

        @Test(dataProvider = "PackActivitiesSkuN", priority = 2)
        public void SKUNbrs (String location, String resNbr, String shpToLocNbr, String shpNbr, String
                packgNbr, String skuUpcWithQtyList, String activities, String eventTypeCode, String associateId, String
                                     deviceType, String deviceName) throws Exception {
            for (int i = 0; i < cartonNbr.size(); i++) {
                packgNbr = cartonNbr.get(i);
                Thread.sleep(2000);
                String variable = String.format(variable2, location, resNbr, shpToLocNbr, shpNbr, packgNbr, skuUpcWithQtyList, activities, eventTypeCode, associateId, deviceType, deviceName);
                Response response = RestApi.postGrapgQlcall(uri, null, variable, query2);
//        System.out.println(variable);
                Thread.sleep(2000);
                log.info("---------- Scenario: Validate response --------------");
                System.out.println();
                log.info("Hitting the API with the following test data:");
                log.info("location: " + location);
                log.info("resNbr: " + resNbr);
                log.info("shpNbr: " + shpNbr);
                log.info("packgNbr: " + packgNbr);
                log.info("skuUpcWithQtyList: " + skuUpcWithQtyList);
                log.info("activities:" + activities);
                log.info("eventTypeCode: " + eventTypeCode);
                log.info("associateId: " + associateId);
                log.info("deviceType: " + deviceType);
                log.info("deviceName:" + deviceName);
                System.out.println(response.body().prettyPrint());
                System.out.println("**********************************************************************************");
            }
        }
        @AfterClass
        private void endTest() {
            log.endTest("PackActivitySkuNbrs testScenarios");
        }
    }

