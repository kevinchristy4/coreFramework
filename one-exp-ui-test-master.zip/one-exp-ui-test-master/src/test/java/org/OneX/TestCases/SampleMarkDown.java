package org.OneX.TestCases;

import org.core.component.elements;
import org.core.component.pages.BasePage;
import org.core.component.pages.HomePage;
import org.core.component.pages.Markdown.Ticketing;
import org.openqa.selenium.By;
import org.testng.annotations.Test;

public class SampleMarkDown extends BasePage {

    public SampleMarkDown() throws Exception {
    }

    @Test
    public void sampleTest() throws Exception {
        HomePage homePage = new HomePage();
        homePage.selectService(HomePage.serviceOptions.MERCHANDISING);
        homePage.selectServiceSection("Ticketing");
        Ticketing ticketing = new Ticketing();
        new elements(By.xpath("abc")).click();
    }
}
