package org.OneX.TestCases.Foundations;

import com.google.cloud.bigquery.TableResult;
import com.google.cloud.spanner.ResultSet;
import org.core.component.BQanalytics;
import org.core.component.pages.BasePage;
import org.core.component.pages.HomePage;
import org.core.util.*;
import org.testng.Assert;
import org.testng.annotations.Test;

public class NotificationsReceivingTest extends BasePage {

    private Logger log = Logger.getLogger();
    private String customerName = "VIRATAPU";
    private String vehicleType = "SUV";
    private String color = "White";
    private String location = "test";
    private String eventDataLoc = "src/main/resources/EventsData/FoundationsEvent.json";

    public NotificationsReceivingTest() throws Exception {
    }

    @Test
    public void test() throws Exception{

        log.startTest("Notification Test");

//        HomePage homePage1 = new HomePage();
//        homePage1.goToPreferences();
//        Preferences preferences1 = new Preferences();
//        preferences1.clickOnOption(Preferences.options.alerts);
//        preferences1.toggleAlerts(true);
//        preferences1.clickBackPref();
//        preferences1.goToHomePage();

        new BQanalytics().getLastEntry(PropertiesHandler.getProperties().getProperty("bqUserID"));
        log.step(1,"Get valid customer token from Spanner DB");
        SpannerDB db = new SpannerDB();
        db.connectDB(PropertiesHandler.getProperties().getProperty("testEnv"));

        log.info("Query created and updating in DB");
        db.updateQuery(new TriggerNotification().getUpdateTokenQuery(customerName));

        log.info("Filtering the results for the given customer name");
        ResultSet result = db.selectQuery(new TriggerNotification().getSelectTokenQuery(customerName));
        String customerToken =  db.getToken(result,customerName);

        log.step(2,"Launching browser and navigating to curbside");
        new TriggerNotification().triggerOnTheWayAndArrivedInCar(customerToken,vehicleType,color,location);

        log.step(3, "Navigate to Notification centre");
        HomePage homePage = new HomePage();
        Assert.assertTrue(homePage.getNotificationsList().contains(String.format("%1$s has arrived to the store",customerName)));
//        Assert.assertTrue(homePage.getNotificationsList().contains(String.format("%1$s is on the way to the store",customerName)));
        homePage.closeAndroidNotifications();
        setCurrentContext();
        homePage.goToNotificationCentre();

        log.step(4, "Verify if notifications are present");
        homePage.isNotificationPresent(customerName, HomePage.notificationStatus.ON_THE_WAY);
        homePage.isNotificationPresent(customerName, HomePage.notificationStatus.ARRIVED);


        log.step(5,"Mark one of the notification as Read");
        homePage.markNotificationAsRead(customerName,HomePage.notificationStatus.ON_THE_WAY);
        homePage.goToHomePage();
//        homePage.deleteNotification(customerName,HomePage.notificationStatus.ON_THE_WAY,true);
        sleep(7);

        log.step(6,"Verify events in bigQuery");
        BQanalytics bq = new BQanalytics();
        TableResult results = bq.getCurrentSessionEntries();

        Assert.assertTrue(new BQdataValidator().verifyEventIsPresentInResults(results, EventDataParser.getEventDatafor(eventDataLoc,"NotificationAccess"),1));
        Assert.assertTrue(new BQdataValidator().verifyEventIsPresentInResults(results, EventDataParser.getEventDatafor(eventDataLoc,"NotificationExit"),1));
        Assert.assertTrue(new BQdataValidator().verifyEventIsPresentInResults(results, EventDataParser.getEventDatafor(eventDataLoc,"FcmNotificationArrived"),2));
        Assert.assertTrue(new BQdataValidator().verifyEventIsPresentInResults(results, EventDataParser.getEventDatafor(eventDataLoc,"FcmNotificationRead"),1));

        log.info("Notification tray access, exit, customer arrived, customer on the way and notification read events are present in BigQuery");

        log.endTest("Notification Receiving and Read test");

    }

}
