package org.OneX.TestCases.FLM_FSS;

import com.google.cloud.bigquery.TableResult;
import org.core.component.BQanalytics;
import org.core.component.pages.BasePage;
import org.core.component.pages.FSS.FSSMain;
import org.core.component.pages.HomePage;
import org.core.util.BQdataValidator;
import org.core.util.EventDataParser;
import org.core.util.Logger;
import org.core.util.PropertiesHandler;
import org.testng.Assert;
import org.testng.annotations.Test;

public class FSS_Login extends BasePage {

    private Logger log = Logger.getLogger();
    private String startEvent = "fssLoginStart";
    private String endEvent = "fssLoginEnd";
    private String dataFilePath = "src/main/resources/FlmEventsData/fss.json";

    public FSS_Login() throws Exception {
    }

    @Test
    public void fssLoginTest() throws Exception {

        log.startTest("FSS Login test for FLM events");
        HomePage homePage = new HomePage();

        log.info("Select Shoe sales in landing page");
        homePage.selectService(HomePage.serviceOptions.SHOES_SALES);

        new BQanalytics().getLastEntry(PropertiesHandler.getProperties().getProperty("bqUserID"));

        log.info("Select FSS");
        homePage.selectServiceSection(HomePage.serviceOptions.FSS.getString());
        FSSMain fssMain = new FSSMain();

        log.info("Verify events in BQ");
        String[] excludeEvent = {"page tracking"};
        TableResult result = new BQanalytics().getCurrentSessionEntries(excludeEvent);

        Assert.assertTrue(new BQdataValidator().verifyFLMEvents(result, EventDataParser.getEventDatafor(dataFilePath,startEvent),EventDataParser.getEventDatafor(dataFilePath,endEvent),2));
        fssMain.goToHomePage();
    }
}
