package org.OneX.TestCases.API.Merchandising;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import io.restassured.response.Response;
import org.core.util.JsonParserFromFile;
import org.core.util.Logger;
import org.core.util.RestApi;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import java.util.ArrayList;
import java.util.List;

public class CartonNumber {
    private Logger log = Logger.getLogger();
    private String variable = "{\"cartonRequestInput\":{ \"deliveryTypeDesc\": \"%1$s\", \"divNbr\": \"%2$s\", \"zlStoreNbr\": \"%3$s\" }}";
    private String query = "query getCartonNumber($cartonRequestInput:CartonRequestInput){\n" +
            "    getCartonNumber(cartonRequestInput:$cartonRequestInput){\n" +
            "         returnCode\n" +
            "         returnMessage\n" +
            "         cartonNbr\n" +
            "    }\n" +
            "}";
    private String uri = "https://pick-pack-api-qa.devops.fds.com/graphql";

    @DataProvider(name = "myDataProvider")
    public static Object[][] dataProviderMethod() {
        List<JsonObject> datObject = JsonParserFromFile.getDataAsList(JsonParserFromFile.readJsonFromFile("src/test/java/org/OneX/TestData/CartonNumberData.json"));
        List<Object[]> testData = new ArrayList<>();
//        List<String> deliveryTypes = new ArrayList<>();
        for (JsonObject key : datObject) {
            String deliveryTypeDesc = key.get("deliveryTypeDesc").getAsString();
            String divNbr = key.get("divNbr").getAsString();
            String zlStoreNbr = key.get("zlStoreNbr").getAsString();
            testData.add(new Object[]{deliveryTypeDesc, divNbr, zlStoreNbr});
        }
        return testData.toArray(new Object[testData.size()][]);
    }

    public CartonNumber() {
        log.startTest("Start the validate CartonNumber ");
    }

    @Test(dataProvider = "myDataProvider")
    public void GraphicalVaribles(String deliveryTypeDesc, String divNbr, String zlStoreNbr) throws Exception {
        Response response = RestApi.postGrapgQlcall(uri, null, String.format(variable, deliveryTypeDesc, divNbr, zlStoreNbr), query);
        log.info("---------- Scenario: Validate response --------------");
        System.out.println();
        log.info("Hitting the api with the following test data");
        log.info("deliveryTypeDesc: " + deliveryTypeDesc);
        log.info("divNbr: " + divNbr);
        log.info("zlStoreNbr: " + zlStoreNbr);
        System.out.println(response.prettyPrint());
//        JsonObject object = new JsonObject();
//        log.info("Response data is printed" + response.body());
    }

    @AfterClass
    private void endTest() {
        log.endTest("CartonNumber testScenarios");
    }
}