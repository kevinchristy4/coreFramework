package org.OneX.TestCases.FLM_FSS;

import org.core.component.BQanalytics;
import org.core.component.pages.BasePage;
import org.core.component.pages.HomePage;
import org.core.component.pages.FSS.Expeditor;
import org.core.component.pages.FSS.FSSMain;
import org.core.util.BQdataValidator;
import org.core.util.EventDataParser;
import org.core.util.Logger;
import org.core.util.PropertiesHandler;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.google.cloud.bigquery.TableResult;

public class FSS_PutAway extends BasePage {
    HomePage homePage;
    Expeditor expeditor;
    FSSMain fss;
    
    private Logger log = Logger.getLogger();
    private String zoneName = "Tribeca";
    private String zoneType = "LITE";
    private String upc = "19841273436";
    private String startEvent = "fssPutAwayStart";
    private String endEvent = "fssPutAwayEnd";
    private String dataFilePath = "src/main/resources/FlmEventsData/fss.json";

    public FSS_PutAway() throws Exception {
        super();
    }
    
    @Test
    public void expeditorPutAway() throws Exception {
        
    new BQanalytics().getLastEntry(PropertiesHandler.getProperties().getProperty("bqUserID"));    
    log.startTest("FSS-FLM integration: Feature Put Away in FSS (Lite Flow)");
    
    log.step(1, "Navigate to Shoe Sales -> FSS");    
    homePage = new HomePage();
    homePage.selectService(HomePage.serviceOptions.SHOES_SALES);

    log.step(2, "Login to FSS");    
    homePage.selectServiceSection(HomePage.serviceOptions.FSS.getString());

    log.step(3,"Select Zone as Tribeca - Lite"); 
    fss = new FSSMain();
    fss.selectZone(zoneName,zoneType);
    
    log.step(4, "Navigate to Put Away and enter UPC");
    expeditor = new Expeditor("Lite");
    expeditor.putAwayItem(upc);
    
    log.step(5, "Verify events in BQ");
    String[] excludeEvent = {"page tracking","picklist"};
    TableResult result = new BQanalytics().getCurrentSessionEntries(excludeEvent);

    Assert.assertTrue(
        new BQdataValidator().verifyFLMEvents(result, EventDataParser.getEventDatafor(dataFilePath, startEvent),
            EventDataParser.getEventDatafor(dataFilePath, endEvent), 2));
    
    expeditor.goToHomePage();

    log.endTest("FSS-FLM integration: Feature Put Away in FSS (Lite Flow)");
    
    }
}
