package org.core.component.pages;

import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.offset.PointOption;
import org.core.component.BaseFunc;
import org.core.component.elements;
import org.core.component.wait;
import org.core.driver.onexApp;
import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class ConfigPage extends BaseFunc {

    private String versionXpath = "com.macys.sdf.androidhal.onexp:id/openConfigScreen";
    private String landingPageURl = "com.macys.sdf.androidhal.onexp:id/landingPageAc";
    private String divisionNumber = "com.macys.sdf.androidhal.onexp:id/idDivNo";
    private String storeNumber = "com.macys.sdf.androidhal.onexp:id/idStoreNo";
    private String sspID = "com.macys.sdf.androidhal.onexp:id/idssp";
    private String cancelButton = "com.macys.sdf.androidhal.onexp:id/idBtnCancel";
    private String continueButton = "com.macys.sdf.androidhal.onexp:id/idBtnLoadEnv";
    private String configHeader = "com.macys.sdf.androidhal.onexp:id/idTVHeader";
    private String skipButton = "android:id/button2";
    private int versionXaxis = 375;
    private int versionYaxis = 1044;

    public String appVersion;

    public ConfigPage() throws Exception {
//        new onexApp().unlockDevice();
        wait.waitForAppElement(By.id(configHeader));
        log.info("User in App Config page");
    }


    public void getAppVersion() throws Exception {

        elements versionBtn = new elements(By.id(versionXpath),"Version number");
        appVersion = versionBtn.getText();
    }



    public void selectEnv(String env, String division, String store, String ssp) throws Exception {

        WebDriver configDriver = new onexApp().getDriver();

        log.info("Typing Environment url = "+env);
        configDriver.findElement(By.id(landingPageURl)).sendKeys(env);

        if(division != null){
            log.info("Typing Division number = "+division);
            configDriver.findElement(By.id(divisionNumber)).sendKeys(division);
        }
        if(store != null) {
            log.info("Typing Store number = "+store);
            configDriver.findElement(By.id(storeNumber)).sendKeys(store);
        }
        if(ssp != null) {
            log.info("Typing ssp ID = "+ssp);
            configDriver.findElement(By.id(sspID)).sendKeys(ssp);
        }

        log.info("Clicking Continue");
        configDriver.findElement(By.id(continueButton)).click();

        try {
            WebElement warningPopup = new WebDriverWait(configDriver, Duration.ofSeconds(5)).until(ExpectedConditions.presenceOfElementLocated(By.id(skipButton)));
            if(warningPopup.isDisplayed()){
                log.info("Skipping version warning message");
                configDriver.findElement(By.id(skipButton)).click();
            }
        }catch (TimeoutException e){
            log.info("Version warning message did not appear");
        }
    }



}
