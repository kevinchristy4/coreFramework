package org.core.component.pages.FSS;

import org.core.component.BaseFunc;
import org.core.component.elements;
import org.core.component.wait;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import java.util.List;

public class Expeditor extends BaseFunc {

    private String expeditorHeader = "//span[@class='logo-text' and text()='Expeditor']";
    private String stockRoomTableHeader = "//div[@class='ui raised card']";
    private String selectStockRoomCheckBox = "//div[text()='%1$s']/..//div[@data-testid]";
    private String selectStockRoom = "//div[text()='%1$s']/..//div[@data-testid and contains(@class,'checked')]";
    private String selectStockroomButton = "//div[@class='button-content' and text()='Select Stockroom']";
    private String pillHeader = "//div[contains(@class,'ui pointing')]";
    private String pillSelector = "//a[text()='%1$s']";
    private String pickListAccept = "//b[text()='%1$s']/../../..//div[@class='ui fitted checkbox']";
    private String pickListCard = "//div[@class='productDescription']//span[contains(.,'%1$s')]";
    private String acceptButton = "//div[@class='button-content' and text()='Accept']";
    private String deliverItemsButton = "//div[@class='button-content' and text()='Deliver Items']";
    private String getUpc = "//div[@class='productCardContent']//i/following-sibling::span";
    private String menuButton = "//div[@role='listbox']//i";
    private String menuButton2 = "//div[@role='option']";
    private String scanItemText = "//span[text()='Scan Items']";
    private String upcInput = "//input[@type='number']";
    private String itemPulledText = "//div[@class='productStatus']//span[text()='Pulled']";
    private String deliveredText = "//a[contains(@class,'active') and text()='Delivered']";
    private String customerNameLoc = "//div[contains(@class,'DeliveredExpeditor__card')]/div[1]//div[@class='productDescription']//span";
    private String quantityLoc = "//div[contains(@class,'DeliveredExpeditor__card')]/div[1]//div[@class='productDescription']/div[2]";
    private String putAwayDetails = "//div[contains(@class,'putAway')]//p[contains(text(),'Put Away')]";
    private String putAwayText = "//span[text()='Put Away']";
    private String itemNotFound = "//div[@class='ui-swipe-content-hidden']";
    private String notFoundMarkedItem = "//span[contains(text(),'Item Not Found')]";
    private String pickListCardNew = "//div[@class='productDescription']//span[contains(.,'%1$s')]/../../../..";
    
    public Expeditor() throws Exception {
        wait.waitForPage();
        Assert.assertTrue(new elements(By.xpath(expeditorHeader),"FSS Header").isDisplayed());
        log.info("User in FSS expeditor Page");
    }
    
    public Expeditor(String str) throws Exception{
        log.info("Using this constructor to use methods for Lite version");
    }

    public enum actionTabs{
        PICKLIST("Picklist"),
        INCOMING("Incoming"),
        DELIVERED("Delivered");

        private String s;
        actionTabs(String s){this.s = s;}
        public String getString(){return s;}
    }

    public void selectStockRoom(String[] roomName) throws Exception {
        wait.waitForAppElement(By.xpath(stockRoomTableHeader));
        sleep(2);
        for (int i=0;i<roomName.length;i++){
            scrollIntoView(String.format(selectStockRoomCheckBox,roomName[i]));
            if(isElementNotDisplayed(By.xpath(String.format(selectStockRoom,roomName[i])))){
                new elements(By.xpath(String.format(selectStockRoom,roomName[i])),"Stock room checkbox").click();
            }
        }
        new elements(By.xpath(selectStockroomButton),"Select Stock room button").click();
    }

    public void selectHeaderPill(actionTabs actions) throws Exception {
        wait.waitForAppElement(By.xpath(pillHeader));
        new elements(By.xpath(String.format(pillSelector,actions.getString())),"Pill selector").click();
        wait.waitForPage();
    }

    public void acceptPickList(String[] name) throws Exception {
        wait.waitForPage();
        new elements(By.xpath(String.format(pickListAccept,name)),"Accept picklist").click();
        new elements(By.xpath(acceptButton),"Accept button").click();
    }

    public void acceptAllPicklist() throws Exception {
        wait.waitForPage();
        wait.waitForAppElement(By.xpath("//a[text()='Incoming']"));
        sleep(3);
        List<WebElement> stockRoomList = new elements().findElements(By.xpath("//div[@class='ui fitted checkbox']"));
        for(WebElement eachSR:stockRoomList){
            new elements(eachSR).click();
        }
        new elements(By.xpath(acceptButton),"Accept button").click();
    }

    public String enterUpcForItems(String customerName, String quantity) throws Exception {

        scrollIntoView(String.format(pickListCard,customerName));
        new elements(By.xpath(String.format(pickListCard,customerName)),"Picklist card").click();
        scrollIntoView(getUpc);
        String textUPC = new elements(By.xpath(getUpc),"UPC").getText();
        System.out.println(textUPC);

        while (checkIfItemPulled(customerName)){
            new elements(By.xpath(menuButton),"Menu button").click();
            new elements(By.xpath(menuButton2),"Menu button").click();
            wait.waitForAppElement(By.xpath(scanItemText));
            new elements(By.xpath(upcInput),"Enter UPC").sendKeys(textUPC+ Keys.ENTER);
            wait.waitForAppElement(By.xpath(pillHeader));
            wait.waitForToast();
        }
        return textUPC;
    }

    public Boolean checkIfItemPulled(String customerName) throws Exception {

        sleep(1);
        scrollIntoView(String.format(pickListCard,customerName));
        sleep(1);
        if(isElementNotDisplayed(By.xpath("//div[@class='ui-swipe-root']"))){
            new elements(By.xpath(String.format(pickListCard,customerName)),"Picklist card").click();
        }
        sleep(1);
        scrollIntoView(getUpc);
        sleep(1);
        return isElementNotDisplayed(By.xpath(itemPulledText));

    }

    public void clickDeliverItems() throws Exception {

        wait.waitForToast();
        scrollIntoView(deliverItemsButton);
        new elements(By.xpath(deliverItemsButton),"Deliver Items").click();
        wait.waitForPage();
        wait.waitForAppElement(By.xpath(deliveredText));

    }

    public void verifyItemInDeliveredSection(String customerName, String itemQty) throws Exception {
        String customerNameFromUI = new elements(By.xpath(customerNameLoc),"Customer name").getText();
        try{
            Assert.assertTrue(customerNameFromUI.contains(customerName));
        }catch (AssertionError e){
            log.error("Customer name not present in UI");
        }
        String qty = new elements(By.xpath(quantityLoc),"Customer name").getText();
        try{
            Assert.assertTrue(qty.contains(itemQty));
        }catch (AssertionError e){
            log.error("Quantity does not match");
        }
    }
    
    public void putAwayItem(String upc) throws Exception{
        wait.waitForPage();
        new elements(By.xpath(menuButton),"Menu button").click();
        new elements(By.xpath(menuButton2),"Menu button").click();
        wait.waitForAppElement(By.xpath(putAwayText));
        new elements(By.xpath(upcInput),"Enter UPC").sendKeys(upc+ Keys.ENTER);
        wait.waitForToast();
        wait.waitForAppElement(By.xpath(putAwayText));
        Assert.assertTrue(new elements(By.xpath(putAwayDetails),"Put Away Details").isDisplayed(), "Item has not been Put Away");
    }
    
    public void expeditorMarkItemAsNotFound(String customerName) throws Exception {
        wait.waitForPage();      
        wait.waitForAppElement(By.xpath(String.format(pickListCard,customerName)));
        scrollIntoView(String.format(pickListCard,customerName));
        wait.waitForElementToBeClickable(By.xpath(String.format(pickListCardNew,customerName)));
        new elements(By.xpath(String.format(pickListCardNew,customerName)), "First Item in Picklist").click();
        wait.waitForAppElement(By.xpath(getUpc));
        scrollIntoView(itemNotFound);       
        new elements(By.xpath(itemNotFound),"Not Found button").click();
        wait.waitForAppElement(By.xpath(notFoundMarkedItem));
        Assert.assertTrue(new elements(By.xpath(notFoundMarkedItem),"Item Not Found").isDisplayed(), "Item has marked as Not Found successfully!");
        scrollIntoView(deliverItemsButton);
        new elements(By.xpath(deliverItemsButton),"Deliver Items").click();
        wait.waitForPage();
        wait.waitForAppElement(By.xpath(deliveredText));
    }
    
}
