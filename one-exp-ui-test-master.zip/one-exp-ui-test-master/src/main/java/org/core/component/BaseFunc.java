package org.core.component;

import io.appium.java_client.NoSuchContextException;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;
import org.core.driver.onexApp;
import org.core.util.Logger;
import org.core.util.PropertiesHandler;
import org.openqa.selenium.*;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.JavascriptExecutor;
import org.testng.SkipException;

import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.*;
import java.util.stream.Collectors;

public class BaseFunc implements WebElement {
    private static WebDriver driver;
    private By locator;
    private WebElement ele;
    public Logger log = Logger.getLogger();
    private String elementName;

    private String labelWithText = "//label[text()=\"%1$s\"]";
    private String elementWithText = "//*[text()=\"%1$s\"]";
    private String connectDeviceHeader = "//span[text()='Connect Devices']";
    private String skipConnectionButton = "//div[text()='Skip Connection']";
    private String homeIconXpath = "//img[@id='onex-home-icon']";
    private String preferencesIconXpath = "//img[@id='onex-preferences-icon']";
    private String backArrowXpath = "//i[contains(@class,'icon macys back-arrow')]";
    private String downArrowXpath = "//i[contains(@class,'icon macys down-arrow')]";
    public String pageHeaderXpath = "//span[@class = 'logo-text' and text()='%1$s']";
    private String toggleMenuXpath = "//i[@title = 'Toggle Menu']";
    private String toggleOptions = "//a[@class = 'item' and text()='%1$s']";
    private String notificationsList = "android:id/title";
    private String getPageHeader = "//span[@class='logo-text']";
    private String browserExecution = PropertiesHandler.getProperties().getProperty("runInBrowser");


    public BaseFunc(By locator, String name) throws Exception {
        driver = new onexApp().getDriver();
        this.locator = locator;
        elementName = name;
        ele = waitAtConstruct(this.locator);
    }

    public BaseFunc(By locator)throws Exception{
        ele = driver.findElement(locator);
    }

    private void reinitializeElement() {
        ele = waitAtConstruct(this.locator);
    }


    public BaseFunc() throws Exception {

        driver = new onexApp().getDriver();

    }

    public BaseFunc(WebElement element) throws Exception{
        ele = element;
    }

    private WebElement waitAtConstruct(By loc) {

        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));
            final WebElement[] element = new WebElement[1];
            wait.until(driver -> {
                WebElement waitedEle = null;
                try{
                    waitedEle = wait.until(ExpectedConditions.presenceOfElementLocated(loc));
                    if (waitedEle != null && waitedEle.isDisplayed()) {
                        element[0] = waitedEle;
                        return wait.until(webDriver -> {
                            JavascriptExecutor jsExec = (JavascriptExecutor) driver;
                            return jsExec.executeScript("return document.readyState").equals("complete");
                        });
                    }
                }catch (StaleElementReferenceException e){
                    waitedEle = wait.until(ExpectedConditions.presenceOfElementLocated(loc));
                    if (waitedEle != null && waitedEle.isDisplayed()) {
                        element[0] = waitedEle;
                        return wait.until(webDriver -> {
                            JavascriptExecutor jsExec = (JavascriptExecutor) driver;
                            return jsExec.executeScript("return document.readyState").equals("complete");
                        });
                    }
                }


                return false;
            });
            return element[0];
        }catch (Exception e){
            e.printStackTrace();
            throw new NoSuchElementException(String.format("Element not found - %1$s",elementName));
        }
    }

    // A simple custom wait
    public void waitForElement(){
        try {
            WebDriverWait wait =  new WebDriverWait(driver, Duration.ofSeconds(60));
            wait.until(driver -> {
                WebElement waitedEle = null;
                try{
                    waitedEle =  wait.until(ExpectedConditions.elementToBeClickable(ele));
                    if(waitedEle != null && ele.isDisplayed()){
                        return true;
                    }
                }catch (StaleElementReferenceException e){
                    waitedEle =  wait.until(ExpectedConditions.elementToBeClickable(ele));
                    if(waitedEle != null && ele.isDisplayed()){
                        return true;
                    }
                }
                return false;
            });
        }catch (Exception e){
            e.printStackTrace();
            throw new SkipException(e.getLocalizedMessage());
        }
    }


    public WebDriverWait waitObj(Duration duration){
        WebDriverWait wait = new WebDriverWait(driver, duration);
        return wait;
    }

    public void setCurrentContext() throws Exception {

        try {
            new onexApp().getAndroidDriver().context("WEBVIEW_com.macys.sdf.androidhal.onexp");
        }
        catch (SessionNotCreatedException | NoSuchContextException e){
            if (e.getLocalizedMessage().contains("This version of ChromeDriver only supports Chrome version")){
                log.error("This version of chrome driver is not compatible with Onex");
                log.error("Delete the drivers folder and restart the tests");
                log.error("System will try to automatically download matching drivers with webview version of oneX");
                throw new SkipException("Delete the drivers folder and restart the test");
            }
        }
    }

    public void setNativeContext() throws Exception {

        new onexApp().getAndroidDriver().context("NATIVE_APP");
    }

    public void tapWithAxis(int x, int y, int count) throws Exception {

        TouchAction action = new TouchAction(new onexApp().getAndroidDriver());
            for(int i=0; i<count;i++) {
                action.tap(PointOption.point(x,y)).perform();
            }
    }

    public String charSeqToStr(CharSequence... chars){
        StringBuilder sb = new StringBuilder();
        for(CharSequence ch: chars){
            sb.append(ch.toString());
        }
        return sb.toString();
    }

    public void sleep(int sec) throws InterruptedException {
        Thread.sleep(sec*1000);
    }

    public List getTitleAndUrl(){

        ArrayList title_url = new ArrayList<String>();
        title_url.add(driver.getTitle());
        title_url.add(driver.getCurrentUrl());
        return title_url;
    }

    public void clickLabelWithText(String text) throws Exception {
        new elements(By.xpath(String.format(labelWithText,text)),text).click();
    }

    public void clickElementWithText(String text) throws Exception {
        new elements(By.xpath(String.format(elementWithText,text)),text).click();
    }

    public int getNoOfElements(By locator) throws Exception {

        return new onexApp().getDriver().findElements(locator).size();

    }

    public boolean isElementNotDisplayed(By locator) throws Exception {
        if(getNoOfElements(locator) == 0){
            return true;
        }
        else {
            return false;
        }
    }

    public void skipConnection() throws Exception {

        wait.waitForPage();
        sleep(2);
        if(!isElementNotDisplayed(By.xpath(connectDeviceHeader))){
                new elements(By.xpath(connectDeviceHeader),"Connect device page").waitForElement();
                new elements(By.xpath(skipConnectionButton),"Skip connection").click();
        }else {
            log.info("Skip connection page is not displayed");
        }

    }

    public void goToHomePage() throws Exception {

        wait.waitForPage();
        new elements(By.xpath(homeIconXpath),"Home Button").click();
    }

    public void goToPreferences() throws Exception {

        wait.waitForPage();
        new elements(By.xpath(preferencesIconXpath),"Preferences Button").click();
    }

    public void selectToggleMenuOption(String option) throws Exception {

        new elements(By.xpath(toggleMenuXpath),"Toggle Menu").click();
        new elements(By.xpath(String.format(toggleOptions,option)),"Toggle option").click();
    }
    public void scrollIntoView(String xpath) throws Exception {


        if(browserExecution.equalsIgnoreCase("true")) {
            try{
                ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({ block: 'center', inline: 'nearest' });", driver.findElement(By.xpath(xpath)));
            }catch (StaleElementReferenceException e){
                ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({ block: 'center', inline: 'nearest' });", driver.findElement(By.xpath(xpath)));
            }
        }
        else {
                try {
                    ((JavascriptExecutor) driver).executeScript(
                            "document.evaluate(arguments[0], document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.scrollIntoView({ block: 'center', inline: 'nearest' });",
                            xpath
                    );
                } catch (Exception e) {
                    System.err.println("Failed to scroll to element: " + e.getMessage());
                }
        }

    }

    public void scrollIntoView(WebElement ele){
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", ele);
    }

    public void scrollToBottom(){

        ((JavascriptExecutor)driver).executeScript("window.scrollBy(0,document.body.scrollHeight)");

    }



    public void doubleClick(){
        Actions act = new Actions(driver);
        try{
            act.doubleClick(ele).perform();
        }catch (StaleElementReferenceException e){
            reinitializeElement();
            act.doubleClick(ele).perform();
        }
    }

    public String getPageHeader() throws Exception {
        return new elements(By.xpath(getPageHeader),"Return Page header").getText();
    }


    /* Have your owm custom implementation of selenium methods - or just use the original methods */
    @Override
    public void click() {
        log.info("Clicking --- "+elementName);
        try{
            waitForElement();
            ele.click();
        }catch (StaleElementReferenceException | ElementClickInterceptedException e){
            if(e.getLocalizedMessage().contains("element click intercepted")){
                scrollIntoView(ele);
                ele.click();
            }else {
                reinitializeElement();
                ele.click();
            }
        }
    }

    public void clickConfig() {
        log.info("Clicking --- "+elementName);
        ele.click();
    }

    public void clickWithoutWait(By locator, String name){
        log.info("Clicking --- "+name);
        driver.findElement(locator).click();
    }

    public void clickWithAction(By locator, String name){
        Actions action = new Actions(driver);
        action.click(driver.findElement(locator)).build().perform();
    }

    public void clickBackArrow() throws Exception {

        log.info("Navigating back");
        new elements(By.xpath(backArrowXpath),"Back arrow icon").click();
    }

    public void clickDownArrrow() throws Exception{

        new elements(By.xpath(backArrowXpath),"Back arrow icon").click();

    }

    public WebElement returnElement(String xpath){
        return driver.findElement(By.xpath(xpath));
    }

    public void swipeLeft(WebElement element, int pixels) throws Exception {

        Dimension size = driver.manage().window().getSize();

        System.out.println(size.getHeight());
        System.out.println(size.getWidth());

        System.out.println(element.getLocation().getX());
        System.out.println(element.getLocation().getY());

        int startX = 500;
        int startY = 550;
        int endX = 310;

        TouchAction swipe = new TouchAction(new onexApp().getAndroidDriver());
        swipe.press(PointOption.point(startX, startY))
                .waitAction(WaitOptions.waitOptions(Duration.ofMillis(500)))
                .moveTo(PointOption.point(endX, startY))
                .release()
                .perform();
    }

    public List<String> getNotificationsList() throws Exception {

        openAndroidNotifications();
        setNativeContext();
        List<String> notificationContents = driver.findElements(By.id(notificationsList)).stream().map(WebElement::getText).collect(Collectors.toList());
        closeAndroidNotifications();
        return notificationContents;
    }

    public void openAndroidNotifications() throws Exception {

        log.info("Opening Android Notification...");
        new onexApp().getAndroidDriver().openNotifications();
    }

    public void closeAndroidNotifications() throws Exception {

        log.info("Closing Android Notification...");
        new onexApp().getAndroidDriver().navigate().back();
    }


    public String getTimeStamp(){
        SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyy HH-mm-ss");
        Date date = new Date();
        return format.format(date);
    }


    @Override
    public void submit() {
        try{
            ele.submit();
        }catch (StaleElementReferenceException e){
            reinitializeElement();
            ele.submit();
        }
    }

    @Override
    public void sendKeys(CharSequence... keysToSend) {

        waitForElement();
       try {
           ele.sendKeys(keysToSend);
       }catch (StaleElementReferenceException e){
           reinitializeElement();
           ele.sendKeys(keysToSend);
       }
        if(elementName != "Password"){
            log.info("Typing in "+elementName+" = "+charSeqToStr(keysToSend));
        }
    }

    public void sendKeysConfig(CharSequence... keysToSend) {
        ele.sendKeys(keysToSend);
        if(elementName != "Password"){
            log.info("Typing in "+elementName+" = "+charSeqToStr(keysToSend));
        }
    }

    @Override
    public void clear() {
        try{
            ele.clear();
        }catch (StaleElementReferenceException e){
            reinitializeElement();
            ele.clear();
        }
    }

    @Override
    public String getTagName() {
        try {
            return ele.getTagName();
        }catch (StaleElementReferenceException e){
            reinitializeElement();
            return ele.getTagName();
        }
    }

    @Override
    public String getAttribute(String name) {
        try {
            return ele.getAttribute(name);
        }catch (StaleElementReferenceException e){
            reinitializeElement();
            return ele.getAttribute(name);
        }

    }

    @Override
    public boolean isSelected() {
        try {
            return ele.isSelected();
        }catch (StaleElementReferenceException e){
            reinitializeElement();
            return ele.isSelected();
        }

    }

    @Override
    public boolean isEnabled() {
        try {
            return ele.isEnabled();
        }catch (StaleElementReferenceException e){
            reinitializeElement();
            return ele.isEnabled();
        }
    }

    @Override
    public String getText() {
        String text = null;
        try{
            waitForElement();
            text =  ele.getText();
        }catch (StaleElementReferenceException e){
            reinitializeElement();
            text =  ele.getText();
        }
        return text;
    }

    @Override
    public List<WebElement> findElements(By by) {
        try {

            return driver.findElements(by);
        }catch (StaleElementReferenceException e){
            reinitializeElement();
            return driver.findElements(by);
        }

    }

    @Override
    public WebElement findElement(By by) {
        try {
            return driver.findElement(by);
        }catch (StaleElementReferenceException e){
            reinitializeElement();
            return driver.findElement(by);
        }
    }

    @Override
    public boolean isDisplayed() {
        try {
            return ele.isDisplayed();
        }catch (StaleElementReferenceException e){
            reinitializeElement();
            return ele.isDisplayed();
        }
    }

    @Override
    public Point getLocation() {
        try {
            return ele.getLocation();
        }catch (StaleElementReferenceException e){
            reinitializeElement();
            return ele.getLocation();
        }
    }

    @Override
    public Dimension getSize() {
        try {
            return ele.getSize();
        }catch (StaleElementReferenceException e){
            reinitializeElement();
            return ele.getSize();
        }
    }

    @Override
    public Rectangle getRect() {
        try {
            return ele.getRect();
        }catch (StaleElementReferenceException e){
            reinitializeElement();
            return ele.getRect();
        }

    }

    @Override
    public String getCssValue(String propertyName) {
        try {
            return ele.getCssValue(propertyName);
        }catch (StaleElementReferenceException e){
            reinitializeElement();
            return ele.getCssValue(propertyName);
        }
    }

    @Override
    public <X> X getScreenshotAs(OutputType<X> target) throws WebDriverException {
        try {
            return ele.getScreenshotAs(target);
        }catch (StaleElementReferenceException e){
            reinitializeElement();
            return ele.getScreenshotAs(target);
        }
    }

}
