package org.core.component.pages.Markdown;

public class MarkdownCannotReadFileException extends Exception{
    public MarkdownCannotReadFileException(String message) {
        super(message);
    }
}
