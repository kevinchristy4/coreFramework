package org.core.component.pages.FSS;

import org.core.component.BaseFunc;
import org.core.component.elements;
import org.core.component.pages.HomePage;
import org.core.component.wait;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.testng.Assert;
import org.testng.SkipException;

public class FSSMain extends BaseFunc {

    private String fssHeaderXpath = "//span[@class='logo-text' and text()='Full Service Selling (FSS)']";
    private String noZoneMessage = "//div[contains(@class,'searchError') and contains(.,'No Zones')]";
    private String zoneSelector = "//input[@name='zone']/..//label[text()='%1$s']";
    private String zoneTypeXpath = "//span[@class='subtitle-text']";
    private String searchBySize = "//label[text()='Size']";
    private String subOptionActive = "//a[@class='active item']";
    private String subOptionInActive = "//a[@class='item']";
    private String genderSelector = "//label[text()='%1$s']";
    private String widthDropDown = "//span[text()='WIDTH']/../..//div[@role='listbox']";
    private String widthOptionSelector =
        "//div[contains(@class,'WidthSelector')]//div[@role='option' and text()='%1$s']";
    private String sizeDropDown = "//span[text()='SIZE']/../..//div[@role='listbox']";
    private String sizeOptionSelector = "//div[@role='option' and text()='%1$s']";
    private String searchButton = "//div[@class='button-content' and text()='Search']";
    private String productSelectorByOrder = "//div[@class='productCardContainer '][%1$s]//div[@class='productName']";
    private String productDetailsHeader = "//span[@class='logo-text' and text()='Product Details']";
    private String addToBagSelector = "//div[@class='button-content' and text()='Add To Bag']";
    private String existingCustomerName =
        "//div[contains(@class,'CustomersModalListItem__name')]//div[contains(.,'%1$s')]";
    private String addNewCustomerInput = "//input[@placeholder='Add customer']";
    private String addBagNewCustomer = "//button[contains(@class,'secondary')]//div[text()='Add To Bag']";
    private String sendBagButton = "//div[text()='Send Bag']";
    private String sendButtonWait = "//button[@class='ui small button secondary']";
    private String sendButtonWaitDisAbled = "//button[@class='ui small disabled button secondary']";
    private String addToBagPopUpHeder = "//div[@class='header' and text()='Add to Bag']";
    public Boolean isRetryCalled = false;
    private String qtyDropDownCollapsed = "//span[text()='QTY']/../..//div[@class='ui selection dropdown']";
    private String qtyDropDownExpand = "//div[@class='ui active visible selection dropdown']";
    private String itemQtySelector = "//div[@class='visible menu transition']//div[@role and text()='%1$s']";
    private String selectedQty = "//span[text()='QTY']/../..//div[@class='ui selection dropdown']//div[@role='alert']";
    private String enterUpcOrWebId = "//input[@placeholder='Scan or enter UPC / WebID']";
    private String productStatusInLite = "//div[@class='productStatus']/span";
    private String itemNotFound = "//div[@class='ui-swipe-content-hidden']";
    private String enterUpc = "//input[@placeholder='Scan or enter UPC / WebID']";

    public FSSMain() throws Exception {
        wait.waitForPage();
        Assert.assertTrue(new elements(By.xpath(fssHeaderXpath), "FSS Header").isDisplayed());
        log.info("User in FSS Page");
    }

    public void selectZone(String zoneName, String zoneType) throws Exception {

        retryIfNoData();
        tryAgainPopUp();

        elements zone = new elements(By.xpath(String.format(zoneSelector, zoneName)), "Select Zone Radio Button");
        scrollIntoView(String.format(zoneSelector, zoneName));
        zone.click();
        String actualZoneType = new elements(By.xpath(zoneTypeXpath), "Zone Type").getText();
        Assert.assertTrue(actualZoneType.equals(zoneType),
            String.format("Expected type = %1$s but actual type = %2$s", zoneType, actualZoneType));
        log.info("Zone Selected");
    }

    public void retryIfNoData() throws Exception {
        wait.waitForPage();
        if (!isElementNotDisplayed(By.xpath(noZoneMessage))) {
            isRetryCalled = true;
            clickBackArrow();
            wait.waitForPage();
            new HomePage().selectService(HomePage.serviceOptions.SHOES_SALES);
            new HomePage().selectServiceSection("Full Service Selling (FSS)");
            if (!isElementNotDisplayed(By.xpath(noZoneMessage))) {
                throw new SkipException("No Data to select Zone");
            }
        }
    }

    public void tryAgainPopUp() throws Exception {
        wait.waitForPage();
        if (!isElementNotDisplayed(By.xpath("//div[contains(@class,'Modal_headerTitleError')]"))) {
            new elements(By.xpath("//div[@class='button-content' and text()='Try Again']"), "Try again").click();
        }
    }

    public Boolean isRetried(){
        Boolean toReturn = isRetryCalled;
        isRetryCalled = false;
        return toReturn;
    }

    public void searchType(String option) throws Exception {

        String selectedItem = new elements(By.xpath(subOptionActive), "Active Option").getText();
        if (!selectedItem.equals(option)) {
            new elements(By.xpath(subOptionInActive), "Select other option").click();
        } else {
            log.info("Option already in selected state");
        }

    }

    public void searchBySize(String gender, String width, String size) throws Exception {

        new elements(By.xpath(searchBySize), "Size radio button").click();
        if (isElementNotDisplayed(By.xpath(widthDropDown))) {
            searchType("Customers");
            searchType("Search By");
            new elements(By.xpath(searchBySize), "Size radio button").click();
        }
        new elements(By.xpath(String.format(genderSelector, gender.toUpperCase())), "Gender selector").click();
        new elements(By.xpath(widthDropDown), "Width dropdown Opener").click();
        scrollToBottom();
        new elements(By.xpath(String.format(widthOptionSelector, width)), "Width option selector").click();
        new elements(By.xpath(sizeDropDown), "Size dropdown Opener").click();
        scrollToBottom();
        new elements(By.xpath(String.format(sizeOptionSelector, size)), "Size option selector").click();
        new elements(By.xpath(searchButton), "Search Button").click();
        wait.waitForPage();


    }

    public String selectProductByOrder(String orderOfProduct) throws Exception {

        wait.waitForAppElement(By.xpath(String.format(pageHeaderXpath, "Search Results")));
        elements product =
            new elements(By.xpath(String.format(productSelectorByOrder, orderOfProduct)), "Product selector");
        String nameOfProduct = product.getText();
        product.click();
        wait.waitForAppElement(By.xpath(productDetailsHeader));
        return nameOfProduct;

    }

    public void selectProductQuantity(String quantity) throws Exception {

        new elements(By.xpath(qtyDropDownCollapsed), "QTY dropdown").click();
        if (new elements(By.xpath(qtyDropDownExpand), "QTY dropdown expanded").isDisplayed()) {
            new elements(By.xpath(String.format(itemQtySelector, quantity)),
                String.format("Quantity selected - %1$s", quantity)).click();
        } else {
            log.error("QTY dropdown not expanded on click");
        }
        if (new elements(By.xpath(qtyDropDownCollapsed), "QTY dropdown collapsed").isDisplayed()) {
            try {
                Assert.assertTrue(new elements(By.xpath(selectedQty), "Selected Quantity").getText().equals(quantity));
            } catch (AssertionError e) {
                log.error("Selected Quantity not reflected in UI");
            }
        } else {
            log.error("QTY dropdown not collapsed on selection");
        }

    }

    public String clickAddToBag() throws Exception {

        String textUPC = new elements(By.xpath("//i[contains(@class,'macys barcode')]/.."), "UPC").getText();
        System.out.println(textUPC);
        scrollToBottom();
        new elements(By.xpath(addToBagSelector), "Add to Bag button").click();
        return textUPC;
    }

    public void addToCustomerBag(String customerName) throws Exception {

        wait.waitForPage();
        wait.waitForAppElement(By.xpath(addToBagPopUpHeder));
        scrollToBottom();
        sleep(3);
        if (!isElementNotDisplayed(By.xpath(String.format(existingCustomerName, customerName)))) {
            new elements(By.xpath(String.format(existingCustomerName, customerName)), "Existing customer Present")
                .click();
        } else {
            new elements(By.xpath(addNewCustomerInput), "Add new Customer").sendKeys(customerName);
            new elements(By.xpath(addBagNewCustomer), "Click Add to Bag for new cusotmer").click();
        }
        wait.waitForPage();

    }

    public void sendBag(String customerName) throws Exception {

        wait.waitForAppElement(By.xpath(sendButtonWait));
        Assert.assertTrue(getPageHeader().contains(customerName), "Customer name does not match");
        new elements(By.xpath(sendBagButton), "Send Bag Button").click();
        wait.waitForAppElement(By.xpath(sendButtonWaitDisAbled));
        wait.waitForToast();
    }

    public void searchByUPC(String upcOrWebId ) throws Exception {

        new elements(By.xpath(enterUpcOrWebId), "Enter UPC").sendKeys(upcOrWebId + Keys.RETURN);

    }

    public void fssNotFound() throws Exception{
        wait.waitForPage();
        scrollIntoView(itemNotFound);
        new elements(By.xpath(itemNotFound),"Not Found button").click();
        wait.waitForAppElement(By.xpath(productStatusInLite));
        Assert.assertTrue(new elements(By.xpath(productStatusInLite),"Item Not Found").isDisplayed(), "Item has marked as Not Found successfully!");
    }

    public void fssLitePullItem(String upc) throws Exception {
        wait.waitForPage();
        int spaceIndex = upc.indexOf(' ');
        String srtUpc = upc.substring(0,spaceIndex);
        String itemXpath = String.format("//span[contains(normalize-space(.), '%1$s')]//parent::span//div[@class='productFooter']//div[contains(@class,'link')]",srtUpc);

        elements pullItem = new elements(By.xpath(itemXpath),"pull item");
        scrollIntoView(itemXpath);
        pullItem.click();
        wait.waitForElementDisapper(By.xpath(itemXpath));
    }


    public void enterUpc(String upc) throws Exception{
        wait.waitForPage();
        new elements(By.xpath(enterUpc),"Enter Upc").click();
        new elements(By.xpath(enterUpc),"Enter Upc").sendKeys(upc + Keys.ENTER);
        wait.waitForPage();
    }

}
