package org.core.component;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class elements extends BaseFunc {
    public elements(By locator, String name) throws Exception {
        super(locator, name);
    }

    public elements(By locator) throws Exception {
        super(locator);
    }

    public elements() throws Exception {

    }

    public elements(WebElement element) throws Exception {
        super(element);
    }

}
