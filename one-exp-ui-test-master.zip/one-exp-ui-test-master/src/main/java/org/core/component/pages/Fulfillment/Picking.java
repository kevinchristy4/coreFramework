package org.core.component.pages.Fulfillment;

import org.core.component.BaseFunc;
import org.core.component.elements;
import org.core.component.wait;
import org.openqa.selenium.By;

public class Picking extends BaseFunc {

    private String heading = "Picking Zones";
    private String selectAll = "//div[@class = 'button-content' and text()='Select All']";
    private String save = "//i[contains(@class,'building save')]";
    private String pickingUnitsHeader = "//span[@class = 'logo-text' and text()='Picking Units']";
    public Picking() throws Exception {
        wait.waitForPage();
//        Assert.assertTrue(new elements(By.xpath(String.format(pageHeaderXpath,heading)),"Picking Header").isDisplayed());
        log.info("User in Fulfillment - Picking");
    }

    public void saveAllZones() throws Exception {
        new elements(By.xpath(selectAll),"Select All").click();
        new elements(By.xpath(save),"Save").click();
        wait.waitForAppElement(By.xpath(pickingUnitsHeader));
    }


}
