package org.core.component.pages.Markdown;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.spanner.DatabaseClient;
import com.google.cloud.spanner.DatabaseId;
import com.google.cloud.spanner.Spanner;
import com.google.cloud.spanner.SpannerOptions;
import org.core.util.MarkDown.AppProperties;
import lombok.Data;

@Data
public class MarkdownDbClient {
    Spanner spanner;
    DatabaseId db;
    DatabaseClient dbClient;

    public MarkdownDbClient() throws FileNotFoundException, IOException {
        AppProperties props = new AppProperties();
        GoogleCredentials credentials = GoogleCredentials.fromStream(new FileInputStream(
            props.readProperty(AppProperties.GCP_APP_USER_CREDENTIALS)
    ));
        SpannerOptions options = SpannerOptions.newBuilder().setCredentials(credentials).build();
        spanner = options.getService();
        String env = props.readProperty(AppProperties.ENVIRONMENT).toUpperCase();
        String dbName = env.equals("DEV") ? props.readProperty(AppProperties.DB_NAME_DEV) :
                env.equals("QA") ? props.readProperty(AppProperties.DB_NAME_QA) :
                        env.equals("UAT") ? props.readProperty(AppProperties.DB_NAME_UAT) : "";
        System.out.println("Connecting to spanner - Environment: " + env + " - database: " + dbName);
        this.db = DatabaseId.of(props.readProperty(AppProperties.PROJECT_NAME),
                props.readProperty(AppProperties.DB_INSTANCE),
                dbName);
        if (!db.getInstanceId().getProject().equals(props.readProperty(AppProperties.PROJECT_NAME))) {
            System.err.println(
                    "Invalid project specified. Project in the database id should match the"
                            + "project name set in the environment variable GOOGLE_CLOUD_PROJECT. Expected: "
                            + props.readProperty(AppProperties.PROJECT_NAME));
        } else {
            dbClient = spanner.getDatabaseClient(db);
        }
    }

    public void closeConnection() {
        spanner.close();
    }

}
