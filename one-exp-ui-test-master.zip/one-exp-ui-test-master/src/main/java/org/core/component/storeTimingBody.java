package org.core.component;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;

public class storeTimingBody {

    public static String body = "{\n" +
            "    \"name\": \"Macy's Herald Square\",\n" +
            "    \"address\": {\n" +
            "        \"id\": 70,\n" +
            "        \"line1\": \"151 West 34th Street\",\n" +
            "        \"line2\": \"\",\n" +
            "        \"line3\": \"\",\n" +
            "        \"city\": \"New York\",\n" +
            "        \"state\": \"NY\",\n" +
            "        \"zipCode\": \"10001\",\n" +
            "        \"countryCode\": \"USA\"\n" +
            "    },\n" +
            "    \"locationNumber\": 10,\n" +
            "    \"storeNumber\": 3,\n" +
            "    \"divisionId\": 71,\n" +
            "    \"workingHour\": {\n" +
            "        \"openTime\": \"00:01\",\n" +
            "        \"closeTime\": \"23:59\",\n" +
            "        \"operationDate\": \"%1$s\",\n" +
            "        \"curbsideOpenTime\": \"00:03\",\n" +
            "        \"curbsideCloseTime\": \"23:59\"\n" +
            "    },\n" +
            "    \"mapUrl\": \"http://maps.googleapis.com/maps/api/staticmap?format=JPEG&zoom=14&size=400x400&sensor=false&markers=icon:http://www.macys.com/dyn_img/google_maps/no_letter_red_icon_2.png%7C40.750787,%20-73.988959&client=gme-macysinc&signature=mhdyaKDw6Cnkih4RfNUVObwzqy4%3D\",\n" +
            "    \"geoLocation\": {\n" +
            "        \"latitude\": 40.750787,\n" +
            "        \"longitude\": -73.988959\n" +
            "    },\n" +
            "    \"phoneNumber\": \"212-695-4400\",\n" +
            "    \"walkupInstruction\": \"\",\n" +
            "    \"pickupInstruction\": \"\",\n" +
            "    \"driveupInstruction\": \"\",\n" +
            "    \"currentTime\": \"%1$s 14:50:42.336943\",\n" +
            "    \"attributes\": {\n" +
            "        \"attribute\": [\n" +
            "            {\n" +
            "                \"name\": \"CURBSIDE_PICKUP\",\n" +
            "                \"value\": [\n" +
            "                    \"TRUE\"\n" +
            "                ]\n" +
            "            },\n" +
            "            {\n" +
            "                \"name\": \"DAYLIGHT_SAVINGS_INDICATOR\",\n" +
            "                \"value\": [\n" +
            "                    \"TRUE\"\n" +
            "                ]\n" +
            "            },\n" +
            "            {\n" +
            "                \"name\": \"GMT_OFFSET\",\n" +
            "                \"value\": [\n" +
            "                    \"5\"\n" +
            "                ]\n" +
            "            },\n" +
            "            {\n" +
            "                \"name\": \"IN_STORE_PICKUP\",\n" +
            "                \"value\": [\n" +
            "                    \"TRUE\"\n" +
            "                ]\n" +
            "            }\n" +
            "        ]\n" +
            "    }\n" +
            "}";

    public static String getCurrentStoreTime() throws JSONException {

        String date = new SimpleDateFormat("yyyy-dd-MM").format(new Date());
        System.out.println(date);
        JSONObject jsonObject = new JSONObject(body);
        jsonObject.put("currentTime",String.format(jsonObject.getString("currentTime"),date));
        JSONObject jsonObject1 = jsonObject.getJSONObject("workingHour");
        jsonObject1.put("operationDate",date);
        jsonObject.put("workingHour",jsonObject1);
        return jsonObject.toString();
    }
}
