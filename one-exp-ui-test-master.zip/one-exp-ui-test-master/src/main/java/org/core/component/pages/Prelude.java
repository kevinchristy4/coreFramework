package org.core.component.pages;

import com.google.cloud.bigquery.TableResult;
import org.core.component.BQanalytics;
import org.core.component.BaseFunc;
import org.core.component.elements;
import org.core.component.wait;
import org.core.util.BQdataValidator;
import org.core.util.EventDataParser;
import org.core.util.PropertiesHandler;
import org.openqa.selenium.By;
import org.testng.Assert;

public class Prelude extends BaseFunc {


    public Prelude() throws Exception {
        log.info("Prelude events test");
    }

    private String preludeHeader = "//div[@class = 'prelude-header-title']";
    private String versionHeader = "//div[@class = 'prelude-header-title' and text()='OneX version check']";
    private String locationChecked = "//div[@data-testid = 'div-opt-divisions']//div[contains(@class,'checked')]";
    private String alertsChecked = "//div[contains(@class,'checked')]";
    private String alertsCheckbox = "//input/../label";
    private String versionMessageTitle = "OneX version check";
    private String versionMessageSubTitle = "New version is now available";
    private String versionMessage = "Please be advised that this device does not have the latest version of OneX and may not display all the Fulfillment product images.";
    private String preludeHeaderSubTitle = "//div[@class = 'prelude-header-subtitle']";
    private String preludeMessage = "//div[@class = 'prelude-content']//div//div";
    private Boolean verifyVersionCheckEvent = false;
    private String preludeFrame = "//div[@class='prelude-header']";
    private String browserExecution = PropertiesHandler.getProperties().getProperty("runInBrowser");
    private String osUpdatePopUP = "//div[text()='OS Update Required']/..//button//div[text()='Ok']";

    public enum location{
        MACYS("Macy's"),
        BACKSTAGE("Macy's Backstage");
        private String i;
        location(String i) {
            this.i = i;
        }
        private String getVal(){
            return i;
        }
    }


    public void setLocation(location loc) throws Exception {


        String title = new elements(By.xpath(preludeHeader),"location header").getText();
        Assert.assertEquals(title,"Location","Location Title Does not Match");
        clickLabelWithText(loc.getVal());
        log.info("Location set to "+loc.getVal());

    }

    public void setAlerts(Boolean val) throws Exception {

        String title = new elements(By.xpath(preludeHeader),"prelude header").getText().toString();
        Assert.assertEquals(title,"Get Alerts","Alerts Title Does not Match");

        Boolean checkStatus = (!new elements().isElementNotDisplayed(By.xpath(alertsChecked)));

        if(!(checkStatus && val)){
            new elements(By.xpath(alertsCheckbox),"Alert checkbox").click();
            Boolean checkStatusAfterClick = (!new elements().isElementNotDisplayed(By.xpath(alertsChecked)));
            if(checkStatusAfterClick == checkStatus){
                log.error("Alerts are not changed");
            }
//            log.info("Alerts are set to "+ val);
        }
//        log.info("Alerts are expected to be"+ val);

    }

    public void connectDevices() throws Exception {

        String title = new elements(By.xpath(preludeHeader),"prelude header").getText().toString();
        Assert.assertEquals(title,"Connect Devices","Connect device page Title Does not Match");

    }

    private void closeOsUpdatePopUp() throws Exception {
        if(browserExecution.equalsIgnoreCase("true")) {
            new elements(By.xpath(osUpdatePopUP), "Os update PopUp").click();
        }
    }

    public void preludeOptions(location location, Boolean alerts) throws Exception {

        wait.waitForAppElement(By.xpath(preludeFrame));
        verifyVersionWarning();

        wait.waitForPage();
        setLocation(location);
        clickElementWithText("Next");

        wait.waitForPage();
        setAlerts(alerts);
        clickElementWithText("Next");

        wait.waitForPage();
        closeOsUpdatePopUp();
        connectDevices();
        clickElementWithText("Skip Connection");

        wait.waitForPage();

    }

    public void verifyPreludeEvents(Boolean SubscribeNotification) throws Exception {

        String eventDataLoc = "src/main/resources/EventsData/FoundationsEvent.json";

        sleep(3);
        BQanalytics bq = new BQanalytics();
        TableResult results = bq.getCurrentSessionEntries();
        Assert.assertTrue(new BQdataValidator().verifyEventIsPresentInResults(results, EventDataParser.getEventDatafor(eventDataLoc,"OneXlogin"),1));
        Assert.assertTrue(new BQdataValidator().verifyEventIsPresentInResults(results, EventDataParser.getEventDatafor(eventDataLoc,"SwitchDivisionPrelude"),1));
        Assert.assertTrue(new BQdataValidator().verifyEventIsPresentInResults(results, EventDataParser.getEventDatafor(eventDataLoc,"RegisterDevice"),1));
        if(SubscribeNotification){
            Assert.assertTrue(new BQdataValidator().verifyEventIsPresentInResults(results, EventDataParser.getEventDatafor(eventDataLoc,"SubscribeNotificationPrelude"),1));
        }
        if(verifyVersionCheckEvent){
            Assert.assertTrue(new BQdataValidator().verifyEventIsPresentInResults(results, EventDataParser.getEventDatafor(eventDataLoc,"VersionCheck"),1));
        }
    }

    public void verifyVersionWarning() throws Exception {


        if(!isElementNotDisplayed(By.xpath(versionHeader))){
            String subTitle = new elements(By.xpath(preludeHeaderSubTitle),"Version Message Header").getText();
            Assert.assertEquals(subTitle,versionMessageSubTitle,"Version message sub title does not match");

            String message = new elements(By.xpath(preludeMessage),"Version Message Header").getText();
            Assert.assertEquals(message,versionMessage,"Version message does not match");
            verifyVersionCheckEvent = true;
            clickElementWithText("Next");
        }else {
            log.info("Version Warning Page is not displayed");
        }
    }

}
