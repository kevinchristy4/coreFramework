package org.core.component;

import org.core.driver.Browserfactory;
import org.core.driver.onexApp;
import org.core.util.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public abstract class wait{


    private Logger log = Logger.getLogger();


    public static void waitForPage() throws Exception {
        new WebDriverWait(new onexApp().getDriver(), Duration.ofSeconds(120)).until(driver -> {
            Boolean isPageLoaded = false;
            try {
                Object isDocumentReady = ((JavascriptExecutor)
                        driver).executeScript("return document.readyState");
                if (isDocumentReady.toString().equals("complete")){
                    isPageLoaded =  true;
                }
            } catch (Exception e) {
                System.out.println(e);
            }
            return isPageLoaded;
        });
    }

    public static void waitForBrowserPage() throws Exception {
        new WebDriverWait(Browserfactory.getDriver(), Duration.ofSeconds(120)).until(driver -> {
            Boolean isPageLoaded = false;
            try {
                Object isDocumentReady = ((JavascriptExecutor)
                        driver).executeScript("return document.readyState");
                if (isDocumentReady.toString().equals("complete")){
                    isPageLoaded =  true;
                }
            } catch (Exception e) {
                System.out.println(e);
            }
            return isPageLoaded;
        });
    }

    public static Boolean waitForAppElement(By locator) throws Exception {
        WebDriverWait wait = new WebDriverWait(new onexApp().getDriver(),Duration.ofSeconds(40));
//        wait.until(ExpectedConditions.visibilityOf(new onexApp().getDriver().findElement(locator)));
        wait.until(ExpectedConditions.presenceOfElementLocated(locator));
        return  new onexApp().getDriver().findElement(locator).isDisplayed();
    }

    public static Boolean waitForURL(String url) throws Exception {
        return new WebDriverWait(new onexApp().getDriver(), Duration.ofSeconds(20)).until(ExpectedConditions.urlContains(url));
    }

    public static void waitForToast() throws Exception {
        WebDriverWait wait = new WebDriverWait(new onexApp().getDriver(),Duration.ofSeconds(10));
        wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//span[@class='toast-title']")));
    }
    
    public static void waitForElementToBeClickable(By locator) throws Exception {
        WebDriverWait wait = new WebDriverWait(new onexApp().getDriver(),Duration.ofSeconds(30));
        wait.until(ExpectedConditions.elementToBeClickable(locator));
    }

    public static void waitForElementDisapper(By locator) throws Exception {
        WebDriverWait wait = new WebDriverWait(new onexApp().getDriver(),Duration.ofSeconds(10));
        wait.until(ExpectedConditions.invisibilityOfElementLocated(locator));
    }



}
