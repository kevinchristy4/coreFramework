package org.core.component.pages.Markdown;

import org.core.component.BaseFunc;
import org.core.component.elements;
import org.core.component.wait;
import org.openqa.selenium.By;
import org.testng.Assert;

public class Ticketing extends BaseFunc {

    private String header = "Create Ticketing";
    private String createListButton = "//div[@class='button-content' and text()='Create List']";
    private String ticketingHeader = "Ticketing List";

    public Ticketing() throws Exception {
        wait.waitForPage();
        skipConnection();
        Assert.assertTrue(new elements(By.xpath(String.format(pageHeaderXpath,header)),"Ticketing header").isDisplayed());
        log.info("User in Markdown - Ticketing");
    }

    public void clickCreateListButton() throws Exception {

        wait.waitForPage();
        log.info("Creating Ticketing list");
        new elements(By.xpath(createListButton),"Create List").click();

    }

    public void verifyTicketingListPage() throws Exception {

        wait.waitForPage();
        if(new elements(By.xpath(String.format(pageHeaderXpath,ticketingHeader)),"Page Header").isDisplayed()){
            log.info("User in Ticketing list page");
        }else {
            log.error("User is not navigated to Ticketing list page");
        }
    }






}
