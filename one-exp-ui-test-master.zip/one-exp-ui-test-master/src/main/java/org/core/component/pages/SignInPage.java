package org.core.component.pages;

import org.core.component.BaseFunc;
import org.core.component.elements;
import org.core.component.wait;
import org.core.driver.onexApp;
import org.core.util.PropertiesHandler;
import org.core.util.locker;
import org.openqa.selenium.By;
import org.testng.SkipException;

public class SignInPage extends BaseFunc {

    private String signInBtn = "//div[text()='Sign In']";
    private String usrNm = "//input[@id='idToken2']";
    private String pswrd = "//input[@id='idToken3']";
    private String loginBtn = "//input[@id='loginButton_0']";
    private String browserExecution = PropertiesHandler.getProperties().getProperty("runInBrowser");


    public SignInPage() throws Exception {
        log.info("User in SignIn page");
    }


    public void clickSign() throws Exception {

        if(browserExecution != null && browserExecution.equalsIgnoreCase("false")){
            setCurrentContext();
        }
        wait.waitForPage();
        wait.waitForAppElement(By.xpath(signInBtn));
        new elements().clickWithoutWait(By.xpath(signInBtn),"Sign In");
        sleep(8);

    }

    public void loginWithCredentials() throws Exception {

        if(browserExecution != null && browserExecution.equalsIgnoreCase("false")){
            setCurrentContext();
        }
        wait.waitForPage();
        wait.waitForAppElement(By.xpath(loginBtn));

        new elements(By.xpath(usrNm),"User Name").sendKeys(PropertiesHandler.getProperties().getProperty("userName"));
        new elements(By.xpath(pswrd),"Password").sendKeys(locker.decode64(PropertiesHandler.getProperties().getProperty("passWord")));
        new elements().clickWithAction(By.xpath(loginBtn),"Login");
        sleep(2);

        if(browserExecution != null && browserExecution.equalsIgnoreCase("false")){
            new elements().clickWithAction(By.xpath(loginBtn),"Login");
        }

        sleep(2);
        wait.waitForURL(PropertiesHandler.getProperties().getProperty("envURL"));

        if(getTitleAndUrl().get(1).toString().contains("secureqa")){
            log.error("Invalid credentials");
            throw new SkipException("Invalid credentials - skipping test execution");
        }
        else {
            log.info("Login Successful");
        }

    }
}
