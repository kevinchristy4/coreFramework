package org.core.component.pages;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidStartScreenRecordingOptions;
import org.apache.commons.io.FileUtils;
import org.core.component.BQanalytics;
import org.core.component.BaseFunc;
import org.core.driver.Browserfactory;
import org.core.driver.onexApp;
import org.core.util.Logger;
import org.core.util.PropertiesHandler;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.*;

import java.io.File;
import java.time.Duration;
import java.util.Base64;

public class BasePage extends BaseFunc {

    private Logger log = Logger.getLogger();
    private WebDriver driver;
    private String browserExecution = PropertiesHandler.getProperties().getProperty("runInBrowser");
    private boolean signInComplete = false;

    public BasePage() throws Exception {
    }

    @Parameters({"location","alerts"})
    @BeforeSuite
    public void setup(Prelude.location location,Boolean alerts) throws Exception {

        //Do not add logs before or in between the below two lines it sometimes slows down the tapping action
        onexApp onex = new onexApp(15);
        driver = onex.getDriver();

        log.info("----------Drivers Initialized-------------------");

        if(browserExecution != null && browserExecution.equalsIgnoreCase("false")){
            log.info("-------Selecting environment and store location in app config page--------");
            ConfigPage launchPage = new ConfigPage();
            launchPage.selectEnv(PropertiesHandler.getProperties().getProperty("envURL"),PropertiesHandler.getProperties().getProperty("division"),PropertiesHandler.getProperties().getProperty("store"),null);
        }
        else {
            log.info("--------Navigating to OneX in browser----------");
            onex.launchApp();
            onex.setLocInfoInBrowserStorage(PropertiesHandler.getProperties().getProperty("division"),PropertiesHandler.getProperties().getProperty("store"),PropertiesHandler.getProperties().getProperty("location"));
        }

        log.info("----------Establishing BigQuery Connection--------------");
        new BQanalytics().getLastEntry(PropertiesHandler.getProperties().getProperty("bqUserID"));

        log.info("-------SignIn Actions----------");
        SignInPage signInPage = new SignInPage();
        signInPage.clickSign();
        signInPage.loginWithCredentials();

        log.info("--------Prelude Actions-----------");
        Prelude prelude = new Prelude();
        prelude.preludeOptions(location,alerts);
        signInComplete = true;
        log.info("---------Prelude completed---------------");

    }


    @AfterSuite
    public void end() throws Exception {

        if(signInComplete){
            goToPreferences();
            Preferences preferences = new Preferences();
            preferences.logout();
        }
        driver.quit();

    }
}
