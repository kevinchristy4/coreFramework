package org.core.component.pages;

import org.core.component.BaseFunc;
import org.core.component.elements;
import org.core.component.wait;
import org.core.driver.onexApp;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import java.time.Duration;

public class Preferences extends BaseFunc {

    private String preferencesIconXpath = "//img[@id='onex-preferences-icon']";
    private String logoutXpath = "//div[@id='pref-list-item-title-Sign Out' and text()='Sign Out']";
    private String signOutPopupxpath = "//div[@id='signout-popup']";
    private String logoutYesXpath = "//div[@class='button-content' and text()='Yes']";
    private String clickOnOptions = "//div[@id = 'pref-list-item-link-%1$s']";
    private String applicationInfoHeader = "//span[@class='logo-text' and text()='Application Info']";
    private String detailsList = "//span[contains(.,'%1$s')]/following-sibling::span";
    private String preferencesHeader = "//div[@id='pref-page-header']";
    private String rnInfoHeader = "//span[@class='logo-text' and text()='Release Notes']";
    private String rnUpdatesHeader = "//div[text()='Current Updates']";
    private String backButton = "//div[@id='pref-page-header']//div[text()='BACK']";
    private String getCurDivision = "//div[contains(@id,'subheader-division')]";
    private String switchDivHeader = "//span[text()='Switch Division']";
    private String selectedDiv = "//input[@checked]/..";
    private String divisionButton = "//div[contains(@data-testid,'%1$s')]";
    private String switchDivPopup = "//div[@id='sws-popup']//div[text()='%1$s']";
    private String popUpHeader = "//div[@id='sws-popup']";
    private String prefBackBtn = "//div[@id='preferences-back-btn']//i";

    public enum options{
        applicationinfo,
        division,
        alerts,
        releasenotes
    }

    public enum Division{
        MACYS("71"),
        MACYS_BACKSTAGE("77");
        private String s;
        Division(String s) {
            this.s = s;
        }
        public String getString(){
            return s;
        }

    }
    public Preferences() throws Exception {
        wait.waitForPage();
        Assert.assertTrue(new elements(By.xpath(preferencesHeader),"Preferences Header").isDisplayed());
        log.info("User in Preferences Page");
    }

    public void clickOnOption(options option) throws Exception {

//        scrollIntoView();
        elements options = new elements(By.xpath(String.format(clickOnOptions,option.name())),"Preferences Option");
        options.scrollIntoView(String.format(clickOnOptions,option.name()));
        sleep(3);
        options.click();
        wait.waitForPage();
    }

    public void verifyAppInfo(String division,String storeNum,String loc,String id,String name,String uiVersion, String halVersion, String url, String middleware) throws Exception {

        wait.waitForPage();

        Assert.assertTrue(new elements(By.xpath(applicationInfoHeader),"Application info header").isDisplayed(),"Application info heading does not match");
        Assert.assertEquals(new elements(By.xpath(String.format(detailsList,"Division Number")),"Division Number").getText(),division,"Division number does not match");
        Assert.assertEquals(new elements(By.xpath(String.format(detailsList,"Store Number")),"Store Number").getText(),storeNum,"Store number does not match");
        Assert.assertEquals(new elements(By.xpath(String.format(detailsList,"Location Number")),"Location Number").getText(),loc,"Location Number does not match");
        Assert.assertEquals(new elements(By.xpath(String.format(detailsList,"Colleague ID")),"Colleague ID").getText(),id,"Colleague ID does not match");
        Assert.assertTrue(new elements(By.xpath(String.format(detailsList,"Colleague Name")),"Colleague Name").getText().contains(name),"Colleague Name does not match");
//        Assert.assertEquals(new elements(By.xpath(String.format(detailsList,"Store-UI Version")),"Store-UI Version").getText(),uiVersion,"Store-UI Version does not match");
//        Assert.assertEquals(new elements(By.xpath(String.format(detailsList,"HAL Android Version")),"HAL Android Version").getText(),halVersion,"HAL Android Version does not match");
        Assert.assertEquals(new elements(By.xpath(String.format(detailsList,"UI Endpoint")),"UI Endpoint").getText(),url,"UI Endpoint does not match");
//        Assert.assertEquals(new elements(By.xpath(String.format(detailsList,"Middleware Endpoint")),"Middleware Endpoint").getText(),middleware,"Middleware Endpoint does not match");

    }

    public void verifyReleaseNotes() throws Exception {

        wait.waitForPage();
        Assert.assertTrue(new elements(By.xpath(rnInfoHeader),"Release Notes header").isDisplayed(),"Release notes heading does not match");
        Assert.assertTrue(new elements(By.xpath(rnUpdatesHeader),"Release Notes Updates header").isDisplayed(),"Release notes updates heading does not match");

    }

    public void clickBackMarkDownPref() throws Exception {
        new elements(By.xpath(backButton),"Preferences Back button").click();
    }

    public void clickBackPref() throws Exception {
        new elements(By.xpath(prefBackBtn),"Preferences Back button").click();
    }

    public void switchDivision(Division division) throws Exception {

        if(division.getString().equals(getCurrentDivisionNumber())){
            log.error(String.format("User already in given division - %1$d",division.getString()));
        }else {
            log.info("Selecting division");
            sleep(3);
            clickOnOption(options.division);
            wait.waitForAppElement(By.xpath(switchDivHeader));
            Assert.assertTrue(!new elements(By.xpath(selectedDiv),"Selected Division").getAttribute("data-testid").replaceAll("\\D","").equals(division.getString()),"Given Division radio button is already selected");
            log.info("Accept popup message");

            new elements(By.xpath(String.format(divisionButton,division.getString())),"Division Button").click();
            acceptSwitchDivision(true);
            Assert.assertTrue(new elements(By.xpath(selectedDiv),"Selected Division").getAttribute("data-testid").replaceAll("\\D","").equals(division.getString()),"Given Division button cannot be selected");
            new elements(By.xpath(prefBackBtn),"Preferences back button").click();

            log.info("Verify if division is switched");
            Assert.assertTrue(getCurrentDivisionNumber().equals(division.getString()));
        }

    }

    public void acceptSwitchDivision(Boolean yN) throws Exception {
        wait.waitForAppElement(By.xpath(popUpHeader));
        String opt = yN ? "Yes" : "No";
        new elements(By.xpath(String.format(switchDivPopup,opt)),"Switch Division Popup").click();
    }

    public String getCurrentDivisionNumber() throws Exception {

        return new elements(By.xpath(getCurDivision),"Current Division").getText().replaceAll("\\D", "");
    }



    public void logout() throws Exception {
        elements logout = new elements(By.xpath(logoutXpath),"Logout Button");
        logout.scrollIntoView(logoutXpath);
        logout.click();
        new WebDriverWait(new onexApp().getDriver(), Duration.ofSeconds(30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath(signOutPopupxpath)));
        new elements(By.xpath(logoutYesXpath),"Confirm Logout").click();
        log.info("User Logged out of oneX");

    }

    public void toggleAlerts(Boolean toggle) throws Exception {

        elements toggleStatus = new elements(By.xpath("//input/parent::div"),"Toggle button status");
        Boolean status = toggleStatus.getAttribute("class").contains("checked");
        System.out.println(status);
//        sleep(3);
        elements toggleButton = new elements(By.xpath("//input/following-sibling::label"),"Toggle button switch");
        if((toggle && !status) || (!toggle && status)){
            toggleButton.click();
            log.info(String.format("Alerts set to - %1$s",toggle));
            elements toggleStatus1 = new elements(By.xpath("//input/parent::div"),"Toggle button status");
            Boolean statusAfter = toggleStatus1.getAttribute("class").contains("checked");
            Assert.assertTrue(!statusAfter.equals(status),"Button does not change state after clicking");
        }
        else {
            log.error(String.format("Button is already set to %1$s",toggle));
        }


    }
}
