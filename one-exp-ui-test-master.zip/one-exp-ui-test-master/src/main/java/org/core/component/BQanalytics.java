package org.core.component;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.bigquery.*;
import org.core.driver.onexApp;
import org.core.util.BQdataValidator;
import org.core.util.EventDataParser;
import org.core.util.PropertiesHandler;

import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

public class BQanalytics extends BaseFunc{

    static BigQuery bigquery;
    static String lastEntry = null;
    String userID = null;
    private String userLatestQuery = "SELECT * FROM `mtech-storesys-np.onex_analytics.onex_events_analytics_%1$s` WHERE user_id= '%2$s' order by created_ts desc LIMIT 1";
    private String currentSessionQuery = "SELECT * FROM `mtech-storesys-np.onex_analytics.onex_events_analytics_%1$s` WHERE user_id= '%2$s' and created_ts > '%3$s' LIMIT 100";
    private String currentSessionQueryWithExclusions = "SELECT * FROM `mtech-storesys-np.onex_analytics.onex_events_analytics_%1$s` WHERE user_id= '%2$s' and event_id NOT IN (%3$s) and created_ts > '%4$s' LIMIT 100";
    public static Map<String,String> wifiDetailsFromADB = null;
    public BQanalytics() throws Exception {
    }

    public void connectBQ() throws IOException {

        log.info("Connecting to BigQuery...");
        GoogleCredentials credentials = GoogleCredentials.fromStream(new FileInputStream(PropertiesHandler.getProperties().getProperty("bq_service_account_file_path")));
        bigquery = BigQueryOptions.newBuilder().setCredentials(credentials).build().getService();
        if(bigquery != null){
            log.info("BigQuery Connected");
        }

    }

    public TableResult executeQuery(String query) throws InterruptedException, IOException {

//        connectBQ();
        QueryJobConfiguration queryConfig = QueryJobConfiguration.newBuilder(query).setUseLegacySql(false).build();

        JobId jobId = JobId.of(UUID.randomUUID().toString());
        Job queryJob = bigquery.create(JobInfo.newBuilder(queryConfig).setJobId(jobId).build());

        queryJob = queryJob.waitFor();

        if (queryJob == null) {
            throw new RuntimeException("Job no longer exists");
        } else if (queryJob.getStatus().getError() != null) {

            throw new RuntimeException(queryJob.getStatus().getError().toString());
        }
        log.info("Querying from BigQuery...");
        TableResult result = queryJob.getQueryResults();
        return result;

    }

    public String getLastEntry(String userID) throws IOException, InterruptedException {

        connectBQ();
        String query = String.format(userLatestQuery,PropertiesHandler.getProperties().getProperty("testEnv"),userID);
        TableResult result = executeQuery(query);
        for (FieldValueList row : result.iterateAll()) {
//            System.out.println(row);
            lastEntry = convertToDate(row.get(BQdataValidator.eventHeaders.CREATED_TS.toString()).getStringValue());
        }
        if(lastEntry != null){log.info("Saving last BigQuery entry");}
        return lastEntry;
    }

    public TableResult getCurrentSessionEntries(String... eventIdExclusions) throws Exception {

        log.info("5 second timeout for events to complete");
        sleep(5);
        String query;
        if(eventIdExclusions.length == 0){
             query = String.format(currentSessionQuery,PropertiesHandler.getProperties().getProperty("testEnv"),PropertiesHandler.getProperties().getProperty("bqUserID"),lastEntry);
             executeQuery(query);
        }else {
            String eventsString = Arrays.stream(eventIdExclusions).map(s -> "\"" + s + "\"").collect(Collectors.joining(","));
            query = String.format(currentSessionQueryWithExclusions,PropertiesHandler.getProperties().getProperty("testEnv"),PropertiesHandler.getProperties().getProperty("bqUserID"),eventsString,lastEntry);
            executeQuery(query);
        }

        TableResult result = executeQuery(query);
        System.out.println(query);
        log.info("BQ event count = "+result.getTotalRows());
        for (FieldValueList row : result.iterateAll()) {

            System.out.println(String.format("eventID = %1$s, appID = %2$s, traceID = %3$s",row.get("event_id").getStringValue(),row.get("app_id").getStringValue(),row.get("trace_id").getStringValue()));
        }
        wifiDetailsFromADB = new onexApp().getWifiDetails();
        return  result;

    }

    private String convertToDate(String ts){
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
        return sdf.format(Double.parseDouble(ts)*1000)+ts.substring(ts.indexOf("."));
    }




}
