package org.core.component.pages;

import org.core.component.BaseFunc;
import org.core.component.elements;
import org.core.component.wait;
import org.core.driver.onexApp;
import org.core.util.PropertiesHandler;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.time.Duration;

public class HomePage extends BaseFunc {

    private String greetingXpath = "//div[@id='greeting-message']";
    private String searchIconXpath = "//div[@class='right menu page-header-menu']//i[@title='Search']";
    private String placeHOlderForSearchBox = "Search app or task";
    private String searchBoxXpath = "//input[@class='input-box']";
    private String searchBoxClearXpath = "//div[@id='close-icon']//i";
    private String searchResults = "//div[text()='%1$s']/../following-sibling::div//div[text()='...in %2$s']/../div//i";

    private String numberOfResultsXpath = "//div[@class='ui divider']";
    private String cancelButtonXpath = "//div[text()='Cancel']";

    private String notificationPageIcon = "//div[@class='right menu page-header-menu']//div[@class='item']";
    private String notificationHeader = "//span[text()='Notification']";
    private String notificationXpath = "//div[@id='alert-detail']//span[text()='%1$s']";
    private String notificationRead = "//div[@id='alert-detail']//span[text()='%1$s']/../preceding-sibling::div//div";
    private String notificationArrow = "//div[@id='alert-detail']//span[text()='%1$s']/../following-sibling::div//i";
    private String swipeNotification = "//span[text()='%1$s']";
    private String deleteNotification = "//span[text()='%1$s']//ancestor::div[@class='ui-swipe-root']//div[@id='swipe-delete-button']//i";

    private String pillXpath = "//a[text()='%1$s']";
    private String serviceOptions = "//span[text()='%1$s']";
    private String orderPickupHP = "//span[text()='Order Pickup']/ancestor::div[normalize-space(@class)='ui-swipe-wrapper']";
    private String alertIcon = "//i[contains(@class,'notification-stop')]/..";
    private String alertPopUpXpath = "//div[@class='header' and text()='Stop alerts']";
    private String alertPopUpOk = "//div[@class='button-content' and text()='Ok']";
    
    public HomePage() throws Exception {
        wait.waitForPage();
        Assert.assertTrue(new elements(By.xpath(greetingXpath),"Greeting name").getText().contains(PropertiesHandler.getProperties().getProperty("userActualName")));
        log.info("User in HomePage");

    }

    public enum notificationStatus{

        ON_THE_WAY("is on the way to the store"),
        ARRIVED("has arrived to the store"),
        WAITING("is waiting outside the store");
        private String s;
        notificationStatus(String s){
            this.s = s;
        }
        public String getVal(){
            return s;
        }
    }

    public enum serviceOptions{
        AYS("AYS"),
        FULFILLMENT("Fulfillment"),
        MERCHANDISING("Merchandising"),
        SHOES_SALES("Shoe Sales"),
        FSS("Full Service Selling (FSS)"),
        EXPEDITOR("Expeditor");
        private String s;
        serviceOptions(String s){
            this.s = s;
        }
        public String getString(){
            return s;
        }
    }


    public void searchWithClear(String searchItem, String section) throws Exception {
        wait.waitForPage();
        goToSearch();
        elements search = new elements(By.xpath(searchBoxXpath),"Search Box");
        search.sendKeys(searchItem);
        new elements(By.xpath(searchBoxClearXpath),"Search Box Clear").click();
        search.sendKeys(searchItem);
        Assert.assertTrue(getNoOfElements(By.xpath(numberOfResultsXpath)) > 0);
        new elements(By.xpath(String.format(searchResults,searchItem,section)),"Search Result").click();
        skipConnection();
        goToHomePage();
    }

    public void searchWithoutClear(String searchItem, String section) throws Exception {
        wait.waitForPage();
        goToSearch();
        elements search = new elements(By.xpath(searchBoxXpath),"Search Box");
        search.sendKeys(searchItem);
        Assert.assertTrue(getNoOfElements(By.xpath(numberOfResultsXpath)) > 0);
        new elements(By.xpath(String.format(searchResults,searchItem,section)),"Search Result").click();
        skipConnection();
//        goToHomePage();
    }

    public void goToSearch() throws Exception {
        wait.waitForPage();
        new elements(By.xpath(searchIconXpath),"Search Icon").click();
        log.info("User in Search Page");
        elements search = new elements(By.xpath(searchBoxXpath),"Search Box");
        Assert.assertTrue(search.getAttribute("placeholder").equals(placeHOlderForSearchBox));
    }

    public void cancelSearch() throws Exception {

        wait.waitForPage();
        new elements(By.xpath(cancelButtonXpath),"Cancel Button").click();

    }

    public void goToNotificationCentre() throws Exception {

        wait.waitForPage();
        new elements(By.xpath(notificationPageIcon),"Notification icon").click();
        wait.waitForPage();
        try{
            new elements(By.xpath(notificationHeader),"Notification Header").waitForElement();
        }catch (NoSuchElementException e){
            log.error("Notification centre is not displayed");
        }
    }



    public Boolean isNotificationPresent(String customerName, notificationStatus status) throws Exception {

        String alertStatus = customerName+" "+status.getVal();
        return new elements(By.xpath(String.format(notificationXpath,alertStatus)),"Customer Notification").isDisplayed();

    }

    public void markNotificationAsRead(String customerName, notificationStatus status) throws Exception {
        String alertStatus = customerName+" "+status.getVal();
        elements read = new elements(By.xpath(String.format(notificationRead,alertStatus)),"Notification Read mark");
        if(read.isDisplayed()){
            new elements(By.xpath(String.format(notificationArrow,alertStatus)),"Notification Read arrow").click();
            sleep(1);
            Assert.assertTrue(isElementNotDisplayed(By.xpath(String.format(notificationRead,alertStatus))));
        }else {
            log.error("Notification is already Read or not present");
        }
    }

    public void deleteNotification(String customerName, notificationStatus status, Boolean undo) throws Exception{
        String alertStatus = customerName+" "+status.getVal();
        Actions actions = new Actions(new onexApp().getDriver());
        elements swipeEle = new elements(By.xpath(String.format(swipeNotification,alertStatus)),"Swipe element");
        actions.clickAndHold(swipeEle);
        actions.dragAndDropBy(swipeEle,-60,0).build().perform();
        new elements(By.xpath(String.format(deleteNotification,alertStatus)),"Delete Notification").click();
    }

    public void selectService(serviceOptions option) throws Exception {

        elements element = new elements(By.xpath(String.format(pillXpath,option.getString())),option.getString());
        element.scrollIntoView(String.format(pillXpath,option.getString()));
        element.click();
    }

    public void selectServiceSection(String section) throws Exception {

        elements element = new elements(By.xpath(String.format(serviceOptions,section)),section);
        element.scrollIntoView(String.format(serviceOptions,section));
        element.click();
    }

    public String checkStatusOrDisableAlerts_HP(Boolean disableAlerts) throws Exception{

        elements alerts = new elements(By.xpath(orderPickupHP),"Order pickip alerts");
        swipeLeft(alerts,15);

        elements alertBellIcon = new elements(By.xpath(alertIcon),"Alert Icon");
        String status = alertBellIcon.getAttribute("aria-disabled");

        if(disableAlerts && Boolean.parseBoolean(status)){
            alertBellIcon.click();
            new elements(By.xpath(alertPopUpXpath),"Stop alerts popup").waitForElement();
            new elements(By.xpath(alertPopUpOk),"Ok button").click();
            sleep(2);
            swipeLeft(alerts,15);
            waitObj(Duration.ofSeconds(5)).until(ExpectedConditions.attributeToBe(new elements(By.xpath(alertIcon),"Alert Icon"), "aria-disabled", "false"));
            log.info("Alert are Disabled");
        }
        else if(disableAlerts && !Boolean.parseBoolean(status)){
            log.error("The alert icon is already disabled");
        }
        return status;

    }







}
