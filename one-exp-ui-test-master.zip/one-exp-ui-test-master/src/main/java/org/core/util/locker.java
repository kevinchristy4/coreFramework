package org.core.util;

import java.util.Base64;

public class locker {

    public static String decode64(String base64){
        return new String(Base64.getDecoder().decode(base64));
    }



}
