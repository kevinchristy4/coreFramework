package org.core.util;

import org.core.driver.Browserfactory;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.SkipException;

import java.time.Duration;
import java.util.Base64;

public class BrowserController {

    private Logger log = Logger.getLogger();
    ChromeDriver driver;

    @FindBy(xpath = "//input[@id='loginButton_0']")
    WebElement loginButton;

    @FindBy(xpath = "//input[@id='idToken2']")
    WebElement userName;

    @FindBy(xpath = "//input[@id='idToken3']")
    WebElement passWord;
    private String loginButtonXpath = "//input[@id='loginButton_0']";

    private String passwordNotice = "//h4[text()='PASSWORD EXPIRATION NOTICE']";
    @FindBy(xpath = "//input[@id='idToken3_0']")
    WebElement changeLaterBtn;

    private String headerXpath = "//div[@class='prelude-header-title' and text()='Location']";

    @FindBy(xpath = "//label[text()=\"Macy's\"]")
    WebElement macysLocation;

    @FindBy(xpath = "//label[text()=\"Macy's Backstage\"]")
    WebElement BackStageLocation;

    private String nextButton = "//div[text()=\"Next\"]";


    private String pageHeader = "//div[@class='prelude-header-title' and text()='Get Alerts']";
    private String alertsChecked = "//div[contains(@class,'checked')]";
    private String alertsCheckbox = "//input/../label";

    @FindBy(xpath = "//input/../label")
    WebElement alertToggle;

    private String popUpHeader = "//div[@class='header' and text()='OS Update Required']";

    @FindBy(xpath = "//div[@class='button-content' and text()='Ok']")
    WebElement popUpButton;

    private String pageHeaderCD = "//div[@class='prelude-header-title' and text()='Connect Devices']";
    private String skipConnectionPrelude = "//div[text()='Skip Connection']";
    private String headerXpathHP = "//div[@id='greeting-message']";
    private String preferencesIcon = "//a[@description='settings']";
    private String headerXpathPref = "//div[text()=\"Preferences\"]";
    @FindBy(xpath = "//div[@id=\"pref-list-item-title-Sign Out\"]")
    WebElement signOut;

    private String signOutHeader = "//div[@class=\"header\" and text()='Sign out']";

    @FindBy(xpath = "//div[@class=\"button-content\" and text()='Yes']")
    WebElement signoutConfirmation;

    private String signInButtonXpath = "//div[text()='Sign In']";


    public BrowserController() throws Exception {
            driver = Browserfactory.getDriver();
            driver.get(PropertiesHandler.getProperties().getProperty("envURL"));
            PageFactory.initElements(driver, this);
            waitForElement(By.xpath(signInButtonXpath)).click();
            waitForElement(By.xpath(loginButtonXpath));

    }


    public void login(){
        try {
            waitForElement(By.xpath(loginButtonXpath));
            log.info("Entering Username and Password...");
            userName.sendKeys(PropertiesHandler.getProperties().getProperty("userName"));
            passWord.sendKeys(new String(Base64.getDecoder().decode(PropertiesHandler.getProperties().getProperty("passWord"))));
            loginButton.click();
            sleep(2);
            if(!isElementNotDisplayed(By.xpath(passwordNotice))){
                changeLaterBtn.click();
            }
        }
        catch (Exception ne){
            log.error(ne.getLocalizedMessage());
            throw new SkipException("Login Page is not loaded");
        }
    }

    public void completePrelude(String location, Boolean alerts) throws Exception {

        // Select Location
        waitForElement(By.xpath(headerXpath));
        switch (location){
            case "MACYS": macysLocation.click();
                break;
            case "BACKSTAGE": BackStageLocation.click();
                break;
            default: throw new SkipException("Invalid location selected");
        }
        log.info("Location selected");
        driver.findElement(By.xpath(nextButton)).click();

        // Select Alerts
        waitForElement(By.xpath(pageHeader));
        log.info("User in Alerts page");
        Boolean checkStatus = (!isElementNotDisplayed(By.xpath(alertsChecked)));

        if(!(checkStatus && alerts)){
            alertToggle.click();
            log.info("Alerts are set to "+ alerts);
        }
        log.info("Alerts are set to "+ alerts);
        driver.findElement(By.xpath(nextButton)).click();

        // Skip Devices
        waitForElement(By.xpath(popUpHeader));
        popUpButton.click();
        waitForElement(By.xpath(pageHeaderCD));
        driver.findElement(By.xpath(skipConnectionPrelude)).click();
        waitForElement(By.xpath(headerXpathHP));
    }


    public void logout() throws Exception {

        driver.findElement(By.xpath(preferencesIcon)).click();
        waitForElement(By.xpath(headerXpathPref));
        scrollToBottom();
        signOut.click();
        waitForElement(By.xpath(signOutHeader));
        signoutConfirmation.click();
    }

    public void close(){
        if(driver.getSessionId() != null) {
            driver.close();
        }
    }

    public void scrollToBottom() throws Exception {
        ((JavascriptExecutor)driver).executeScript("window.scrollBy(0,document.body.scrollHeight)");
    }

    public WebElement waitForElement(By locator) throws Exception {
        WebDriverWait wait =  new WebDriverWait(driver, Duration.ofSeconds(30));
        WebElement waitedElement;
        Object ee = wait.until(driver -> {
            WebElement waitedEle =  wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(locator)));
            if(waitedEle != null && driver.findElement(locator).isDisplayed()){
                return waitedEle;
            }
            return null;
        });
        waitedElement = (WebElement) ee;
        return waitedElement;
    }

    public void sleep(int sec) throws InterruptedException {
        Thread.sleep(sec*1000);
    }

    public boolean isElementNotDisplayed(By locator) throws Exception {
        if(driver.findElements(locator).size() == 0){
            return true;
        }
        else {
            return false;
        }
    }
}
