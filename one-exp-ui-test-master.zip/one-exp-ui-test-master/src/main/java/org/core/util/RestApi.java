package org.core.util;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.http.Header;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import java.util.Map;

public class RestApi {

    private static Logger log = Logger.getLogger();
    public static Response post(String uRI, String stringJSON){
        RequestSpecification requestSpecification = RestAssured.given().body(stringJSON);
        requestSpecification.contentType(ContentType.JSON);
        Response response = requestSpecification.post(uRI);
        if(response.getStatusCode() == 200){
            log.info("Store timing updated Successfully");
        }
        else {
            log.error("Store timing update failed with status code = "+response.getStatusCode());
        }
        return response;
    }

    public static Response get(String uRI){
        RequestSpecification requestSpecification = RestAssured.given();
        requestSpecification.contentType(ContentType.JSON);
        Response response = requestSpecification.get(uRI);
        return response;
    }

    public static Response put(String uRI,String stringJSON){
        RequestSpecification requestSpecification = RestAssured.given().body(stringJSON);
        requestSpecification.contentType(ContentType.JSON);
        Response response = requestSpecification.put(uRI);
        return response;
    }

    public static Response delete(String uRI){
        RequestSpecification requestSpecification = RestAssured.given();
        requestSpecification.contentType(ContentType.JSON);
        Response response = requestSpecification.delete(uRI);
        return response;
    }


    public static Response postCallWithToken(String uRI,String stringJSON, String token){
        RequestSpecification requestSpecification = RestAssured.given().body(stringJSON);
        requestSpecification.contentType(ContentType.JSON);
        requestSpecification.headers("Authorization",token);
        Response response = requestSpecification.post(uRI);
        return response;
    }

    public static Response postGrapgQlcall(String uRI, Map<String,String> headers, String variables, String query){

        String requestBody = "{\n" +
                "  \"query\": \"" + query + "\",\n" +
                "  \"variables\": " + variables + "\n" +
                "}";

        RequestSpecification requestSpecification = RestAssured.given().body(requestBody);
        if(headers != null){
            for (Map.Entry<String, String> entry : headers.entrySet()) {
                Header header = new Header(entry.getKey(), entry.getValue());
                requestSpecification.header(header);
            }
        }

        Response response = requestSpecification.post(uRI);
        if(response.getStatusCode() == 200){
            log.info("Api success = 200");
        }
        else {
            log.error("Api error = "+response.getStatusCode()+" - "+response.getBody().toString());
        }
        return response;
    }

    public static String getGrapghQLbody(String query, String variables){

        String requestBody = "{\n" +
                "  \"query\": \"" + query + "\",\n" +
                "  \"variables\": " + variables + "\n" +
                "}";
        return requestBody;
    }
}
