package org.core.util;

import org.core.component.storeTimingBody;
import org.core.component.wait;
import org.core.driver.Browserfactory;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class TriggerNotification {

    public String updateToken = "update CURBSIDE_ORDER set CS_ORDER_STATUS=106 where CS_ORDER_STATUS not in (106) and CUSTOMER_TOKEN is not null and CUSTOMER_FNAME = '%1$s'";
    public String selectToken = "select * from CURBSIDE_ORDER where CUSTOMER_TOKEN is not null and CUSTOMER_FNAME = '%1$s' and DIVISION_ID=%2$s and STORE_NUMBER=%3$s";
    public String storeTimingURI = "https://curbside-api-%1$s.devops.fds.com/api/v1/cache/divnNbr/%2$s/storeNumber/%3$s";
    private Logger log = Logger.getLogger();
    private String curbSideUrl = "https://macys-curbside-microsite-%1$s.devops.fds.com/curbside?token=%2$s";
    private String headingTextXpath = "//div[contains(@class,'viewOrderDetails')]/following-sibling::div//strong";
    private String onTHeWayText = "Let us know when you're on the way, so we can have your order ready.";
    private String onTheWayButtonText = "I'm on the way";
    private String buttonXpath = "//div[@class='button-content' and text()=\"%1$s\"]";
    private String imHereText = "Check back here when you arrive. We'll see you soon!";
    private String imHereButtonText = "I'm here";
    private String pickUPScreenXpath = "//div[text()='Help us find you.']";
    private String vehicleXpath = "//p[text()='%1$s']";
    private String colorXpath = "//div[@class='ColorText' and text()='%1$s']/ancestor::div[@class='colorDot']";
    private String locationTextXpath = "//input[@class='input-box']";
    private String nextButtonXpath = "//div[@class='button-content' and text()='Next']";
    private String pickUpTypeXpath = "//span[text()='%1$s']";
    private String orderConfirmationXpath = "//div[text()=\"We'll be out with your order shortly.\"]";
    private String unableProcessXpath = "//div[text()='Unable to process check in at this time.']";




    public TriggerNotification() throws Exception {
    }

    public enum CustomerNamesDev{
        VIRATAPU,
        ROBERT,
        TEST,
        ASHWINI,
        KEERTHI;
    }

    public enum CustomerNamesUAT{
        TV,
        VIRATAPU,
        ATLANTA,
        ASHWINI,
        AHBS,
        DHANA,
        TEST,
        JAMES,
        TRIPURA,
        TEDDY,
        RAGHU,
        MEL;
    }

    public String getUpdateTokenQuery(String customerName){
            return String.format(updateToken,customerName);
    }

    public String getSelectTokenQuery(String customerName){
        return String.format(selectToken,customerName, PropertiesHandler.getProperties().getProperty("division"),PropertiesHandler.getProperties().getProperty("store"));
    }


    public void triggerOnTheWayAndArrivedInCar(String token, String vehicleType, String color, String location) throws Exception {

        log.info("Updating store timing api");
        RestApi.post(String.format(storeTimingURI,PropertiesHandler.getProperties().getProperty("testEnv"),PropertiesHandler.getProperties().getProperty("division"),PropertiesHandler.getProperties().getProperty("store")),storeTimingBody.getCurrentStoreTime());
        RestApi.post(String.format(storeTimingURI,PropertiesHandler.getProperties().getProperty("testEnv"),PropertiesHandler.getProperties().getProperty("division"),PropertiesHandler.getProperties().getProperty("store")),storeTimingBody.getCurrentStoreTime());
        goToCurbSide(token);
        log.info("Triggering On the way notification");
        clickOnTheWay();
        log.info("Triggering Arrived notification");
        clickImHere();
        pickUpInCar(vehicleType,color,location);
        closeBrowser();
    }

    public void triggerOnTheWayAndArrivedAtDoor(String token) throws Exception {

        RestApi.post(String.format(storeTimingURI,PropertiesHandler.getProperties().getProperty("testEnv"),PropertiesHandler.getProperties().getProperty("division"),PropertiesHandler.getProperties().getProperty("store")),storeTimingBody.getCurrentStoreTime());
        goToCurbSide(token);
        clickOnTheWay();
        clickImHere();
        pickUpAtDoor();
        closeBrowser();
    }

    public void goToCurbSide(String token) throws Exception {

        if(token != null){
            log.info("Launching Chrome...");
            ChromeDriver driver = Browserfactory.getDriver();
            System.out.println(String.format(curbSideUrl,PropertiesHandler.getProperties().getProperty("testEnv"),token));
            String url = String.format(curbSideUrl,PropertiesHandler.getProperties().getProperty("testEnv"),token);
            driver.get(url);
            wait.waitForBrowserPage();

        }else {
            log.error("Need Valid token to launch curbside from chrome");
        }
    }

    public void clickOnTheWay() throws Exception {

        new WebDriverWait(Browserfactory.getDriver(), Duration.ofSeconds(30)).until(ExpectedConditions.textToBePresentInElementLocated(By.xpath(headingTextXpath), onTHeWayText));
        Thread.sleep(3500);
        log.info("Clicking - On the Way button");
        new WebDriverWait(Browserfactory.getDriver(), Duration.ofSeconds(30)).until(ExpectedConditions.elementToBeClickable(By.xpath(String.format(buttonXpath,onTheWayButtonText)))).click();

        log.info("Waiting for next page...");
        new WebDriverWait(Browserfactory.getDriver(), Duration.ofSeconds(30)).until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(String.format(buttonXpath,onTheWayButtonText))));
        wait.waitForBrowserPage();

        if(Browserfactory.getDriver().findElements(By.xpath(unableProcessXpath)).size() > 0){
            log.info("Curbside error... Reloading the page and trying again");
            Browserfactory.getDriver().navigate().refresh();
            clickOnTheWay();
        }

    }

    public void clickImHere() throws Exception {

        new WebDriverWait(Browserfactory.getDriver(), Duration.ofSeconds(30)).until(ExpectedConditions.textToBePresentInElementLocated(By.xpath(headingTextXpath), imHereText));
        new WebDriverWait(Browserfactory.getDriver(), Duration.ofSeconds(30)).until(ExpectedConditions.elementToBeClickable(By.xpath(String.format(buttonXpath,imHereButtonText)))).click();
        new WebDriverWait(Browserfactory.getDriver(), Duration.ofSeconds(30)).until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(String.format(buttonXpath,imHereButtonText))));
        wait.waitForBrowserPage();
        if(Browserfactory.getDriver().findElements(By.xpath(unableProcessXpath)).size() > 0){
            Browserfactory.getDriver().navigate().refresh();
            clickImHere();
        }
    }

    public void pickUpInCar(String type, String color, String location) throws Exception {

        new WebDriverWait(Browserfactory.getDriver(), Duration.ofSeconds(30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath(pickUPScreenXpath)));
        new WebDriverWait(Browserfactory.getDriver(), Duration.ofSeconds(30)).until(ExpectedConditions.elementToBeClickable(By.xpath(String.format(pickUpTypeXpath,"Pick up in car")))).click();
        new WebDriverWait(Browserfactory.getDriver(), Duration.ofSeconds(30)).until(ExpectedConditions.elementToBeClickable(By.xpath(String.format(vehicleXpath,type)))).click();
        new WebDriverWait(Browserfactory.getDriver(), Duration.ofSeconds(30)).until(ExpectedConditions.elementToBeClickable(By.xpath(String.format(colorXpath,color)))).click();
        new WebDriverWait(Browserfactory.getDriver(), Duration.ofSeconds(30)).until(ExpectedConditions.elementToBeClickable(By.xpath((locationTextXpath)))).sendKeys(location);
        new WebDriverWait(Browserfactory.getDriver(), Duration.ofSeconds(30)).until(ExpectedConditions.elementToBeClickable(By.xpath(nextButtonXpath))).click();
        new WebDriverWait(Browserfactory.getDriver(), Duration.ofSeconds(30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath(orderConfirmationXpath)));

    }

    public void pickUpAtDoor() throws Exception {

        new WebDriverWait(Browserfactory.getDriver(), Duration.ofSeconds(30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath(pickUPScreenXpath)));
        new WebDriverWait(Browserfactory.getDriver(), Duration.ofSeconds(30)).until(ExpectedConditions.elementToBeClickable(By.xpath(String.format(pickUpTypeXpath,"Pick up at door")))).click();
        new WebDriverWait(Browserfactory.getDriver(), Duration.ofSeconds(30)).until(ExpectedConditions.elementToBeClickable(By.xpath(nextButtonXpath))).click();
        new WebDriverWait(Browserfactory.getDriver(), Duration.ofSeconds(30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath(orderConfirmationXpath)));

    }

    public void closeBrowser() throws Exception {
        log.info("Closing browser");
        Browserfactory.closeBrowser();
    }

}
