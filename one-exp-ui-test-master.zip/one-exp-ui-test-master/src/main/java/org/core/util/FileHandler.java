package org.core.util;

import java.io.File;

public final class FileHandler {

    public Boolean deleteFolder(String path){

        File folder = new File(path);
            if (folder.exists()) {
                File[] files = folder.listFiles();
                if (files != null) {
                    for (File file : files) {
                        if (file.isDirectory()) {
                            // Recursively delete sub-folders
                            deleteFolder(file.getPath());
                        } else {
                            // Delete files
                            file.delete();
                        }
                    }
                }
                // Delete the empty folder
                folder.delete();
                return true;
            }
            return false;
    }
}


