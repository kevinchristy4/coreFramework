package org.core.util.MarkDown;

import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.util.Properties;

@Slf4j
public class AppProperties {

    private final Properties properties;
    public static final String PROJECT_NAME = "markdown.utility.project_name";
    public static final String DB_INSTANCE = "markdown.utility.db_instance";
    public static final String DB_NAME_DEV = "markdown.utility.db_name_dev";
    public static final String DB_NAME_QA = "markdown.utility.db_name_qa";
    public static final String DB_NAME_UAT = "markdown.utility.db_name_uat";
    public static final String ENVIRONMENT = "markdown.utility.environment";
    public static final String OUTPUT_PATH = "markdown.utility.output_path";
    public static final String INPUT_PATH = "markdown.utility.input_path";
    public static final String INPUT_FILE = "markdown.utility.input_file";

    public static final String GCP_APP_USER_CREDENTIALS = "GCP_APP_USER_CREDENTIALS";

    public AppProperties() {
        properties = new Properties();
        try {
            properties.load(getClass().getClassLoader().getResourceAsStream("application.properties"));

        } catch (IOException ioex) {
            log.error("IOException Occurred while loading properties file::::" + ioex.getMessage());
        }
    }

    public String readProperty(String keyName) {
        log.info("Reading Property {}", keyName);
        return properties.getProperty(keyName, "There is no key in the properties file");
    }

}
