package org.core.util;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import org.apache.http.client.config.RequestConfig;
import org.apache.http.ssl.SSLContextBuilder;

import javax.net.ssl.SSLContext;
import java.io.*;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;

import java.util.zip.ZipFile;

public final class DriverDownloader {

    private static String chromeapiUrl = "https://googlechromelabs.github.io/chrome-for-testing/known-good-versions-with-downloads.json";
    private static  String destinationFolder = "drivers";
    private static String fileName = "chromedriver.exe";
    private static String downloadedFileName = "chromedriver-win64.zip";


    public void updateChromeDriver(String installedVersion) throws IOException, NoSuchAlgorithmException, KeyStoreException, KeyManagementException {
            new FileHandler().deleteFolder(destinationFolder);
            downloadChromeDriver(installedVersion);
    }

    public static void downloadChromeDriver(String version) throws IOException, NoSuchAlgorithmException, KeyStoreException, KeyManagementException {

        System.out.println("Getting list of driver versions from chromelabs api...");

        try{
            HttpClient httpClient = createInsecureHttpClient();
            HttpGet httpGet = new HttpGet(chromeapiUrl);
            HttpResponse response = httpClient.execute(httpGet);
            String jsonResponse = EntityUtils.toString(response.getEntity());

            System.out.println("Extract the download link for the closest matching version...");
            JSONObject jsonObject = new JSONObject(jsonResponse);
            JSONArray versions = jsonObject.getJSONArray("versions");
            JSONObject closestMatch = findClosestMatch(versions, version);

            if (closestMatch != null) {

                System.out.println("Closest version found - "+closestMatch.getString("version"));
                JSONObject downloads = closestMatch.getJSONObject("downloads");

                String downloadUrl = downloads.getJSONArray("chromedriver")
                        .getJSONObject(4) // Assuming "win64" is always at index 4
                        .getString("url");

                System.out.println("Download the closest matching version...");
                System.out.println(downloadUrl);
                String zipFilePath = downloadFile(downloadUrl,destinationFolder,downloadedFileName);
                extractZip(zipFilePath,fileName);

                // Locate the chromedriver.exe within the extracted folder
                File chromedriverFile = new File(destinationFolder + File.separator + fileName);
                if (chromedriverFile.exists()) {
                    System.out.println("Driver downloaded and extracted successfully");
                } else {
                    System.out.println("ChromeDriver extraction failed.");
                }
            } else {
                String zipFilePath = downloadFile(getLegacyChromeDriverURL(version),destinationFolder,downloadedFileName);
                extractZip(zipFilePath,fileName);

                // Locate the chromedriver.exe within the extracted folder
                File chromedriverFile = new File(destinationFolder + File.separator + fileName);
                if (chromedriverFile.exists()) {
                    System.out.println("Driver downloaded and extracted successfully");
                } else {
                    System.out.println("ChromeDriver extraction failed.");
                }
//                System.out.println("No matching version found.");
            }
        }catch (IOException | InterruptedException e){
            System.out.println("Issue in downloading the driver");
            throw new IOException(e);
        }
    }

    private static HttpClient createInsecureHttpClient() throws NoSuchAlgorithmException, KeyManagementException, KeyStoreException {
        SSLContext sslContext = SSLContextBuilder.create()
                .loadTrustMaterial((chain, authType) -> true)
                .build();
        return HttpClients.custom()
                .setSSLContext(sslContext)
                .setDefaultRequestConfig(RequestConfig.custom()
                        .setConnectTimeout(5000)
                        .setSocketTimeout(5000)
                        .build())
                .build();
    }

    private static JSONObject findClosestMatch(JSONArray versions, String version) {
        int low = 0;
        int high = versions.length() - 1;

        while (low <= high) {
            int mid = (low + high) / 2;
            JSONObject currentVersion = versions.getJSONObject(mid);
            String versionString = currentVersion.getString("version");
            int compareResult = versionCompare(version, versionString);
            if (compareResult == 0) {
                return currentVersion;
            } else if (compareResult < 0) {
                high = mid - 1;
            } else {
                low = mid + 1;
            }
        }

        if (high < 0) {
            System.out.println("The webview version installed in ct40 is outdated");
            System.out.println("Downloading legacy drivers...");
            return null;
        }

        // At this point, low is the index of the closest version
        // Choose the closer one between low and high
        int lowDiff = low >= 0 ? versionDifference(version, versions.getJSONObject(low).getString("version")) : Integer.MAX_VALUE;
        int highDiff = high < versions.length() ? versionDifference(version, versions.getJSONObject(high).getString("version")) : Integer.MAX_VALUE;

        return lowDiff <= highDiff ? versions.getJSONObject(low) : versions.getJSONObject(high);
    }

    private static int versionCompare(String v1, String v2) {

        String[] parts1 = v1.split("\\.");
        String[] parts2 = v2.split("\\.");

        int length = Math.min(parts1.length, parts2.length);
        for (int i = 0; i < length; i++) {
            int diff = Integer.parseInt(parts1[i]) - Integer.parseInt(parts2[i]);
            if (diff != 0) {
                return diff;
            }
        }

        return parts1.length - parts2.length;
    }

    private static int versionDifference(String v1, String v2) {
        String[] parts1 = v1.split("\\.");
        String[] parts2 = v2.split("\\.");

        int length = Math.min(parts1.length, parts2.length);
        int difference = 0;
        for (int i = 0; i < length; i++) {
            difference += Math.abs(Integer.parseInt(parts1[i]) - Integer.parseInt(parts2[i]));
        }

        // Consider remaining parts in longer version
        for (int i = length; i < parts1.length; i++) {
            difference += Integer.parseInt(parts1[i]);
        }
        for (int i = length; i < parts2.length; i++) {
            difference += Integer.parseInt(parts2[i]);
        }

        return difference;
    }

    private static String downloadFile(String downloadUrl, String downloadPath, String downloadedFileName) throws IOException, InterruptedException {
        File destinationFolder = new File(downloadPath);

        // Create the destination folder if it doesn't exist
        if (!destinationFolder.exists()) {
            destinationFolder.mkdirs();
        }
        HttpClient httpClient = HttpClients.createDefault();

        HttpGet httpGet = new HttpGet(downloadUrl);

        HttpResponse response = httpClient.execute(httpGet);

        BufferedInputStream inputStream = new BufferedInputStream(response.getEntity().getContent());
        FileOutputStream fileOutputStream = new FileOutputStream(new File(downloadPath,downloadedFileName));

        byte[] buffer = new byte[1024];
        int bytesRead;
        while ((bytesRead = inputStream.read(buffer)) != -1) {
            fileOutputStream.write(buffer, 0, bytesRead);
        }

        fileOutputStream.flush();
        fileOutputStream.close();
        inputStream.close();
        System.out.println("ChromeDriver downloaded successfully in drivers folder: " + downloadPath+File.separator+downloadedFileName);
        return downloadPath+File.separator+downloadedFileName;
    }

    private static void extractZip(String zipFilePath, String fileName) throws IOException {

        try (ZipFile zipFile = new ZipFile(zipFilePath)) {

            // Iterate over each entry in the ZIP file
            zipFile.stream().forEach(entry -> {
                try {
                    // Construct the destination file path
                    String entryFilePath = destinationFolder + File.separator + fileName;
                    System.out.println("Extraction destination - "+entryFilePath);

                    File entryFile = new File(entryFilePath);

                    // If the entry is a directory, create it
                    if (entry.isDirectory()) {
                        entryFile.mkdirs();
                    } else {
                        // If the entry is a file, extract it
                        try (InputStream inputStream = zipFile.getInputStream(entry);
                             FileOutputStream outputStream = new FileOutputStream(entryFile)) {
                            byte[] buffer = new byte[1024];
                            int bytesRead;
                            while ((bytesRead = inputStream.read(buffer)) != -1) {
                                outputStream.write(buffer, 0, bytesRead);
                            }
                        }
                        System.out.println("ZIP file extracted successfully to: " + destinationFolder);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });

        }
    }

    public static String getLegacyChromeDriverURL(String chromeVersion) throws IOException {
        String[] versionParts = chromeVersion.split("\\.");
        String releaseVersion = versionParts[0] + "." + versionParts[1] + "." + versionParts[2];
        String urlForFullVersion =  "https://chromedriver.storage.googleapis.com/LATEST_RELEASE_" + releaseVersion;
        HttpClient httpClient = HttpClients.createDefault();
        HttpGet httpGet = new HttpGet(urlForFullVersion);
        HttpResponse response = httpClient.execute(httpGet);
        BufferedReader reader = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
        String version = reader.readLine();
        reader.close();
        System.out.println("https://chromedriver.storage.googleapis.com/index.html?path=" + version + "/"+"chromedriver_win32.zip");
        return "https://chromedriver.storage.googleapis.com/" + version + "/"+"chromedriver_win32.zip";

    }


}
