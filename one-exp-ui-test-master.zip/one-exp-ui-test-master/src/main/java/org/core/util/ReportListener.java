package org.core.util;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.Markup;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import io.appium.java_client.android.AndroidStartScreenRecordingOptions;
import lombok.SneakyThrows;
import org.apache.commons.io.FileUtils;
import org.core.driver.onexApp;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.io.FileHandler;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestNGListener;
import org.testng.ITestResult;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;

public class ReportListener implements ITestListener {
    static ExtentReports reporter = new ExtentReports();
    private static ThreadLocal<ExtentTest> extentTest = new ThreadLocal<ExtentTest>();
    private static ExtentTest test;
    public static ExtentTest getReporter() {

        if(extentTest.get() == null){
            test = reporter.createTest("Initial setup");
            extentTest.set(test);
        }
        return extentTest.get();
    }


    @Override
    public synchronized void onTestStart(ITestResult result) {
        test = reporter.createTest(result.getTestClass().getName().substring(result.getTestClass().getName().lastIndexOf(".")+1) + " -- "+result.getMethod().getMethodName().trim());
        extentTest.set(test);
    }
    @Override
    public synchronized void onTestSuccess(ITestResult result) {
        String logText = "<b> Test Method " + result.getMethod().getMethodName() + " Successful</b>";
        Markup m = MarkupHelper.createLabel(logText, ExtentColor.GREEN);
        extentTest.get().log(Status.PASS, m);
        extentTest.remove();
    }

    private String getTimeStamp(){
        SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyy_HH_mm");
        Date date = new Date();
        return format.format(date);
    }
    @SneakyThrows
    @Override
    public synchronized void onTestFailure(ITestResult result) {
        //add screenshot for failed test.
        File src = ((TakesScreenshot) new onexApp().getDriver()).getScreenshotAs(OutputType.FILE);
        String screenshotPath = System.getProperty("user.dir")+ "/test-output/"+getTimeStamp()+".jpeg";
        File dest = new File(screenshotPath);
        try {
            FileHandler.copy(src, dest);
        } catch (IOException e) {
            e.printStackTrace();
        }
        extentTest.get().log(Status.FAIL, "Test Case: "+result.getMethod().getMethodName()+ " is Failed.");
        extentTest.get().log(Status.FAIL, result.getThrowable());
        extentTest.get().addScreenCaptureFromPath(screenshotPath, "Test case failure screenshot");
        extentTest.remove();
    }
    @Override
    public synchronized void onTestSkipped(ITestResult result) {
        String logText = "<b> Test Method " + result.getMethod().getMethodName() + " Skipped</b>";
        Markup m = MarkupHelper.createLabel(logText, ExtentColor.YELLOW);
        extentTest.get().log(Status.SKIP, m);
        extentTest.remove();
    }

    @Override
    public synchronized void onTestFailedButWithinSuccessPercentage(ITestResult result) {
        ITestListener.super.onTestFailedButWithinSuccessPercentage(result);
    }

    @Override
    public synchronized void onTestFailedWithTimeout(ITestResult result) {
        ITestListener.super.onTestFailedWithTimeout(result);
    }

    @Override
    public synchronized void onStart(ITestContext context) {
        String suite = context.getCurrentXmlTest().getSuite().getName();
        System.out.println(suite + " Test Suite Started!");
        String path = System.getProperty("user.dir") + "/test-output/" + suite +" "+getTimeStamp()+".html";
        ExtentSparkReporter spark = new ExtentSparkReporter(path);
        spark.config().setTheme(Theme.STANDARD);
        spark.config().setDocumentTitle(suite);
        spark.config().setEncoding("utf-8");
        spark.config().setReportName("Test Report");
        spark.config().setTimelineEnabled(true);
        reporter.attachReporter(spark);
        if(PropertiesHandler.getProperties().getProperty("screenRecord").equals("true")){
            try {
                new onexApp().getAndroidDriver().startRecordingScreen(new AndroidStartScreenRecordingOptions().withVideoSize("1280x720"));
            } catch (Exception e) {
                System.out.println("Screen recording only available for ct40, please set the flag to false in properties file for browser execution");
            }
        }
    }

    @Override
    public synchronized void onFinish(ITestContext context) {
        if(reporter!=null) {
            reporter.flush();
            if(PropertiesHandler.getProperties().getProperty("screenRecord").equals("true")) {
                try {
                    String video = new onexApp().getAndroidDriver().stopRecordingScreen();
                    byte[] decode = Base64.getDecoder().decode(video);
                    String suite = context.getCurrentXmlTest().getSuite().getName();
                    FileUtils.writeByteArrayToFile(new File(System.getProperty("user.dir") + "/test-output/" + suite + " " + getTimeStamp() + ".mp4"), decode);
                } catch (Exception e) {
                    System.out.println("Screen recording only available for ct40, please set the flag to false in properties file for browser execution");
                }
            }
        }
    }
}
