package org.core.util;

import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import org.core.driver.onexApp;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

public final class ReportLogger {

    private ReportLogger(){}
    public static void step(String message){
        ReportListener.getReporter().log(Status.PASS,MediaEntityBuilder.createScreenCaptureFromBase64String(getBase64()).build());
        ReportListener.getReporter().pass(message);

    }
    public static void info(String message){
        ReportListener.getReporter().log(Status.INFO,MediaEntityBuilder.createScreenCaptureFromBase64String(getBase64()).build());
        ReportListener.getReporter().info(message);

    }
    public static void fail(String message){
        ReportListener.getReporter().log(Status.FAIL,MediaEntityBuilder.createScreenCaptureFromBase64String(getBase64()).build());
        ReportListener.getReporter().fail(message);
    }

    private static String getBase64(){
        try{
            TakesScreenshot ts = (TakesScreenshot) new onexApp().getDriver();
            return ts.getScreenshotAs(OutputType.BASE64);
        }
        catch (Exception e){
            System.out.println("Error in adding screenshot");
        }
        return null;
    }
}
