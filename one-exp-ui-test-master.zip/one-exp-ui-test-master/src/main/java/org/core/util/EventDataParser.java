package org.core.util;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import org.testng.SkipException;

import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public final class EventDataParser {

    private static Logger log = Logger.getLogger();

    private static Map<String,String > getMapFromJsonObject(JsonObject object){
        Map<String, String> resultMap = new HashMap<>();
        if (object != null) {
            // Convert JSON object to a Map
            for (Map.Entry<String, JsonElement> entry : object.entrySet()) {
                resultMap.put(entry.getKey().toString(), entry.getValue().getAsString());
            }
            return  resultMap;
        } else {
            log.error("Json object is null or empty");
            throw new SkipException("Json object is null or empty");
        }
    }

    public static Map<String,String> getEventDatafor(String dataFilePath,String eventDataName){

        try (FileReader reader = new FileReader(dataFilePath)) {
            // Parse JSON file into a JsonObject
            Gson gson = new Gson();
            JsonObject jsonObject = gson.fromJson(reader, JsonObject.class);

            // Get the JSON object corresponding to the desired key
            JsonObject desiredObject = jsonObject.getAsJsonObject(eventDataName);
            return getMapFromJsonObject(desiredObject);

        } catch (IOException e) {
            log.error("Failed at parsing data file - check path or contents - provoded path:"+dataFilePath);
            e.printStackTrace();
            throw new SkipException(e.getMessage());
        }

    }
}
