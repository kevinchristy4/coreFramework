package org.core.util;

import com.google.cloud.bigquery.FieldValue;
import com.google.cloud.bigquery.FieldValueList;
import com.google.cloud.bigquery.TableResult;
import org.core.component.BQanalytics;
import org.testng.Assert;

import java.util.*;
import java.util.stream.Collectors;

public class BQdataValidator extends BQanalytics {

    private Boolean deviceExecution = PropertiesHandler.getProperties().getProperty("runInBrowser").equals("false");

    public BQdataValidator() throws Exception {
    }

    public enum eventHeaders{

        APP_ID("app_id"),
        TYPE("type"),
        EVENT_ID("event_id"),
        TRACE_ID("trace_id"),
        DIVISION("division"),
        STORE("store"),
        USER_ID("user_id"),
        DEVICE_ID("device_id"),
        CREATED_TS("created_ts"),
        EVENT("event"),
        FLM_EVENT("flm"),
        FIELDS("fields"),
        DEVICETYPE("device_type"),
        TIMEZONE("time_zone"),
        UTCOFFSET("utc_offset"),
        LOCAL_TIME("local_ts"),
        SESSIONID("session_id"),
        DESCRIPTION("description");
        private String i;
        eventHeaders(String i) {
            this.i = i;
        }
        public String toString(){
            return i;
        }
    }

    public Boolean verifyEventIsPresentInResults(TableResult mainResult, Map<String, String> event, int count){

        List<FieldValueList> eventsWithSameID = new ArrayList<>();
        List<FieldValueList> eventsWithSameDesc = new ArrayList<>();
        String appID = "";
        String eventID = "";

        for(FieldValueList rows: mainResult.iterateAll()){

            if(rows.get(eventHeaders.APP_ID.toString()).getStringValue().equals(event.get(eventHeaders.APP_ID.toString())) && rows.get(eventHeaders.EVENT_ID.toString()).getStringValue().equals(event.get(eventHeaders.EVENT_ID.toString())) ){
                appID = rows.get(eventHeaders.APP_ID.toString()).getStringValue();
                eventID = rows.get(eventHeaders.EVENT_ID.toString()).getStringValue();
                eventsWithSameID.add(rows);
            }
        }

        if(!eventsWithSameID.isEmpty()){
                Map<String, String> flds = event.entrySet().stream().filter(e -> e.getKey().contains("field")).collect(Collectors.toMap(e -> e.getKey(), e -> e.getValue()));
                for (FieldValueList similarEvent: eventsWithSameID){
                    FieldValueList fields = similarEvent.get(eventHeaders.FIELDS.toString()).getRecordValue();
                    if(isFieldMatch(fields, flds)){
                        verifyEventCommonValues(similarEvent,fields,true, eventHeaders.EVENT);
                        eventsWithSameDesc.add(similarEvent);
                    }
                }
                if(!eventsWithSameDesc.isEmpty() && eventsWithSameDesc.size() == count){
                    return true;
                }
                else {
                    log.error(String.format("The expected count or description does not match, For eventID - %1$s, appID - %2$s, Actual count from query = %3$s, Expected count = %4$s",appID,eventID,eventsWithSameDesc.size(),count));
                    return false;
                }
            }
        else {
                log.error(String.format("No events found with the given appID=%1$s and event ID=%2$s",event.get(eventHeaders.APP_ID.toString()),event.get(eventHeaders.EVENT_ID.toString())));
                return false;
        }
    }

    public Boolean verifyFLMEvents(TableResult mainResult, Map<String, String> startEvent, Map<String, String> endEvent, int totalCount){
        List<FieldValueList> startEv = new ArrayList<>();
        List<FieldValueList> endEv = new ArrayList<>();

        List<FieldValueList> startEventsWithSameDesc = new ArrayList<>();
        List<FieldValueList> endEventsWithSameDesc = new ArrayList<>();

        String startEvAppID = "";
        String startEvEventID = "";
        String endEvAppID = "";
        String endEvEventID = "";


        // Iterate over all the results to filter out only the start and end event
        for(FieldValueList rows: mainResult.iterateAll()){

            //Find the start event and store in a list
            if(rows.get(eventHeaders.APP_ID.toString()).getStringValue().equals(startEvent.get(eventHeaders.APP_ID.toString())) && rows.get(eventHeaders.EVENT_ID.toString()).getStringValue().contains(startEvent.get(eventHeaders.EVENT_ID.toString())) ){
                startEvAppID = rows.get(eventHeaders.APP_ID.toString()).getStringValue();
                startEvEventID = rows.get(eventHeaders.EVENT_ID.toString()).getStringValue();
                startEv.add(rows);
            }

            //Find the end event and store in another list
            if(rows.get(eventHeaders.APP_ID.toString()).getStringValue().equals(endEvent.get(eventHeaders.APP_ID.toString())) && rows.get(eventHeaders.EVENT_ID.toString()).getStringValue().contains(endEvent.get(eventHeaders.EVENT_ID.toString())) ){
                endEvAppID = rows.get(eventHeaders.APP_ID.toString()).getStringValue();
                endEvEventID = rows.get(eventHeaders.EVENT_ID.toString()).getStringValue();
                endEv.add(rows);
            }
        }
        if(startEv.isEmpty()){
            log.error("No start event found in BigQuery matching the data provided");
            return false;
        }
        if(endEv.isEmpty()){
            log.error("No end event found in BigQuery matching the data provided");
            return false;
        }

        // Verify if number of events for both matches
        if(startEv.size() == endEv.size()) {

            // Verify if event id with the hash code for both matches

            if (startEvEventID.equals(endEvEventID)) {

                // When the event id matches validate further to verify the field values and common values of both the event
                Map<String, String> flds = startEvent.entrySet().stream().filter(e -> e.getKey().contains("field")).collect(Collectors.toMap(e -> e.getKey(), e -> e.getValue()));
                for (FieldValueList similarEvent : startEv) {
                    FieldValueList fields = similarEvent.get(eventHeaders.FIELDS.toString()).getRecordValue();
                    if (isFieldMatch(fields, flds)) {
                        verifyEventCommonValues(similarEvent, fields, false, eventHeaders.FLM_EVENT);
                        startEventsWithSameDesc.add(similarEvent);
                    }
                }
                if (startEventsWithSameDesc.size() != totalCount) {
                    log.error(String.format("The expected totalCount or description does not match, For eventID - %1$s, appID - %2$s, Actual totalCount from query = %3$s, Expected totalCount = %4$s", startEvAppID, startEvEventID, startEventsWithSameDesc.size(), totalCount));
                    return false;
                }

                Map<String, String> endFlds = endEvent.entrySet().stream().filter(e -> e.getKey().contains("field")).collect(Collectors.toMap(e -> e.getKey(), e -> e.getValue()));
                for (FieldValueList similarEvent : endEv) {
                    FieldValueList fields = similarEvent.get(eventHeaders.FIELDS.toString()).getRecordValue();
                    if (isFieldMatch(fields, endFlds)) {
                        verifyEventCommonValues(similarEvent, fields, false, eventHeaders.FLM_EVENT);
                        endEventsWithSameDesc.add(similarEvent);
                    }
                }
                if (endEventsWithSameDesc.size() != totalCount) {
                    log.error(String.format("The expected totalCount or description does not match, For eventID - %1$s, appID - %2$s, Actual totalCount from query = %3$s, Expected totalCount = %4$s", endEvAppID, endEvEventID, endEventsWithSameDesc.size(), totalCount));
                    return false;
                }

            // When everything is validated return true
            log.info("The start and end event are present and the event id matches");
            return true;
        }
            // Return false if anything fails with breif description
            else {
                log.error("Event ID does not match for the start and end event");
                return false;
            }
        }
        else {
            log.error(String.format("The number of start event and end event does not match , Number of startEvent in BQ = %1$s, Number of endEvent = %2$s",startEv.size(),endEv.size()));
            return false;
        }

    }


    public void verifyEventCommonValues(FieldValueList event, FieldValueList fields, Boolean isWifiCaptured, eventHeaders type){

        try {
            Assert.assertTrue(event.get(eventHeaders.TYPE.toString()).getStringValue().equals(type.toString()));
            Assert.assertFalse(event.get(eventHeaders.TRACE_ID.toString()).isNull(), "Trace ID is null");
            Assert.assertTrue(event.get(eventHeaders.DIVISION.toString()).getStringValue().equals(PropertiesHandler.getProperties().getProperty("division")),"Division does not match");
            Assert.assertTrue(event.get(eventHeaders.STORE.toString()).getStringValue().equals(PropertiesHandler.getProperties().getProperty("store")),"Store number does not match");
            Assert.assertTrue(event.get(eventHeaders.USER_ID.toString()).getStringValue().equals(PropertiesHandler.getProperties().getProperty("bqUserID")),"User ID does not match");
            Assert.assertTrue(event.get(eventHeaders.DEVICETYPE.toString()).getStringValue().equals(PropertiesHandler.getProperties().getProperty("deviceType")),"Device type does not match");
            Assert.assertFalse(event.get(eventHeaders.LOCAL_TIME.toString()).isNull(),"Local Time Stamp is Null");
            Assert.assertFalse(event.get(eventHeaders.SESSIONID.toString()).isNull(), "Session ID is null");

            if(deviceExecution){
                Assert.assertTrue(event.get(eventHeaders.DEVICE_ID.toString()).getStringValue().equals(PropertiesHandler.getProperties().getProperty("deviceID")),"Device ID does not match");
                Assert.assertTrue(event.get(eventHeaders.TIMEZONE.toString()).getStringValue().equals(PropertiesHandler.getProperties().getProperty("timeZone")),String.format("Time zone does not match, Expected: %1$s, Actual: %2$s",PropertiesHandler.getProperties().getProperty("timeZone"),event.get(eventHeaders.TIMEZONE.toString()).getStringValue()));
                Assert.assertTrue(event.get(eventHeaders.UTCOFFSET.toString()).getStringValue().equals(PropertiesHandler.getProperties().getProperty("utcOffSet")),"UTC off does not match");
                if(isWifiCaptured){
                    Map<String, String> wifiDataFromBQ = wifiData(fields);
                    Assert.assertTrue(wifiDetailsFromADB.get("SSID").equals(wifiDataFromBQ.get("SSID")),"SSID is not present");
                    Assert.assertTrue(wifiDetailsFromADB.get("BSSID").equals(wifiDataFromBQ.get("BSSI")),"BSSI is not present");
                    Assert.assertFalse(wifiDataFromBQ.get("signalStrength").isEmpty(),"Signal strength is empty");
                    Assert.assertFalse(wifiDataFromBQ.get("RSSI").isEmpty(),"RSSI value is empty");
                }
            }
            else {
                Assert.assertFalse(event.get(eventHeaders.DEVICE_ID.toString()).isNull());
                Assert.assertFalse(event.get(eventHeaders.TIMEZONE.toString()).isNull(),"Time zone is null");
                Assert.assertFalse(event.get(eventHeaders.UTCOFFSET.toString()).isNull(),"UTC off set is Null");
            }



        }catch (AssertionError e){
            log.error("Issue with: app_id - "+event.get(eventHeaders.APP_ID.toString()).getStringValue()+" - || event_id - "+event.get(eventHeaders.EVENT_ID.toString()).getStringValue());
            log.error(e.getMessage());
            throw new Error("Data mismatch in Common fields");
        }
    }



    private Boolean isFieldMatch(FieldValueList field, Map<String, String> flds){

        boolean matchFound = false;
        for(String fld: flds.keySet()){
            if (matchFound) {
                break;
            }
            Boolean isPresent = false;
            for (FieldValue fieldValue : field) {
                FieldValue recordValue = fieldValue.getRepeatedValue().get(0);
                if (recordValue != null && recordValue.getStringValue().equals(fld.replaceFirst("^field_", ""))) {
                    if(fieldValue.getRepeatedValue().get(2).getStringValue().contains(flds.get(fld))){
                        isPresent = true;
                        matchFound = true;
                        break;
                    }
                }
            }
            if(!isPresent){
                return false;
            }
        }
        return true;
    }

    private Map<String, String> wifiData(FieldValueList field){

        Map <String,String> wifi = new HashMap<>();
        for (FieldValue fieldValue : field) {
            String recordValue = fieldValue.getRepeatedValue().get(0).getStringValue().trim();
            if (recordValue.equals("SSID")) {
                wifi.put("SSID",fieldValue.getRepeatedValue().get(2).getStringValue().trim());
            }
            if (recordValue.equals("BSSI")) {
                wifi.put("BSSI",fieldValue.getRepeatedValue().get(2).getStringValue().trim());
            }
            if (recordValue.equals("RSSI")) {
                wifi.put("RSSI",fieldValue.getRepeatedValue().get(2).getStringValue().trim());
            }
            if(recordValue.equals("signalStrength")){
                wifi.put("signalStrength",fieldValue.getRepeatedValue().get(2).getStringValue().trim());
            }
        }
        if(wifi.isEmpty()){
            log.error("No wifi details present for the event in BQ - returning null");
        }
        return wifi;
    }




    public Boolean verifyBrowserEvents(TableResult mainResult, Map<String, String> event, int count){

        List<FieldValueList> eventsWithSameID = new ArrayList<>();
        List<FieldValueList> eventsWithSameDesc = new ArrayList<>();
        String appID = "";
        String eventID = "";

        for(FieldValueList rows: mainResult.iterateAll()){

            if(rows.get(eventHeaders.APP_ID.toString()).getStringValue().equals(event.get(eventHeaders.APP_ID.toString())) && rows.get(eventHeaders.EVENT_ID.toString()).getStringValue().equals(event.get(eventHeaders.EVENT_ID.toString())) ){
                appID = rows.get(eventHeaders.APP_ID.toString()).getStringValue();
                eventID = rows.get(eventHeaders.EVENT_ID.toString()).getStringValue();
                eventsWithSameID.add(rows);
            }
        }

        if(!eventsWithSameID.isEmpty()){
            Map<String, String> flds = event.entrySet().stream().filter(e -> e.getKey().contains("field")).collect(Collectors.toMap(e -> e.getKey(), e -> e.getValue()));
            for (FieldValueList similarEvent: eventsWithSameID){
                FieldValueList fields = similarEvent.get(eventHeaders.FIELDS.toString()).getRecordValue();
                if(isFieldMatch(fields, flds)){
                    eventsWithSameDesc.add(similarEvent);
                }
            }
            if(!eventsWithSameDesc.isEmpty() && eventsWithSameDesc.size() == count){
                return true;
            }
            else {
                log.error(String.format("The expected count or description does not match, For eventID - %1$s, appID - %2$s, Actual count from query = %3$s, Expected count = %4$s",appID,eventID,eventsWithSameDesc.size(),count));
                return false;
            }
        }
        else {
            log.error(String.format("No events found with the given appID=%1$s and event ID=%2$s",event.get(eventHeaders.APP_ID.toString()),event.get(eventHeaders.EVENT_ID.toString())));
            return false;
        }
    }


}
