package org.core.util;


import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.spanner.*;
import com.google.common.collect.Lists;

import java.io.FileInputStream;

public class SpannerDB {

    String projectId = "mtech-storesys-np";
    String instanceId = "cspanner-storesys-np";
    String databaseId = "oneexperience-spanner-db";
    String databaseIdUAT = "oneexperience-spanner-uat-db";
    DatabaseClient dbClient = null;
    ResultSet resultSet = null;
    private String customerNAme = "CUSTOMER_FNAME";
    private String customerTOken = "CUSTOMER_TOKEN";

    private GoogleCredentials credentials = null;

    private Logger log = Logger.getLogger();

    public void connectDB(String env){

        if(dbClient == null){
            try{
                credentials = GoogleCredentials.fromStream(new FileInputStream(PropertiesHandler.getProperties().getProperty("spanner_service_account_file_path"))).createScoped(Lists.newArrayList(new String[]{"https://www.googleapis.com/auth/cloud-platform"}));
                SpannerOptions spannerOptions = ((SpannerOptions.Builder)SpannerOptions.newBuilder().setCredentials(this.credentials)).build();
                Spanner spanner = (Spanner)spannerOptions.getService();

//                GCPClients gcpClients = new GCPClients(PropertiesHandler.getProperties().getProperty("spanner_service_account_file_path"));
//                Spanner spanner = gcpClients.get_spanner_client();
                System.out.println(env);
                switch (env){
                    case "dev":
                        dbClient = spanner.getDatabaseClient(DatabaseId.of(projectId,instanceId, databaseId));
                        break;
                    case "uat":
                        dbClient = spanner.getDatabaseClient(DatabaseId.of(projectId,instanceId, databaseIdUAT));
                        break;
                    default:
                        log.error("Provide correct environment for spanner db connection");
                }
                if(dbClient != null){
                    Logger.getLogger().info("DB connected");
                }
            }catch (Exception e){
                log.error("Error in Spanner DB connection = "+e.getLocalizedMessage());
            }
        }
        else {
            Logger.getLogger().info("DB already connected");
        }
    }

    public void updateQuery(String query){

            if(dbClient != null){
                dbClient.readWriteTransaction().run(transactionContext -> {
                    Statement updateStatement = Statement.newBuilder(query).build();
                    if(transactionContext.executeUpdate(updateStatement) == 0){
                        Logger.getLogger().info("Query updated successfully");
                    };
                    return null;
                });
            }else {
                log.error("Spanner DB not connected");
            }

    }

    public ResultSet selectQuery(String query){

        if(resultSet != null){
            resultSet.close();
        }
        try{
            resultSet = dbClient.singleUse().executeQuery(Statement.of(query));
        }catch (Exception e){
            log.error("Error in query execution = "+e.getLocalizedMessage());
        }
        return resultSet;

    }

    public String getToken(ResultSet resultSet, String customerName){

        String token = "";
        while (resultSet.next()){
            int columnsIndex = resultSet.getColumnIndex(customerTOken);
            int name = resultSet.getColumnIndex(customerNAme);
            if(resultSet.getString(name).equals(customerName)){
                token = resultSet.getString(columnsIndex);
                break;
            }
        }
        return token;
    }



}
