package org.core.util;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class JsonParserFromFile {

    public static JsonObject readJsonFromFile(String filePath) {
        try {
            String jsonContent = new String(Files.readAllBytes(Paths.get(filePath)));
            return JsonParser.parseString(jsonContent).getAsJsonObject();
        } catch (IOException var2) {
            var2.printStackTrace();
            return null;
        }
    }

    public static List<JsonObject> getDataAsList(JsonObject jsonObject) {
        if (jsonObject == null) {
            System.out.println("No data from json");
            return Collections.emptyList();
        } else {
            List<JsonObject> testData = new ArrayList();
            Iterator var2 = jsonObject.keySet().iterator();

            while(var2.hasNext()) {
                String key = (String)var2.next();
                JsonObject dataObject = jsonObject.getAsJsonObject(key);
                testData.add(dataObject);
            }

            return testData;
        }
    }
}
