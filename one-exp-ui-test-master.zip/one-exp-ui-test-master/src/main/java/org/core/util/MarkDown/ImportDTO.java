package org.core.util.MarkDown;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class ImportDTO {
    private Integer division;
    private Integer location;
    private Long upc;
    private String effectiveDate;
    private Integer prcStat;
    private Integer onHandQty;
    private Integer tcktQty;
    private String color;
    private String mchHierId;
    private String pid;
    private Boolean presentInPricingService;

    public ImportDTO(Integer division, Integer location, Long upc, String effectiveDate, Integer prcStat, Integer onHandQty, Integer tcktQty, String mchHierId, String pid, String color) {
        this.division = division;
        this.location = location;
        this.upc = upc;
        this.effectiveDate = effectiveDate;
        this.prcStat = prcStat;
        this.onHandQty = onHandQty;
        this.tcktQty = tcktQty;
        this.mchHierId = mchHierId;
        this.pid=pid;
        this.color=color;
    }
}
