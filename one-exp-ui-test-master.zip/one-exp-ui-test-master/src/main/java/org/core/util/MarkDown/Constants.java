package org.core.util.MarkDown;

public class Constants {
    public static final String MKDN_MARKDOWN_TABLE_NAME = "MKDN_MARKDOWN";
    public static final String MKDN_MCH_HIER_TABLE_NAME = "MKDN_MCH_HIER";
    public static final String MARKDOWN_ID = "MARKDOWN_ID";
    public static final String UPC = "UPC";
    public static final String EFF_DATE = "EFF_DATE";
    public static final String COLOR_DESC = "COLOR_DESC";
    public static final String NCT_IND = "NCT_IND";
    public static final String ONHAND_QTY = "ONHAND_QTY";
    public static final String TCKT_QTY = "TCKT_QTY";
    public static final String PID = "PID";
    public static final String PRC_STAT = "PRC_STAT";
    public static final String CANCEL="IS_CANCEL";

    public static final String DIVN_NBR = "DIVN_NBR";
    public static final String LOC_NBR = "LOC_NBR";
    public static final String IS_CANCEL = "IS_CANCEL";
    public static final String CREATED_BY = "CREATED_BY";
    public static final String CREATED_TS = "CREATED_TS";
    public static final String DF_UPDATED_TS = "DF_UPDATE_TS";
    public static final String MCH_HIER_ID = "MCH_HIER_ID";
    public static final String UPDATED_TS = "UPDATED_TS";
    public static final String UPDATED_BY = "UPDATED_BY";
    public static final String DEPT_NBR = "DEPT_NBR";
    public static final String DEPT_DESC = "DEPT_DESC";
    public static final String GMM_ID = "GMM_ID";
    public static final String GMM_DESC = "GMM_DESC";
    public static final String DIV_MAN_ID = "DIV_MAN_ID";
    public static final String DIV_MAN_DESC = "DIV_MAN_DESC";
    public static final String VENDOR_NBR = "VENDOR_NBR";
    public static final String VENDOR_DESC = "VENDOR_DESC";
    public static final String RFID_IND = "RFID_IND";
}
