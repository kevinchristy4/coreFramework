package org.core.util;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class PropertiesHandler {

    private static Properties properties;
    public static synchronized Properties getProperties() {
        if (properties == null) {
            InputStream input = PropertiesHandler.class.getClassLoader().getResourceAsStream("application.properties");

            try {
                properties = new Properties();
                properties.load(input);
                input.close();
            } catch (IOException var2) {
                var2.printStackTrace();
            }

        }
        return properties;
    }

    public static String getJsonKeyValue(String jsonString, String key){
        JsonObject jsonObject = JsonParser.parseString(jsonString).getAsJsonObject();
        return jsonObject.get(key).getAsString();
    }
}
