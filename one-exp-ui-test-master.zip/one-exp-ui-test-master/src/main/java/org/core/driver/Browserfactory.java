package org.core.driver;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.html5.LocalStorage;
import org.openqa.selenium.html5.WebStorage;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;

public final class Browserfactory {


    private static org.core.util.Logger log = org.core.util.Logger.getLogger();
    static ThreadLocal<ChromeDriver> driverHolder = new ThreadLocal<ChromeDriver>();
    public static ChromeDriver driver = null;
    private static ChromeDriver setDriver() throws Exception{
        try{
//            System.setProperty("webdriver.chrome.driver","drivers/chromedriver.exe");
            ChromeOptions chcoptions = new ChromeOptions();

//            chcoptions.setBinary("drivers/chrome-win64/chrome.exe");
            chcoptions.addArguments("start-maximized");
            chcoptions.addArguments("incognito");
            chcoptions.addArguments("--remote-allow-origins=*");
            chcoptions.addArguments("--window-size=400,800");
            System.setProperty("webdriver.chrome.silentOutput", "true");
            java.util.logging.Logger.getLogger("org.openqa.selenium").setLevel(Level.SEVERE);

            // Set location permission to true
            Map<String, Object> prefs = new HashMap<String, Object>();
            Map<String, Object> profile = new HashMap<String, Object>();
            Map<String, Object> contentSettings = new HashMap<String, Object>();
            contentSettings.put("geolocation", 1);
            profile.put("managed_default_content_settings", contentSettings);
            prefs.put("profile", profile);
            chcoptions.setExperimentalOption("prefs",prefs);
            driver = new ChromeDriver(chcoptions);

            // Set Geolocation to New york
            Map<String,Object> loc = new HashMap<>();
            loc.put("latitude",37.774929);
            loc.put("longitude",-122.419416);
            loc.put("accuracy",100);
            driver.executeCdpCommand( "Emulation.setGeolocationOverride",loc);

        } catch (Exception e){
            log.error("Error in Launching chrome = "+e.getLocalizedMessage());
        }
        return driver;
    }

//    public static ChromeDriver setDriverWithoutGeoLocation(){
//
//    }
    public static ChromeDriver  getDriver() throws Exception {
        try{
            if(driverHolder.get() == null){
                driverHolder.set(Browserfactory.setDriver());
                return driverHolder.get();
            }
        } catch (Exception e){
            log.error("Error in getting chrome driver = "+e.getLocalizedMessage());
        }
            return driverHolder.get();
    }
    public static void closeBrowser() throws Exception {
        try {
            getDriver().quit();
        } catch (Exception e) {
            log.error("Error in Closing chrome = "+e.getLocalizedMessage());
        } finally {
            driverHolder.remove();
        }
    }

}
