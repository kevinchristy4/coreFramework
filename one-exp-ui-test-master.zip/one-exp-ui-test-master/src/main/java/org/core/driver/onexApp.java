package org.core.driver;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import io.appium.java_client.MultiTouchAction;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.touch.offset.PointOption;
import org.core.util.Logger;
import org.core.util.PropertiesHandler;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.html5.LocalStorage;
import org.openqa.selenium.html5.WebStorage;
import org.openqa.selenium.logging.LogEntries;
import org.openqa.selenium.logging.LogEntry;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.SkipException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class onexApp {

    int xOffSet = 375;
    int yOffSet = 1044;

    private static WebDriver webDriver;
    private static AndroidDriver androidDriver;
    private static ChromeDriver chromeDriver;
    private String browserExecution = PropertiesHandler.getProperties().getProperty("runInBrowser");

    public onexApp() throws Exception {

        if (browserExecution != null && browserExecution.equalsIgnoreCase("true")) {
            chromeDriver = Browserfactory.getDriver();
            webDriver = chromeDriver;
        } else {
            androidDriver = halDriver.getDriver();
            webDriver = androidDriver;
        }
    }

    public onexApp(int count) throws InterruptedException, IOException {

        try {
            for (int i = 0; i < count; i++) {
                Runtime.getRuntime().exec("adb shell input tap " + xOffSet + " " + yOffSet);
            }
        }catch (IOException e) {
            System.out.println("Error in click version number");
            e.printStackTrace();
        }
    }

    public WebDriver getDriver() throws Exception {

        return webDriver;
    }

    public AndroidDriver getAndroidDriver() {
        return androidDriver;
    }

    public ChromeDriver getChromeDriver() {
        return chromeDriver;
    }


    public void close() throws Exception {
        halDriver.closeHal();
    }

    public void unlockDevice() throws Exception {
        if(halDriver.getDriver().isDeviceLocked()){
            halDriver.getDriver().unlockDevice();
        }
    }

    public void waitForPage() throws Exception {
        new WebDriverWait(getDriver(), Duration.ofSeconds(60)).until((Function<WebDriver, Boolean>) driver -> {
            Boolean isPageLoaded = false;
            try {
                Object isDocumentReady = ((JavascriptExecutor)
                        driver).executeScript("return document.readyState");

                if (isDocumentReady.toString().equals("complete")) {
                    isPageLoaded = true;
                }
            } catch (Exception e) {
                System.out.println(e);
            }
            return isPageLoaded;
        });
    }

    public int getEventsCount() throws Exception {

        LogEntries entry =  halDriver.getDriver().manage().logs().get("logcat");
        List<LogEntry> logs= entry.getAll();
        int i = 0;
        for(LogEntry e: logs)
        {
            if(e.getMessage().contains("CONSOLE(204)")){
                i++;
                System.out.println(e.toJson().get("message"));
            }
        }
        System.out.println("Number of events triggered in the current session = "+i);
        return entry.getAll().size();
    }

    // Get wifi details from adb and store ssid and bssid in map, rssi is constantly changing so we don't need it to be compared to BQ
    public Map<String, String> getWifiDetails() throws IOException, InterruptedException {

        Process process = Runtime.getRuntime().exec(" adb shell \"dumpsys wifi | grep 'SSID:' | grep 'state: COMPLETED'\"");

        BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
        StringBuilder output = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            output.append(line).append("\n");
        }
        process.waitFor();
        String wifiDetails = output.toString().trim();
        Matcher ssid = Pattern.compile("SSID: (.*?)(?=\\s+BSSID:)").matcher(wifiDetails);
        Matcher bssid = Pattern.compile("BSSID: (\\S+)").matcher(wifiDetails);
//        Matcher rssi = Pattern.compile("RSSI: (-?\\\\d+)").matcher(wifiDetails);
        Map<String, String> wifiInfoMap = new HashMap<>();
        if (ssid.find()) {
            wifiInfoMap.put("SSID", ssid.group(1).trim());
        }
        if (bssid.find()) {
            wifiInfoMap.put("BSSID", bssid.group(1).trim());
        }
        return wifiInfoMap;
    }

    public String getAppVersion() throws IOException {

        Process process = Runtime.getRuntime().exec(" adb shell \"dumpsys package 'com.macys.sdf.androidhal.onexp' | grep 'versionName'\" ");
        BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
        StringBuilder output = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            output.append(line).append("\n");
        }

        if (output != null && output.toString().contains("versionName=")) {
            return new String(output).trim().split("=")[1];
        }
        return null;
    }

    public void setLocInfoInBrowserStorage(String div, String store, String location) throws Exception {

        LocalStorage local = ((WebStorage) webDriver).getLocalStorage();
        JsonObject jsonObject = JsonParser.parseString(local.getItem("simulatorData")).getAsJsonObject();
        JsonObject getLocationInformation = jsonObject.getAsJsonObject("getLocationInformation")
                .getAsJsonObject("response")
                .getAsJsonObject("locationInformation");
        JsonObject divInfo = getLocationInformation.getAsJsonObject("divInfo");
        JsonObject storeInfo = getLocationInformation.getAsJsonObject("storeInfo");
        divInfo.addProperty("num", div);
        storeInfo.addProperty("num", store);
        storeInfo.addProperty("locn",location);
        local.removeItem("simulatorData");
        local.setItem("simulatorData",jsonObject.toString());
    }

    public void launchApp() throws Exception {
        getDriver().get(PropertiesHandler.getProperties().getProperty("envURL"));
        if(getDriver().getTitle().equals("403")){
            Logger.getLogger().error("Check VPN connection");
            getDriver().quit();
            throw new Exception("Check VPN connection, OneX returns 403");
        }
    }

}
