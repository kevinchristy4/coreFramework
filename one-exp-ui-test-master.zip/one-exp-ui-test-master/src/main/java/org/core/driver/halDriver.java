package org.core.driver;

import com.google.common.collect.ImmutableMap;
import io.appium.java_client.android.AndroidDriver;
//import io.appium.java_client.remote.MobileCapabilityType;
import org.core.util.DriverDownloader;
import org.core.util.PropertiesHandler;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;

public final class halDriver {

    static ThreadLocal<AndroidDriver> driverHolder = new ThreadLocal<AndroidDriver>();
    public static AndroidDriver driver = null;

    private static AndroidDriver setDriver(){
        try{
            DesiredCapabilities capabilities = new DesiredCapabilities();
            capabilities.setCapability("chromedriverExecutable","drivers/chromedriver.exe");
            capabilities.setCapability("deviceName","CT40");
            capabilities.setCapability("platformName","android");
            capabilities.setCapability("automationName","uiautomator2");
            capabilities.setCapability("platformVersion","11");
            capabilities.setCapability("udid", PropertiesHandler.getProperties().getProperty("adbDeviceID"));
            capabilities.setCapability("appPackage","com.macys.sdf.androidhal.onexp");
            capabilities.setCapability("appActivity","com.macys.sdf.androidhal.activities.SplashScreenActivity");
            capabilities.setCapability("autoGrantPermissions", "true");
            capabilities.setCapability("newCommandTimeout", 6000);
            capabilities.setCapability("unlockType", PropertiesHandler.getProperties().getProperty("unlockType"));
            capabilities.setCapability("unlockKey", PropertiesHandler.getProperties().getProperty("unlockPassword"));
            capabilities.setCapability("appium:chromeOptions", ImmutableMap.of("w3c", false));

            URL url = new URL("http://127.0.0.1:4723/wd/hub");

            driver = new AndroidDriver(url,capabilities);

        }catch (Exception e){
            System.out.println(e);
        }
        return driver;
    };

    public static AndroidDriver getDriver() throws Exception {
        try{
            if(driverHolder.get() == null){
                checkForDriverAvailability();
                driverHolder.set(halDriver.setDriver());
                return driverHolder.get();
            }
        } catch (Exception e){
            throw new Exception(e);
        }
        return driverHolder.get();
    }

    public static void closeHal(){
        try {
            getDriver().quit();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            driverHolder.remove();
        }
    }

    public static String getWebViewVersion() {
        try{
            Process process = Runtime.getRuntime().exec("adb shell \"dumpsys package 'com.google.android.webview' | grep 'versionName'\"");
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.contains("versionName")) {
                    return line.split("=")[1].trim();
                }
            }
            reader.close();
            int exitValue = process.waitFor();
            if (exitValue != 0) {
                // Handle abnormal exit
                System.err.println("Error: ADB command exited with non-zero status: " + exitValue);
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
        return null;
    }

    private static Boolean isDriverPresent(){

        String driversFolderPath = "drivers";
        File driversFolder = new File(driversFolderPath);
        if (driversFolder.exists() && driversFolder.isDirectory()) {
            File chromeDriverFile = new File(driversFolderPath + File.separator + "chromedriver.exe");
            return chromeDriverFile.exists();
        }
        return false;
    }

    private static void checkForDriverAvailability() throws IOException, NoSuchAlgorithmException, KeyStoreException, KeyManagementException {
        if(!isDriverPresent()){
            System.out.println("No drivers found - Downloading drivers....");
            System.out.println(getWebViewVersion());
            DriverDownloader.downloadChromeDriver(getWebViewVersion());
        }
    }

}
